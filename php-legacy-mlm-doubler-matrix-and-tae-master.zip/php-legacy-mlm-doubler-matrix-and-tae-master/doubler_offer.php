<?php
if($offer['doubler1_num'])
{
$matrixnumber = 1;
$count = $offer['doubler1_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($offer['doubler2_num'])
{
$matrixnumber = 2;
$count = $offer['doubler2_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($offer['doubler3_num'])
{
$matrixnumber = 3;
$count = $offer['doubler3_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($offer['doubler4_num'])
{
$matrixnumber = 4;
$count = $offer['doubler4_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($offer['doubler5_num'])
{
$matrixnumber = 5;
$count = $offer['doubler5_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($offer['doubler6_num'])
{
$matrixnumber = 6;
$count = $offer['doubler6_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($offer['doubler7_num'])
{
$matrixnumber = 7;
$count = $offer['doubler7_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($offer['doubler8_num'])
{
$matrixnumber = 8;
$count = $offer['doubler8_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($offer['doubler9_num'])
{
$matrixnumber = 9;
$count = $offer['doubler9_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($offer['doubler10_num'])
{
$matrixnumber = 10;
$count = $offer['doubler10_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
?>