<?php
if($upgradesuperjvbonusmatrix1_num > 0)
{
$matrixnumber = 1;
$count = $upgradesuperjvbonusmatrix1_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradesuperjvbonusmatrix2_num > 0)
{
$matrixnumber = 2;
$count = $upgradesuperjvbonusmatrix2_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradesuperjvbonusmatrix3_num > 0)
{
$matrixnumber = 3;
$count = $upgradesuperjvbonusmatrix3_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradesuperjvbonusmatrix4_num > 0)
{
$matrixnumber = 4;
$count = $upgradesuperjvbonusmatrix4_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradesuperjvbonusmatrix5_num > 0)
{
$matrixnumber = 5;
$count = $upgradesuperjvbonusmatrix5_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradesuperjvbonusmatrix6_num > 0)
{
$matrixnumber = 6;
$count = $upgradesuperjvbonusmatrix6_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradesuperjvbonusmatrix7_num > 0)
{
$matrixnumber = 7;
$count = $upgradesuperjvbonusmatrix7_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradesuperjvbonusmatrix8_num > 0)
{
$matrixnumber = 8;
$count = $upgradesuperjvbonusmatrix8_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradesuperjvbonusmatrix9_num > 0)
{
$matrixnumber = 9;
$count = $upgradesuperjvbonusmatrix9_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradesuperjvbonusmatrix10_num > 0)
{
$matrixnumber = 10;
$count = $upgradesuperjvbonusmatrix10_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
?>