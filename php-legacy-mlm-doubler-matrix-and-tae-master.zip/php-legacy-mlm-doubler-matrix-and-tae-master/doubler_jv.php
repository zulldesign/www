<?php
if($upgradejvbonusmatrix1_num > 0)
{
$matrixnumber = 1;
$count = $upgradejvbonusmatrix1_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradejvbonusmatrix2_num > 0)
{
$matrixnumber = 2;
$count = $upgradejvbonusmatrix2_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradejvbonusmatrix3_num > 0)
{
$matrixnumber = 3;
$count = $upgradejvbonusmatrix3_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradejvbonusmatrix4_num > 0)
{
$matrixnumber = 4;
$count = $upgradejvbonusmatrix4_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradejvbonusmatrix5_num > 0)
{
$matrixnumber = 5;
$count = $upgradejvbonusmatrix5_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradejvbonusmatrix6_num > 0)
{
$matrixnumber = 6;
$count = $upgradejvbonusmatrix6_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradejvbonusmatrix7_num > 0)
{
$matrixnumber = 7;
$count = $upgradejvbonusmatrix7_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradejvbonusmatrix8_num > 0)
{
$matrixnumber = 8;
$count = $upgradejvbonusmatrix8_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradejvbonusmatrix9_num > 0)
{
$matrixnumber = 9;
$count = $upgradejvbonusmatrix9_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($upgradejvbonusmatrix10_num > 0)
{
$matrixnumber = 10;
$count = $upgradejvbonusmatrix10_num;
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
?>