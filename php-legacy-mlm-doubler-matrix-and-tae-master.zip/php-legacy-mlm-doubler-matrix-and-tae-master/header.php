<html>
<head>
<title>Doubler Demo</title>
<link rel="stylesheet" type="text/css" href="<?php echo $domain ?>/style.css">
<style TYPE="text/css">
<!--
BODY {
Background-color: #FFFFFF;
background-image:   url("<?php echo $domain ?>/images/bg.jpg");
background-repeat:repeat;
background-position:top;
background-attachment:fixed;
margin-top: 0px;
margin-bottom: 0px;
}
-->
</style>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"/>
<meta NAME="keywords" CONTENT="Sabrina Markon, PHP Site Scripts, e-Webs.us, Marc Tori, Sunshine Hosting, PHP programmer, database expert, server administrator, Marc Tori, E-Webs, design, respected marketer, ad exchange, ad exchanges, free ad exchange, free ad exchanges, text exchange, free text exchange, text exchanges, free text exchanges, advertise, advertise free, advertising, free advertising, market, marketing, promote, promote free, market free, free marketing, free promotion, traffic, guaranteed traffic, free guaranteed traffic, free traffic, free hits, safelist, safelists, free safelist, free safelists, network marketing, free network marketing, affiliate marketing, free affiliate marketing, affiliate, affiliates, free affiliate program, free affiliate programs, affiliate program, affiliate programs, list builder, list builders, free list builder, free list builders, leads, free leads, free business leads, business leads, viral marketing, referrals, free referrals, referral builder, referral builders, free referral builder, free referral builders, banner advertising, post free ads, submit free ads, mlm, tripler, trippler, doubler, cycler">
<META NAME="Description" Content="Best new stable PHP script with Doubler affiliate system! Unique new advertising exchange and TAE script with free advertising for your business and affordable hosting and development!">
<meta name="author" content="Sabrina Markon"/> 
<link rel="SHORTCUT ICON" href="<?php echo $domain ?>/favicon.ico"> 
</head>
<body>
<center><a href="http://phpsitescripts.com">
<img src="<?php echo $domain ?>/images/header.jpg" valign=top border=0></a>
<br>

<!-- START TOP MENU -->
	 <table align="center" cellpadding="0" cellspacing="0" border="0" width="958" background="<?php echo $domain ?>/images/nav.png">
       <tr>
         <td>
          <table cellpadding="0" cellspacing="0" border="0" width="958">
             <tr align="center" style='height: 40px;'>

                    <td class='left_active'></td><td class='center_active'><a href='<?php echo $domain ?>/index.php?referid=<?php echo $referid ?>' class='menu'>Home</a></td><td class='right_active'></td>
                    <td class="divider">&nbsp;</td>
                    <td class='left_inactive'></td><td class='center_inactive'><a href='<?php echo $domain ?>/memberlogin.php?referid=<?php echo $referid ?>' class='menu'>Login</a></td><td class='right_inactive'></td>
					<td class='divider'></td>
<?php
if ($showcyclingnextpage == "yes")
{
?>
<td class='left_inactive'></td><td class='center_inactive'><a href='<?php echo $domain ?>/cyclingnext.php?referid=<?php echo $referid ?>' class='menu'>Cycling Next</a></td><td class='right_inactive'></td>
<td class='divider'>&nbsp;</td>
<?php
}
if ($showcycledalreadypage == "yes")
{
?>
<td class='left_inactive'></td><td class='center_inactive'><a href='<?php echo $domain ?>/cycledalready.php?referid=<?php echo $referid ?>' class='menu'>Already Cycled</a></td><td class='right_inactive'></td>
<td class='divider'>&nbsp;</td>
<?php
}
?>
<td class='left_inactive'></td><td class='center_inactive'><a href='<?php echo $domain ?>/comparememberships.php?referid=<?php echo $referid ?>' class='menu'>Compare Memberships</a></td><td class='right_inactive'></td>
<td class='divider'></td>
<?php
if ($showmembercount == "yes")
{
?>
<td class='left_inactive'></td><td class='center_inactive'><span class='menu'>Member Count: <? echo $rowcount; ?></span></td>
<td class='right_inactive'></td><td class='divider'></td>
<?php
}
if ($showperlevelmembercount == "yes")
{
?>
<td class='left_inactive'></td><td class='center_inactive'><span class='menu'><?php echo $toplevel ?>: <? echo $superjvrowcount; ?></span></td>
<td class='right_inactive'></td>
<td class="divider">&nbsp;</td>
<td class='left_inactive'></td><td class='center_inactive'><span class='menu'><?php echo $middlelevel ?>: <? echo $jvrowcount; ?></span></td>
<td class='right_inactive'></td>
<td class='divider'>&nbsp;</td>
<td class='left_inactive'></td><td class='center_inactive'><span class='menu'><?php echo $lowerlevel ?>: <? echo $prorowcount; ?></span></td>
<td class='right_inactive'></td>
<?php
}
?>
                </tr>
            </table></td>
       </tr>
     </table>
<!-- END TOP MENU -->

<table cellpadding="0" cellspacing="0" border="0" valign="top" width="960" bgcolor="#FFFFFF">
<tr>
<td width="960">

