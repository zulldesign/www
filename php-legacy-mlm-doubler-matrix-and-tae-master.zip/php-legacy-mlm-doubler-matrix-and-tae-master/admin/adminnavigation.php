<style>
input.ssw {
  color:#ffffff;
  font: bold 100% 'Tahoma',helvetica,sans-serif;
  background-color:#ff0000;
  border: 1px #ffffff outset;
}
</style>
<?

  echo "<TABLE BGCOLOR=\"".$nav_bg."\" border=1 bordercolor=BLACK width=155 cellpadding=\"1\" cellspacing=\"0\"><tr><td>";

?>
<table width="100%">
		<tr>
    	<form method="GET" action="index.php">
		<td align="center" valign="top"><input type="submit" value="Main"  style="width: 220px">
		</td></tr>
        </form>
<tr><td align="center" valign="top"><b>==Site Settings==</b></td></tr>
<form method="GET" action="settings.php">
		<td align="center" valign="top"><input type="submit" value="Settings"  style="width: 220px">
		</td></tr>
        </form>
        <form method="GET" action="siteprofile.php">
		<td align="center" valign="top"><input type="submit" value="Site Profile"  style="width: 220px">
		</td></tr>
        </form>
<tr>
<form method="GET" action="subscriptions.php">
<td align="center" valign="top"><input type="submit" value="Member Subscriptions"  style="width: 220px">
</td></tr>
</form>
<tr>
<form method="GET" action="testimonialsview.php">
<td align="center" valign="top"><input type="submit" value="Member Testimonials"  style="width: 220px">
</td></tr>
</form>

<form method="GET" action="doubler_adminsettings.php">
<tr>
<td align="center" valign="top"><input type="submit" value="Doubler Settings"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_transactions.php">
<tr>
<td align="center" valign="top"><input type="submit" value="Doubler Transactions"  style="width: 220px">
</td></tr>
</form>
<tr>
<form method="GET" action="adpacks_admin.php">
<td align="center" valign="top"><input type="submit" value="Doubler AdPacks"  style="width: 220px">
</td></tr>
</form>
<?php
if (($matrixenabled1 == "yes") and ($selldownline1 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="1"><input type="submit" value="Doubler #1 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="1"><input type="submit" value="Doubler #1 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
if (($matrixenabled2 == "yes") and ($selldownline2 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="2"><input type="submit" value="Doubler #2 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="2"><input type="submit" value="Doubler #2 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
if (($matrixenabled3 == "yes") and ($selldownline3 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="3"><input type="submit" value="Doubler #3 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="3"><input type="submit" value="Doubler #3 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
if (($matrixenabled4 == "yes") and ($selldownline4 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="4"><input type="submit" value="Doubler #4 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="4"><input type="submit" value="Doubler #4 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
if (($matrixenabled5 == "yes") and ($selldownline5 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="5"><input type="submit" value="Doubler #5 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="5"><input type="submit" value="Doubler #5 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
if (($matrixenabled6 == "yes") and ($selldownline6 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="6"><input type="submit" value="Doubler #6 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="6"><input type="submit" value="Doubler #6 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
if (($matrixenabled7 == "yes") and ($selldownline7 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="7"><input type="submit" value="Doubler #7 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="7"><input type="submit" value="Doubler #7 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
if (($matrixenabled8 == "yes") and ($selldownline8 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="8"><input type="submit" value="Doubler #8 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="2"><input type="submit" value="Doubler #8 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
if (($matrixenabled9 == "yes") and ($selldownline9 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="9"><input type="submit" value="Doubler #9 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="9"><input type="submit" value="Doubler #9 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
if (($matrixenabled10 == "yes") and ($selldownline10 == "yes"))
{
?>
<form method="GET" action="doubler_admin.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="10"><input type="submit" value="Doubler #10 Downline"  style="width: 220px">
</td></tr>
</form>
<form method="GET" action="doubler_cycled.php">
<tr>
<td align="center" valign="top"><input type="hidden" name="m" value="10"><input type="submit" value="Doubler #10 Cycled"  style="width: 220px">
</td></tr>
</form>
<?php
}
?>
		<tr>
        <form method="GET" action="featuredadsettings.php">
		<td align="center" valign="top"><input type="submit" value="Featured Ad Design"  style="width: 220px">
		</td></tr>
        </form>
		<tr>
        <form method="GET" action="editrecommendedsystems.php">
		<td align="center" valign="top"><input type="submit" value="Recommended Systems"  style="width: 220px">
		</td></tr>
        </form>
		<tr>
		<form method="GET" action="editmonthlybonuses.php">
		<td align="center" valign="top"><input type="submit" value="Monthly Bonuses"  style="width: 220px">
		</td></tr>
		</form>

<tr><td align="center" valign="top"><b>==Super Networks==</b></td></tr>

<tr><td align="center" valign="top"><b>==Site Stats==</b></td></tr>
<form method="GET" action="stats.php">
		<td align="center" valign="top"><input type="submit" value="Site Stats"  style="width: 220px">
		</td></tr>
        </form>
       <form method="GET" action="customertransactions.php">
		<td align="center" valign="top"><input type="submit" value="Auto Transactions"  style="width: 220px">
		</td></tr>
        </form>
        <tr>
		<form method="GET" action="monthlybonustransactions.php">
		<td align="center" valign="top"><input type="submit" value="Monthly Transactions"  style="width: 220px">
		</td></tr>
        </form>
  <form method="GET" action="prizetransactions.php">
		<td align="center" valign="top"><input type="submit" value="Prize Transactions"  style="width: 220px">
		</td></tr>
        </form>
 <form method="GET" action="currentmemberstats.php">
		<td align="center" valign="top"><input type="submit" value="Daily Ad Clicks"  style="width: 220px">
		</td></tr>
        </form>

        <form method="GET" action="activememberstats.php">
		<td align="center" valign="top"><input type="submit" value="Active Members"  style="width: 220px">
		</td></tr>
        </form>
    <tr>
        <form method="GET" action="viewalladminsolos.php">
		<td align="center" valign="top"><input type="submit" value="Admin Ads Stats"  style="width: 220px">
		</td></tr>
		</form>	
               <tr>
        <form method="GET" action="soloadstats.php">
		<td align="center" valign="top"><input type="submit" value="Solo Ad Stats"  style="width: 220px">
		</td></tr>
		</form>               

<tr><td align="center" valign="top"><b>==Ads==</b></td></tr>


<form method="GET" action="addads.php">
		<td align="center" valign="top"><input type="submit" value="Ad Ads to Member"  style="width: 220px">
		</td></tr>
        </form>
    	<form method="GET" action="approveadds.php">
		<td align="center" valign="top"><input type="submit" value="Approve Ads"  style="width: 220px">
		</td></tr>
		</form>
               <tr>
        <form method="GET" action="addadminsolos.php">
		<td align="center" valign="top"><input type="submit" value="Admin Ads"  style="width: 220px">
		</td></tr>
		</form>	
               
              	
		                
<tr><td align="center" valign="top"><b>==Members==</b></td></tr>


<form method="GET" action="view.php">
		<td align="center" valign="top"><input type="submit" value="View Members"  style="width: 220px">
		</td></tr>
        </form>
		<tr>
    	<form method="GET" action="search.php">
		<td align="center" valign="top"><input type="submit" value="Search Members"  style="width: 220px">
		</td></tr>
		</form>
    	<form method="GET" action="upgrademember.php">
		<td align="center" valign="top"><input type="submit" value="Upgrade Member"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="cashoutrequests.php">
		<td align="center" valign="top"><input type="submit" value="Cash Out Requests"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
    	<form method="GET" action="commission.php">
		<td align="center" valign="top"><input type="submit" value="Commission"  style="width: 220px">
		</td></tr>
		</form>


<tr><td align="center" valign="top"><b>==View Ads==</b></td></tr>

		<tr>
    	<form method="GET" action="viewallsurfs.php">
		<td align="center" valign="top"><input type="submit" value="View Surf Pages"  style="width: 220px">
		</td></tr>
		</form>  
		<tr>
    	<form method="GET" action="viewallbanners.php">
		<td align="center" valign="top"><input type="submit" value="View Active Banners"  style="width: 220px">
		</td></tr>
		</form>
                <tr>
    	<form method="GET" action="viewallbanners2.php">
		<td align="center" valign="top"><input type="submit" value="View All Banners"  style="width: 220px">
		</td></tr>
		</form>
                <tr>
        <form method="GET" action="viewallbuttons.php">
		<td align="center" valign="top"><input type="submit" value="View Active Buttons"  style="width: 220px">
		</td></tr>
		</form>
        <form method="GET" action="viewallbuttons2.php">
		<td align="center" valign="top"><input type="submit" value="View All Buttons"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
    	<form method="GET" action="viewallads.php">
		<td align="center" valign="top"><input type="submit" value="View Text Ads"  style="width: 220px">
		</td></tr>
		</form>
                <tr>
    	<form method="GET" action="viewallhtmlads.php">
		<td align="center" valign="top"><input type="submit" value="View Html Ads"  style="width: 220px">
		</td></tr>
		</form>

		<form method="GET" action="viewalltlinks.php">
		<td align="center" valign="top"><input type="submit" value="View Traffic Links"  style="width: 220px">
		</td></tr>
		</form>
                              <form method="GET" action="viewallptclinks.php">
		<td align="center" valign="top"><input type="submit" value="View PTC Links"  style="width: 220px">
		</td></tr>
		</form>

                <form method="GET" action="viewallhotlink.php">
		<td align="center" valign="top"><input type="submit" value="View Hot Links"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="viewalltopnav.php">
		<td align="center" valign="top"><input type="submit" value="View Top Nav"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="viewallbotnav.php">
		<td align="center" valign="top"><input type="submit" value="View Bottom Nav"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="viewalllogin.php">
		<td align="center" valign="top"><input type="submit" value="View Login Ads"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="viewallfullloginads.php">
		<td align="center" valign="top"><input type="submit" value="View Full Page Login Ads"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="viewallfeaturedads.php">
		<td align="center" valign="top"><input type="submit" value="View Featured Ads"  style="width: 220px">
		</td></tr>
		</form>
                 <tr>
		<form method="GET" action="viewallfooterads.php">
		<td align="center" valign="top"><input type="submit" value="View Footer Ads"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="viewallsolos.php">
		<td align="center" valign="top"><input type="submit" value="View Solos"  style="width: 220px">
		</td></tr>
		</form>	
		<tr>
		<form method="GET" action="viewallhheadlineads.php">
		<td align="center" valign="top"><input type="submit" value="View HOT Headline Adz"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="viewallhheaderads.php">
		<td align="center" valign="top"><input type="submit" value="View HOT Header Ads"  style="width: 220px">
		</td></tr>
		</form>

<tr><td align="center" valign="top"><b>==Edit Pages==</b></td></tr>


<tr>
    	<form method="GET" action="editpages.php">
		<td align="center" valign="top"><input type="submit" value="Edit Pages"  style="width: 220px">
		</td></tr>
		</form>
		    	        <tr>
    	<form method="GET" action="navigation.php">
		<td align="center" valign="top"><input type="submit" value="Edit Navigation"  style="width: 220px">
		</td></tr>
		</form>
    	<form method="GET" action="editoto.php">
		<td align="center" valign="top"><input type="submit" value="Edit OTO"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="editspecialoffer.php">
		<td align="center" valign="top"><input type="submit" value="Edit Offer Page"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="editcoupon.php">
		<td align="center" valign="top"><input type="submit" value="Edit Coupon Codes"  style="width: 220px">
		</td></tr>
		</form>
                 <tr>
		<form method="GET" action="editbuilder.php">
		<td align="center" valign="top"><input type="submit" value="Downline Builder"  style="width: 220px">
		</td></tr>
		</form>
		<tr>
		<form method="GET" action="emailpromotion.php">
		<td align="center" valign="top"><input type="submit" value="Promotion emails"  style="width: 220px">
		</td></tr>
		</form>
                <tr>
		<form method="GET" action="autoresponder.php">
		<td align="center" valign="top"><input type="submit" value="Autoresponder"  style="width: 220px">
		</td></tr>
		</form>
<tr>
		<form method="GET" action="editprize.php">
		<td align="center" valign="top"><input type="submit" value="Prize Contest Settings"  style="width: 220px">
		</td></tr>
		</form>		


  <tr><td align="center" valign="top"><b>==Tools==</b></td></tr>

 <form method="GET" action="cleanup.php">
		<td align="center" valign="top"><input type="submit" value="Clean Up"  style="width: 220px">
		</td></tr>
        </form>

        
    	    	    	<tr>
    	<form method="GET" action="support.php">
		<td align="center" valign="top"><input type="submit" value="Support"  style="width: 220px">
		</td></tr>
		</form>

		<tr>
    	<form method="GET" action="email.php">
		<td align="center" valign="top"><input type="submit" value="Contact All"  style="width: 220px">
		</td></tr>
		</form>
				
<tr>
       	<form method="GET" action="banners.php">
		<td align="center" valign="top"><input type="submit" value="Add Site Banners"  style="width: 220px">
		</td></tr>
		</form>

								<tr>
		<form method="GET" action="referrer.php">
		<td align="center" valign="top"><input type="submit" value="Top Referrers"  style="width: 220px">
		</td></tr>
		</form>
				
		<tr>
    	<form method="GET" action="resendall.php">
		<td align="center" valign="top"><input type="submit" value="Resend verification"  style="width: 220px">
		</td></tr>
		</form>
        <form method="GET" action="bannedemails.php">
		<td align="center" valign="top"><input type="submit" value="Banned emails"  style="width: 220px">
		</td></tr>
               </form>
		<tr>
    	<form method="GET" action="logout.php">
		<td align="center" valign="top"><input type="submit" value="Logout"  style="width: 220px">
		</td></tr>
		</form>
		</table>
<?

  echo "</td></tr></table>";

?>
