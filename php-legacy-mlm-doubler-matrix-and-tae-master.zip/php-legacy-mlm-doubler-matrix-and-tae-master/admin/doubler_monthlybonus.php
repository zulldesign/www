<?php
##############################################################
if (($matrixenabled1 == "yes") and ($selldownline1 == "yes"))
{
if ($doubler1_num > 0)
{
$matrixnumber = 1;
$i = "";
for ($i = 1; $i <= $doubler1_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #1 Position','".time()."','$doubler1_num')";
$tr = mysql_query($tq);
} # if ($doubler1_num > 0)
} # if (($matrixenabled1 == "yes") and ($selldownline1 == "yes"))
##############################################################
if (($matrixenabled2 == "yes") and ($selldownline2 == "yes"))
{
if ($doubler2_num > 0)
{
$matrixnumber = 2;
$i = "";
for ($i = 1; $i <= $doubler2_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #2 Position','".time()."','$doubler2_num')";
$tr = mysql_query($tq);
} # if ($doubler2_num > 0)
} # if (($matrixenabled2 == "yes") and ($selldownline2 == "yes"))
##############################################################
if (($matrixenabled3 == "yes") and ($selldownline3 == "yes"))
{
if ($doubler3_num > 0)
{
$matrixnumber = 3;
$i = "";
for ($i = 1; $i <= $doubler3_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #3 Position','".time()."','$doubler3_num')";
$tr = mysql_query($tq);
} # if ($doubler3_num > 0)
} # if (($matrixenabled3 == "yes") and ($selldownline3 == "yes"))
##############################################################
if (($matrixenabled4 == "yes") and ($selldownline4 == "yes"))
{
if ($doubler4_num > 0)
{
$matrixnumber = 4;
$i = "";
for ($i = 1; $i <= $doubler4_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #4 Position','".time()."','$doubler4_num')";
$tr = mysql_query($tq);
} # if ($doubler4_num > 0)
} # if (($matrixenabled4 == "yes") and ($selldownline4 == "yes"))
##############################################################
if (($matrixenabled5 == "yes") and ($selldownline5 == "yes"))
{
if ($doubler5_num > 0)
{
$matrixnumber = 5;
$i = "";
for ($i = 1; $i <= $doubler5_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #5 Position','".time()."','$doubler5_num')";
$tr = mysql_query($tq);
} # if ($doubler5_num > 0)
} # if (($matrixenabled5 == "yes") and ($selldownline5 == "yes"))
##############################################################
if (($matrixenabled6 == "yes") and ($selldownline6 == "yes"))
{
if ($doubler6_num > 0)
{
$matrixnumber = 6;
$i = "";
for ($i = 1; $i <= $doubler6_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #6 Position','".time()."','$doubler6_num')";
$tr = mysql_query($tq);
} # if ($doubler6_num > 0)
} # if (($matrixenabled6 == "yes") and ($selldownline6 == "yes"))
##############################################################
if (($matrixenabled7 == "yes") and ($selldownline7 == "yes"))
{
if ($doubler7_num > 0)
{
$matrixnumber = 7;
$i = "";
for ($i = 1; $i <= $doubler7_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #7 Position','".time()."','$doubler7_num')";
$tr = mysql_query($tq);
} # if ($doubler7_num > 0)
} # if (($matrixenabled7 == "yes") and ($selldownline7 == "yes"))
##############################################################
if (($matrixenabled8 == "yes") and ($selldownline8 == "yes"))
{
if ($doubler8_num > 0)
{
$matrixnumber = 8;
$i = "";
for ($i = 1; $i <= $doubler8_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #8 Position','".time()."','$doubler8_num')";
$tr = mysql_query($tq);
} # if ($doubler8_num > 0)
} # if (($matrixenabled8 == "yes") and ($selldownline8 == "yes"))
##############################################################
if (($matrixenabled9 == "yes") and ($selldownline9 == "yes"))
{
if ($doubler9_num > 0)
{
$matrixnumber = 9;
$i = "";
for ($i = 1; $i <= $doubler9_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #9 Position','".time()."','$doubler9_num')";
$tr = mysql_query($tq);
} # if ($doubler9_num > 0)
} # if (($matrixenabled9 == "yes") and ($selldownline9 == "yes"))
##############################################################
if (($matrixenabled10 == "yes") and ($selldownline10 == "yes"))
{
if ($doubler10_num > 0)
{
$matrixnumber = 10;
$i = "";
for ($i = 1; $i <= $doubler10_num; $i++)
{
$positioncount = 1;
include "../doubler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #10 Position','".time()."','$doubler10_num')";
$tr = mysql_query($tq);
} # if ($doubler10_num > 0)
} # if (($matrixenabled10 == "yes") and ($selldownline10 == "yes"))
?>