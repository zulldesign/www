<?php
if($oto['doubler1_num'])
{
$matrixnumber = 1;
$count = $oto['doubler1_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($oto['doubler2_num'])
{
$matrixnumber = 2;
$count = $oto['doubler2_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($oto['doubler3_num'])
{
$matrixnumber = 3;
$count = $oto['doubler3_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($oto['doubler4_num'])
{
$matrixnumber = 4;
$count = $oto['doubler4_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($oto['doubler5_num'])
{
$matrixnumber = 5;
$count = $oto['doubler5_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($oto['doubler6_num'])
{
$matrixnumber = 6;
$count = $oto['doubler6_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($oto['doubler7_num'])
{
$matrixnumber = 7;
$count = $oto['doubler7_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($oto['doubler8_num'])
{
$matrixnumber = 8;
$count = $oto['doubler8_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($oto['doubler9_num'])
{
$matrixnumber = 9;
$count = $oto['doubler9_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
if($oto['doubler10_num'])
{
$matrixnumber = 10;
$count = $oto['doubler10_num'];
	while($count > 0)
	{
	$positioncount = 1;
	include "doubler_add.php";
	$count--;
	}
}
?>