MLM "Doubler" Affiliate System and TAE (legacy 2012)

Text Ad Exchange (TAE) script with Affiliate Doubler Mod (payout every 2 referrals)

CUSTOM BUILD MLM E-Business Script - TEXT AD EXCHANGE (TAE) and DOUBLER MOD SCRIPT - SJV DOUBLER SCRIPT v6.1      		      
Script Developed By: Sabrina Markon 				      
http://sabrinamarkon.com
