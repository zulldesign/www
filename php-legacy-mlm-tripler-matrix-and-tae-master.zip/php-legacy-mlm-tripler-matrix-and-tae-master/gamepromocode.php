<?PHP 
$sref=$_REQUEST["ref"]; 
include "config.php";
mysql_close();
?>
<html>
<head>
<meta http-equiv="Content-Type" 
content="text/html; charset=iso-8859-1"> 
<title>Win Promo Code <? echo $sitename; ?>!</title>
<center>
<img src="/images/freebie.gif"><br>
<table border="5" bordercolor="#000000" width="700" bgcolor="#F4F2AE">
<tr>
<td>   <br><br><br><div style="margin-left: 80px; font-family: Tahoma;"><font size="3"><font size="5"><span style="font-weight: bold; color: rgb(255, 0, 0);">You could get some really nice advertising credits here! </span><br style="font-weight: bold;"/></font> <br/>
<span style="font-weight: bold; font-family: Arial; color: rgb(0, 0, 128);">Just click button below (start at round 1) and answer very simple questions!</span><br style="font-family: Arial;"/> <br/>
Round 1 -&nbsp;  <span style="font-weight: bold;">5 banners with 5000 views</span><br/>
Round 2 - &nbsp;  <span style="font-weight: bold;">5 hotlinks with 5000 views</span><br/>
Round 3 -&nbsp;  <span style="font-weight: bold;">5 LogIn Ads with 5000 views</span><br/>
Round 4 - &nbsp;  <span style="font-weight: bold;">5 Featured Ads with 10,000 views</span><br/>
Round 5 -&nbsp;&nbsp; <span style="font-weight: bold;">5 solo email</span><br/>
</font></div>
<span style="font-family: Verdana;"><font size="4"></font></span>






<br><br>

<center>
<SCRIPT LANGUAGE="JavaScript">

<!-- This script and many more are available free online at -->
<!-- The JavaScript Source!! http://javascript.internet.com -->
<!-- Original:  Jeremy Greenfield (paperairplane@noisebox.com ) -->
<!-- Web Site:  http://www.buckers.0catch.com -->
<!-- Begin
function Round1()
{
Q1=prompt("How many dollar is the minimum payout here?","Your Answer Here");
if (Q1=="1")
{
alert("Correct! Use Promo Code dollar")
document.verify.Question2.value="Granted"
}
else
{
alert("Incorrect! Try Again.")
}
}
function Round2()
{
Q2=prompt("What comes after Sunday?","Your Answer Here \(lower case\)")
if (Q2=="monday")
{
alert("Correct! Use PromoCode monday")
document.verify.Question3.value="Granted"
}
else
{
alert("Incorrect! Try Again.")
}
}
function Round3()
{
Q3=prompt("We are not a PTC Site.  What PTC stands for?","Your Answer Here! lower case")
if (Q3=="paid to click")
{
alert("Correct! Use Promo Code click")
document.verify.Question4.value="Granted"
}
else
{
alert("Incorrect! Try Again.")
}
}
function Round4()
{
Q4=prompt("The theory E=MC2 was made by whom?","Your Answer Here")
if (Q4=="Albert Einstein")
{
alert("Correct! Use Promo Code Albert")
document.verify.Question5.value="Granted"
}
else
{
alert("Incorrect! Try Again.")
}
}
function Round5()
{
Q3=prompt("The taste of the sea water","Your Answer Here *lowecase")
if (Q3=="salty")
{
alert("Correct! Use Promo Code salt")
alert("You answered every question correctly! Congrats! \n\n\n\n\n\n\n\n\n Bonus Code global")
alert("Thanks for playing! Come back here often for new set of questions and codes!")
}
else
{
alert("Incorrect! Try Again.")
}
}
function PendRound2()
{
if (document.verify.Question2.value=="Granted")
{
Round2()
}
if (document.verify.Question2.value=="Denied")
{
alert("You must answer the previous rounds correctly before advancing to this round.") 
}
}
function PendRound3()
{
if (document.verify.Question3.value=="Granted")
{
Round3()
}
if (document.verify.Question3.value=="Denied")
{
alert("You must answer the previous rounds correctly before advancing to this round.") 
}
}
function PendRound4()
{
if (document.verify.Question4.value=="Granted")
{
Round4()
}
if (document.verify.Question4.value=="Denied")
{
alert("You must answer the previous rounds correctly before advancing to this round.") 
}
}
function PendRound5()
{
if (document.verify.Question5.value=="Granted")
{
Round5()
}
if (document.verify.Question5.value=="Denied")
{
alert("You must answer the previous rounds correctly before advancing to this round.") 
}
}
//  End -->
</script>


</SCRIPT>

<script language=JavaScript>
<!--

//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("alert(message);return false")

// --> 
</script>
</head>

<body background="/images/bg.jpg"> 

<form name="verify">
<input type="hidden" name="Question2" value="Denied"><input type="hidden" name="Question3" value="Denied"><input type="hidden" name="Question4" value="Denied"><input type="hidden" name="Question5" value="Denied">
</form>
<input type="button" value="Round 1" name="R1" style="color: #0000FF; font-family: Courier New" onClick="Round1()">
<input type="button" value="Round 2" name="R3" style="color: #0000FF; font-family: Courier New" onClick="PendRound2()">
<input type="button" value="Round 3" name="R3" style="color: #0000FF; font-family: Courier New" onClick="PendRound3()">
<input type="button" value="Round 4" name="R4" style="color: #0000FF; font-family: Courier New" onClick="PendRound4()">
<input type="button" value="Round 5" name="R5" style="color: #0000FF; font-family: Courier New" onClick="PendRound5()">
</form>

<p><center>
<font face="arial, helvetica" size"-2">Global-Adz.info<br>
 <a href="http://adxchains.info">Cheap T.A.E Sites 4 Sale</a></font>
</center><p>

<!-- Script Size:  3.87 KB -->

<center>&nbsp;<p></p>

</td>
</tr>
</table>
<br>
</center>
</body>

</html>