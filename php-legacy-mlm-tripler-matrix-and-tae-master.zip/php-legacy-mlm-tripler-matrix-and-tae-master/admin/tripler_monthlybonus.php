<?php
##############################################################
if (($matrixenabled1 == "yes") and ($selldownline1 == "yes"))
{
if ($tripler1_num > 0)
{
$matrixnumber = 1;
$i = "";
for ($i = 1; $i <= $tripler1_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #1 Position','".time()."','$tripler1_num')";
$tr = mysql_query($tq);
} # if ($tripler1_num > 0)
} # if (($matrixenabled1 == "yes") and ($selldownline1 == "yes"))
##############################################################
if (($matrixenabled2 == "yes") and ($selldownline2 == "yes"))
{
if ($tripler2_num > 0)
{
$matrixnumber = 2;
$i = "";
for ($i = 1; $i <= $tripler2_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #2 Position','".time()."','$tripler2_num')";
$tr = mysql_query($tq);
} # if ($tripler2_num > 0)
} # if (($matrixenabled2 == "yes") and ($selldownline2 == "yes"))
##############################################################
if (($matrixenabled3 == "yes") and ($selldownline3 == "yes"))
{
if ($tripler3_num > 0)
{
$matrixnumber = 3;
$i = "";
for ($i = 1; $i <= $tripler3_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #3 Position','".time()."','$tripler3_num')";
$tr = mysql_query($tq);
} # if ($tripler3_num > 0)
} # if (($matrixenabled3 == "yes") and ($selldownline3 == "yes"))
##############################################################
if (($matrixenabled4 == "yes") and ($selldownline4 == "yes"))
{
if ($tripler4_num > 0)
{
$matrixnumber = 4;
$i = "";
for ($i = 1; $i <= $tripler4_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #4 Position','".time()."','$tripler4_num')";
$tr = mysql_query($tq);
} # if ($tripler4_num > 0)
} # if (($matrixenabled4 == "yes") and ($selldownline4 == "yes"))
##############################################################
if (($matrixenabled5 == "yes") and ($selldownline5 == "yes"))
{
if ($tripler5_num > 0)
{
$matrixnumber = 5;
$i = "";
for ($i = 1; $i <= $tripler5_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #5 Position','".time()."','$tripler5_num')";
$tr = mysql_query($tq);
} # if ($tripler5_num > 0)
} # if (($matrixenabled5 == "yes") and ($selldownline5 == "yes"))
##############################################################
if (($matrixenabled6 == "yes") and ($selldownline6 == "yes"))
{
if ($tripler6_num > 0)
{
$matrixnumber = 6;
$i = "";
for ($i = 1; $i <= $tripler6_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #6 Position','".time()."','$tripler6_num')";
$tr = mysql_query($tq);
} # if ($tripler6_num > 0)
} # if (($matrixenabled6 == "yes") and ($selldownline6 == "yes"))
##############################################################
if (($matrixenabled7 == "yes") and ($selldownline7 == "yes"))
{
if ($tripler7_num > 0)
{
$matrixnumber = 7;
$i = "";
for ($i = 1; $i <= $tripler7_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #7 Position','".time()."','$tripler7_num')";
$tr = mysql_query($tq);
} # if ($tripler7_num > 0)
} # if (($matrixenabled7 == "yes") and ($selldownline7 == "yes"))
##############################################################
if (($matrixenabled8 == "yes") and ($selldownline8 == "yes"))
{
if ($tripler8_num > 0)
{
$matrixnumber = 8;
$i = "";
for ($i = 1; $i <= $tripler8_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #8 Position','".time()."','$tripler8_num')";
$tr = mysql_query($tq);
} # if ($tripler8_num > 0)
} # if (($matrixenabled8 == "yes") and ($selldownline8 == "yes"))
##############################################################
if (($matrixenabled9 == "yes") and ($selldownline9 == "yes"))
{
if ($tripler9_num > 0)
{
$matrixnumber = 9;
$i = "";
for ($i = 1; $i <= $tripler9_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #9 Position','".time()."','$tripler9_num')";
$tr = mysql_query($tq);
} # if ($tripler9_num > 0)
} # if (($matrixenabled9 == "yes") and ($selldownline9 == "yes"))
##############################################################
if (($matrixenabled10 == "yes") and ($selldownline10 == "yes"))
{
if ($tripler10_num > 0)
{
$matrixnumber = 10;
$i = "";
for ($i = 1; $i <= $tripler10_num; $i++)
{
$positioncount = 1;
include "../tripler_add.php";
}
$tq = "insert into monthly_transactions values ('id','$mbuserid','$mbmemtype Monthly Bonus - Downline #10 Position','".time()."','$tripler10_num')";
$tr = mysql_query($tq);
} # if ($tripler10_num > 0)
} # if (($matrixenabled10 == "yes") and ($selldownline10 == "yes"))
?>