<?php

include("baba/db.php");

$str=mysqli_real_escape_string($con,$_GET["str"]);

//select user
$sql_query="SELECT * FROM referral WHERE str='$str'";
$result_set=mysqli_query($con,$sql_query) or die('error');
$user_ref=mysqli_fetch_array($result_set);
$user=$user_ref['user'];

if(!isset($_COOKIE['referral'])) { 

//cookie for visitor
setcookie("referral", $str, time() + (86400 * 7), "/"); // 86400 = 1 day // 86400 * 7 for 7 Days

//page view Counts
$sql = "UPDATE referral SET clicks=clicks+1 WHERE str='$str'";
$result_set=mysqli_query($con,$sql);

}


?>

<?php

if($user_ref == false)
{

echo 'Sorry, the user does not exist.';

}
else
{   
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php $current_page = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
 echo '<link rel="canonical" href="'.$current_page.'"/>'; ?>


<title><?php echo $user; ?> Love Allwebtuts</title>


<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">


<style type="text/css">
	body {
    font-family: 'Montserrat', sans-serif;
    font-size: 18px;
}

h1{
    font-size: 2.3em;
    font-weight: 600;
    margin: 20px 0 10px 0;
    letter-spacing: -1px;
}


.login-form {
    margin: 0 auto !important;
    float: none;
    padding: 15px;
}

.login-form form.form-horizontal {
    padding: 10px 20px;
}

.bold{
    font-weight: 700;
}
.par{font-family: 'Montserrat', sans-serif; font-weight:200; font-size:23px;}
.inmt{font-weight:100; font-size:17px;}
</style>

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<br />
<br />

<div class="col-md-6 col-lg-5 col-sm-8 center-block well login-form">
<h2 class="par no-margin text-center">Welcome to Allwebtuts Blog</h2>
<div class="clearfix">&nbsp;</div>
<p class="inmt no-margin text-center"><?php echo $user; ?> Loves Allwebtuts what about your??
Read Our Latest Posts <i class="fa fa-smile-o" aria-hidden="true"></i> </p>
</div>
</div>
<div class="clearfix">&nbsp;</div>


<!-- JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


</body>
</html>

<?php
}
?>
