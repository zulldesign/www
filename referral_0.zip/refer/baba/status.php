<?php
//status.php?id=USER_ID
include('db.php');

if($_GET['id'])
{

//variables
$id=mysqli_real_escape_string($con,$_GET["id"]);

//selecr from database
$sql_query = "SELECT * FROM referral WHERE id='$id'";
$result_set=mysqli_query($con,$sql_query) or die('error');
$ref_row=mysqli_fetch_array($result_set); //fetch the result from table
$count=$ref_row['clicks'];
$user=$ref_row['user'];

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php $current_page = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
 echo '<link rel="canonical" href="'.$current_page.'"/>'; ?>


<title>MSK PHP Referral System</title>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">


<style type="text/css">
    body {
    font-family: 'Montserrat', sans-serif;
    font-size: 18px;
}

h1{
    font-size: 2.3em;
    font-weight: 600;
    margin: 20px 0 10px 0;
    letter-spacing: -1px;
}


.login-form {
    margin: 0 auto !important;
    float: none;
    padding: 15px;
}

.login-form form.form-horizontal {
    padding: 10px 20px;
}

.bold{
    font-weight: 700;
}
.par{font-family: 'Montserrat', sans-serif; font-weight:200; font-size:23px;}
.inmt{font-weight:100; font-size:17px;}
</style>

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<br />
<br />


<?php 
if($ref_row)
{
echo "<div class='col-md-6 col-lg-5 col-sm-8 center-block well login-form'><h2 class='par no-margin text-center'>Total Clicks</h2><p class='inmt no-margin text-center'>$user Refer $count Users</p></div></div>";
}
else
{
echo "<div class='col-md-6 col-lg-5 col-sm-8 center-block well login-form'><h2 class='par no-margin text-center'>OOps</h2><p class='inmt no-margin text-center'>404 Page boss</p></div></div>";
}
?>


<!-- JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</body>
</html>