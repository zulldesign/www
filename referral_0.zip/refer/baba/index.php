<?php

include('db.php');
include('logincheck.php');

if(isset($_POST['create-ref']))
{

$user=mysqli_real_escape_string($con,$_POST["user"]);
$user=htmlentities($user);

//friendly URL conversion
function to_prety_url($str){
    if($str !== mb_convert_encoding( mb_convert_encoding($str, 'UTF-32', 'UTF-8'), 'UTF-8', 'UTF-32') )
        $str = mb_convert_encoding($str, 'UTF-8', mb_detect_encoding($str));
    $str = htmlentities($str, ENT_NOQUOTES, 'UTF-8');
    $str = preg_replace('`&([a-z]{1,2})(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig);`i', '\1', $str);
    $str = html_entity_decode($str, ENT_NOQUOTES, 'UTF-8');
    $str = preg_replace(array('`[^a-z0-9]`i','`[-]+`'), '-', $str);
    $str = strtolower( trim($str, '-') );
    return $str;
}
$str=to_prety_url($user);

// sql query for inserting data into database
$sql_query = "INSERT INTO referral (user,str) VALUES ('$user','$str')";
$result_set=mysqli_query($con,$sql_query);

//Referral URL
$refurl="http://localhost/refer/$str";  //replace it with your URL ex: http://example.com/refer/$str

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php $current_page = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
 echo '<link rel="canonical" href="'.$current_page.'"/>'; ?>


<title>MSK PHP Referral System</title>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">


<style type="text/css">
    body {
    font-family: 'Montserrat', sans-serif;
    font-size: 18px;
}

h1{
    font-size: 2.3em;
    font-weight: 600;
    margin: 20px 0 10px 0;
    letter-spacing: -1px;
}


.login-form {
    margin: 0 auto !important;
    float: none;
    padding: 15px;
}

.login-form form.form-horizontal {
    padding: 10px 20px;
}

.bold{
    font-weight: 700;
}
.par{font-family: 'Montserrat', sans-serif; font-weight:200; font-size:23px;}
.inmt{font-weight:100; font-size:17px;}
</style>

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<br />
<br />

<div class="col-md-6 col-lg-5 col-sm-8 center-block well login-form">
<h2 class="par no-margin text-center">Create Referral URL</h2>
<div class="clearfix">&nbsp;</div>
<form method="post" class="form-horizontal" data-parsley-validate>
<div class="form-group">
<input type="text" class="form-control" name="user" placeholder="User Name" data-parsley-required="true" maxlength="25">
 </div>
<div class="form-group">
<button type="submit" name="create-ref" class="btn btn-success btn-block btn-lg">Create Now</button>
</div>
<br />

<?php
if(isset($_POST['user'])) {
echo "<div class='alert alert-success'><p class='inmt no-margin text-center'><i class='fa fa-thumbs-up'></i> Referral URL Created</p><br /><p><pre>$refurl</pre></p></div>";
}
?>

<br />
<a href="logout.php" class="btn btn-success btn-block btn-lg">Logout</a>

</form>
 </div>
</div>
<div class="clearfix">&nbsp;</div>

<!-- JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.5.1/parsley.min.js"></script>

</body>
</html>