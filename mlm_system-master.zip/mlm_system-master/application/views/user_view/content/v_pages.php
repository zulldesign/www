	<div class="space-6"></div>
	<div class="row-fluid">
		<div class="span10">
			<div class="widget-box transparent">
				<div class="widget-header widget-header-flat">
					<h4 class="lighter">
						<i class="icon-star orange"></i>
						.: <?php echo $judul_halaman; ?> :.
					</h4>

					<div class="widget-toolbar">
						<a href="#" data-action="collapse">
							<i class="icon-chevron-up"></i>
						</a>
					</div>
				</div>

				<div class="widget-body">
					<div class="widget-main no-padding">
						<!-- INFORMASI WEBITE DI SINI -->
						<?php echo $isi; ?>
					</div><!--/widget-main-->
				</div><!--/widget-body-->
			</div><!--/widget-box-->
		</div>
	</div>

	<div class="hr hr32 hr-dotted"></div>