Terimakasih Tn/Ny. <?php echo $datausername ?>, Atas Partispasi Anda.<br>
<b>KODE REGISTRAI ANDA ADALAH : <?php echo $konfirmasi; ?></b><br><br>
<h5>*) Harap Mengingat/Menyimpan Kode Registrasi Ini Untuk Mempercepat Proses/Transaksi Anda.</h5>
<hr>
Untuk Melanjutkan Pendaftaran Anda,Silahkan Masukan Kode Konfirmasi Ini:<br><br>
<b><?php echo $konfirmasi; ?></b><br><br>
Atau Klik Link Ini:<br>
<?php echo base_url("user/c_konfirmasi/kode/$konfirmasi"); ?><br><br>

Silahkan Hubungi Sponsor Anda:<br><br>

Nama : <?php echo $namasponsor; ?><br>
Email : <?php echo $email; ?><br>
No. Telp : <?php echo $nohp; ?><br>