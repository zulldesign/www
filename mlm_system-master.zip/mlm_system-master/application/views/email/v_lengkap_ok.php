Terimakasih Tn/Ny. <?php echo $nama_lengkap_user?>, Telah Melengkapi Data Diri.<br>
<p>Ayo!! Tinggal Beberapa Langkah Lagi Untuk Sukses, Segera Aktifasi dan Upgrade Akun Anda Menjadi Member Resmi BMI Tiger Group<br>
Dan Dapatkan Website Replika Anda Yang Akan Membantu Kesuksesan Anda Secara Mudah dan Otomatis<br>
<strong>BAGAIMANA CARA UNTUK SUKSES?? </strong><br>Klik Link Di Bawah Ini :<br>
<a href="http://bmi-eksekutif.com/user/c_dashboard/MemberPages/cara-upgrade" target="_blank">http://bmi-eksekutif.com/user/c_dashboard/MemberPages/cara-upgrade</a><br><br>
Silahkan Hubungi Sponsor Anda:<br><br>

Nama : <?php echo $namasponsor; ?><br>
Email : <?php echo $email; ?><br>
No. Telp : <?php echo $nohp; ?><br>