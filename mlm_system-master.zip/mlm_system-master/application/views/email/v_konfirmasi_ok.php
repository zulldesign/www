Terimakasih Tn/Ny. <?php echo $datausername ?>, Atas Konfirmasi Anda.<br>
Akun Anda Telah Terkonfirmasi Silahkan Login, dan Lengkapi Data Diri,<br>
Informasi Login Anda :<br>
<br>Username : <strong><?php echo $datausername ?></strong><br>
Password : ~ Di Sembunyikan Untuk Keamanan ~<br>
Email : <strong><?php echo $dataemail ?></strong><br>
Link Login : <a href="http://bmi-eksekutif.com/user/c_login" target="_blank">Klik Di Sini</a><br>
Silahkan Hubungi Sponsor Anda:<br><br>

Nama : <?php echo $namasponsor; ?><br>
Email : <?php echo $email; ?><br>
No. Telp : <?php echo $nohp; ?><br>