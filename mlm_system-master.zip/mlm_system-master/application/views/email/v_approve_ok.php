Terimakasih Tn/Ny. <?php echo $nama_lengkap_user?>,<br>
<p>Anda Telah Melengkapi Selulur Administrasi, Kini Anda Resmi Menjadi Member dan Mitra Kerjasama BMI Tiger Group<br>Anda Berhak Mendapatkan Hak Jual dari Produk BMI dan juga Web Replika Milik Anda Telah Aktif, Ayo Beritahu Kerabat Serta Saudara Anda Dan Ikuti Langkah Sukses Anda.</p>
<br>Anda Mendapatkan Link Web Replika Gratis Dari Kami, Berikut kami lampirkan list link website anda, silahkan pergunakan untuk keperluan presentasi dan pemasaran produk anda :<br>
<li><a href="http://bmi-eksekutif.com/site/<?php echo $datausername;?>">http://bmi-eksekutif.com/site/<?php echo $datausername;?></a> (Web Bisnis Anda)
<?php foreach($website as $dtweb){ ?>
<li><a href="<?php echo $dtweb['link'];?>/site/<?php echo $datausername;?>" target="_blank"><?php echo $dtweb['link'];?>/site/<?php echo $datausername;?></a>
<?php } ?>
<br>
Regards,<br>
Leader BMI Tiger Group.<br><br>
Silahkan Hubungi Sponsor Anda:<br>

Nama : <?php echo $namasponsor; ?><br>
Email : <?php echo $email; ?><br>
No. Telp : <?php echo $nohp; ?><br>