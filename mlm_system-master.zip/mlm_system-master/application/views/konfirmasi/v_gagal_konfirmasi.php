<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link href="<?php echo base_url(); ?>/assets/css/bootstrap-responsive.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome.min.css" />

		<!--[if IE 7]>
		  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome-ie7.min.css" />
		<![endif]-->

		<!--page specific plugin styles-->

		<!--fonts-->

		<!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" /> -->
				
		<!--ace styles-->

		<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/ace.min.css" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/ace-responsive.min.css" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/ace-skins.min.css" />
	<title>KODE KONFIRMASI KOSONG ATAU SALAH</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<h1 class="center"><i class='icon-remove-sign red'></i><br>MOHON MAAF KODE KONFIRMASI<br>YANG ANDA MASUKAN SALAH!</h1>
	<br><center>
		<a href="<?php echo base_url("user/c_konfirmasi/"); ?>"><button class="btn btn-danger btn-small">
			<i class="icon-reply"></i>Kembali
		</button></a>
		</center>
</body>
</html>