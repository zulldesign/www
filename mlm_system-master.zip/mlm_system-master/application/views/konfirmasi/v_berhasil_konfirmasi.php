<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
		<link href="<?php echo base_url(); ?>/assets/css/bootstrap-responsive.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome.min.css" />

		<!--[if IE 7]>
		  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/font-awesome-ie7.min.css" />
		<![endif]-->

		<!--page specific plugin styles-->

		<!--fonts-->

		<!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" /> -->
				
		<!--ace styles-->

		<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/ace.min.css" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/ace-responsive.min.css" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/ace-skins.min.css" />
	<title>REGISTRASI BERHASIL</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<h1 class="center"><i class="icon-ok green"></i><br>REGISTRASI BERHASIL<br>SILAHKAN LOGIN</h1>
	<br><center>
		<a href="<?php echo base_url("user/c_login/"); ?>"><button class="btn green btn-small">
			<i class="icon-ok "></i>Login
		</button></a>
		</center>
</body>
</html>