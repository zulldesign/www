<!DOCTYPE html>
<html>
<head>
	<title>Belajar Membuat Login Multi Level - www.teziger.blogspot.com</title>
</head>
<link rel="stylesheet" type="text/css" href="style.css">
<body>
	<form method="post">
<?php
//Menghubungkan Ke Database
$host = 'localhost'; //Nama Host
$user = 'root'; //Nama User
$pass = ''; //Nama Password
$database = 'login'; //Nama Database

$db = mysqli_connect($host,$user,$pass,$database); //Mulai Hubungan

session_start(); //Menyalakan Session
if (!@$_SESSION['masuk']) { //Jika Belum Login Maka Tampilkan Halaman Login

	if (isset($_POST['masuk'])) { // Jika Pengakses Menekan Tombol Masuk
		$user = $_POST['username']; //Mengambil Hasil Input Pada Kolom Input Username
		$pass = $_POST['password']; //Mengambil Hasil Input Pada Kolom Input Password
		$level = $_POST['level']; //Mengambil Jenis Level Yang Dipilih

		if (empty($user) || empty($pass) || empty($level)) {
			echo "<center><div class='peringatan'>Semua Kolom Wajib Diisi!</div></center>";
		}

		if ($level == 'admin') { //Jika Pengakses Memilih Level Admin
			$query = mysqli_query($db, "SELECT*FROM tb_login WHERE level = 'admin' AND username = '$user' AND password = '$pass'"); //Mencari Data Pada Database
			$cek = mysqli_num_rows($query); //Cek Ketersediaan
			if ($cek > 0) { //Jika Tidak Kosong
				$_SESSION['masuk'] = $user; //Membuat Session
				header("location:./"); //Memuat Ulang Halaman
			}
			else{//Jika Kosong
			echo "<center><div class='peringatan'>Username Atau Password Untuk Level Admin Salah!</div></center>";
			}
		}
		elseif ($level == 'user') {
			$query = mysqli_query($db, "SELECT*FROM tb_login WHERE level = 'user' AND username = '$user' AND password = '$pass'"); //Mencari Data Pada Database
			$cek = mysqli_num_rows($query); //Cek Ketersediaan
			if ($cek > 0) { //Jika Tidak Kosong
				$_SESSION['masuk'] = $user; //Membuat Session
				header("location:./"); //Memuat Ulang Halaman
			}
			else{//Jika Kosong
			echo "<center><div class='peringatan'>Username Atau Password Untuk Level User Salah!</div></center>";
			}
		}
	}
?>
	<h1>Masuk</h1>
		<input type="text" name="username" placeholder="Username"><br>
		<input type="password" name="password" placeholder="Password"><br>
		<select name="level">
			<option value="">-PILIH LEVEL-</option>
			<option value="admin">Admin</option>
			<option value="user">User</option>
		</select><br>
		<input type="submit" name="masuk" value="Masuk">
	</form>
<?php
}
else{ //Jika Sudah Masuk Maka Tampilkan Halaman Utama
	$data = mysqli_fetch_array(mysqli_query($db, "SELECT*FROM tb_login WHERE username='$_SESSION[masuk]'")); //Mengambil Data Pengguna Yang Login
	if ($data['level'] == 'admin') { //Jika Yang Masuk Adalah Admin
		$konten = '<h1>Selamat Datang Admin <i>(@'.$data['username'].')</i>!</h1>Selamat Mengembangkan Website!';
	}
	else{ //Jika Yang Masuk Adalah User
		$konten = '<h1>Selamat Datang Pengguna Website <i>(@'.$data['username'].')</i>!</h1>';
	}
	$logout = "<a href='./?keluar=1'>Keluar</a>"; //Membuat Tombol Keluar
	
	if (isset($_GET['keluar'])) { //Jika Klik Tombol Keluar
	unset($_SESSION['masuk']); //Menghapus Session
	header("location:./"); //Memuat Ulang Halaman
	}

	echo $konten.'<br>'.$logout;
?>

<?php
}
?>
</body>
</html>