<?php
$con = new mysqli("localhost", "root", "adminadmin", "adspoint");
if ($con->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
?>