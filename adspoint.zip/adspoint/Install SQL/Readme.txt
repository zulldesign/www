Please import sql file first to install it correctly
Install ME.sql file in current folder for fresh installation





Last updated - 30th April 2015