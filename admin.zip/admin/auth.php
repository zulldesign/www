<?php
/*
Author: zulfahmyrizal
Website: https://www.zulfahmyrizal.ml/
*/
?>

<?php
session_start();
if(!isset($_SESSION["userid"])){
header("Location: login.php");
exit(); }
?>