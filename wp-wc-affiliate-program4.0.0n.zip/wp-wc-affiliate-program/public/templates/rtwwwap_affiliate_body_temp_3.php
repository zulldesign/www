<?php

$rtwwwap_extra_features = get_option( 'rtwwwap_extra_features_opt' );
$rtwwwap_decimal_place = $rtwwwap_extra_features['decimal_places'];
$rtwwwap_decimal_separator = isset($rtwwwap_extra_features['decimal_separator'])? $rtwwwap_extra_features['decimal_separator'] : '';
$rtwwwap_thousand_separator = isset($rtwwwap_extra_features['thousand__separator']) ? $rtwwwap_extra_features['thousand__separator'] : '';



if( RTWWWAP_IS_WOO == 1 ){
    $rtwwwap_currency_sym = esc_html( get_woocommerce_currency_symbol() );
}
else{
    require_once( RTWWWAP_DIR.'includes/rtwaffiliatehelper.php' );

    $rtwwwap_currency		= isset( $rtwwwap_extra_features[ 'currency' ] ) ? $rtwwwap_extra_features[ 'currency' ] : 'USD';
    $rtwwwap_curr_obj 		= new RtwAffiliateHelper();
    $rtwwwap_currency_sym 	= $rtwwwap_curr_obj->rtwwwap_curr_symbol( $rtwwwap_currency );
}
global $wpdb;

    $rtwwwap_user_id 			= get_current_user_id();
    $rtwwwap_user_name          =   wp_get_current_user();
    
//// overview tab

    $rtwwwap_total_referrals 	= $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(`id`) as total_referrals FROM ".$wpdb->prefix."rtwwwap_referrals WHERE `aff_id`=%d", $rtwwwap_user_id ) );
    $rtwwwap_pending_comm 		= $wpdb->get_var( $wpdb->prepare( "SELECT SUM(`amount`) FROM ".$wpdb->prefix."rtwwwap_referrals WHERE `aff_id`=%d AND `status`=%d AND `capped`!=%d", $rtwwwap_user_id, 0, 1 ) );
    $rtwwwap_approved_comm 		= $wpdb->get_var( $wpdb->prepare( "SELECT SUM(`amount`) FROM ".$wpdb->prefix."rtwwwap_referrals WHERE `aff_id`=%d AND `status`=%d", $rtwwwap_user_id, 1 ) );
    $rtwwwap_total_comm 		= $wpdb->get_var( $wpdb->prepare( "SELECT SUM(`amount`) FROM ".$wpdb->prefix."rtwwwap_referrals WHERE `aff_id`=%d AND `status`=%d", $rtwwwap_user_id, 2 ) );
    $rtwwwap_total_comm 		= $rtwwwap_total_comm+$rtwwwap_approved_comm;
    $rtwwwap_wallet 			= get_user_meta( $rtwwwap_user_id, 'rtw_user_wallet', true );
    $rtwwwap_wallet   			= isset($rtwwwap_wallet) ? $rtwwwap_wallet : '0';
    if($rtwwwap_wallet == '')
    {
        $rtwwwap_wallet = 0; 
    }

    $rtwwwap_user_id 			= get_current_user_id();
    $rtwwwap_theme = get_user_meta( $rtwwwap_user_id, 'rtwwwap_theme', true );
    $rtwwwap_theme_message = $rtwwwap_theme;

    if($rtwwwap_theme == "dark")
    {
     $rtwwwap_theme = "checked";
    }
    else {
        $rtwwwap_theme = "";
        
         }

        
$rtwwwap_html1 = '';
$rtwwwap_html1 .=	'
        <div class="rtwwwap-right-section">
            <div class="rtwwwap-top-bar">
                <div class="rtwwwap-top-bar-inner">
                    <div class="rtwwsm_sidebar_icon">
                         <i class="fas fa-bars"></i>
                    </div>
                    <label class="rtwwwap_switch">
                    <input type="checkbox" class="rtwwwap_theme_toggle" '.$rtwwwap_theme.'>
                    <span class="rtwwwap_slider rtwwwap_round"></span>
                    </label>';
                    if($rtwwwap_theme_message == "dark"){
                        $rtwwwap_html1 .=' <span class="rtwwwap_theme_message">'.esc_html__('Enable Lite Mode','rtwwsm-woocommerce-membership').'</span>';
                        }
                        else{
                        $rtwwwap_html1 .= '<span class="rtwwwap_theme_message">'.esc_html__('Enable Dark Mode','rtwwsm-woocommerce-membership').'</span>';
                        }
                        $rtwwwap_login_page_id = get_option('rtwwwap_login_page_id');
                        $rtwwwap_affiliate_page_id = get_option('rtwwwap_affiliate_page_id');
                        if($rtwwwap_login_page_id)
						{
							$redirect_url = get_permalink($rtwwwap_login_page_id);
						}
						else{
							$redirect_url = get_permalink($rtwwwap_login_page_id);
						}
                        $rtwwwap_html1 .=     '<div class="rtwwwap_logout">';
						$rtwwwap_html1 .=  		 '<a class="rtwwwap_logout_button" href='.wp_logout_url($redirect_url).'>
													<i class="fas fa-sign-out-alt"></i>
													<span class="rtwwwap_logout_text">logout</span></a>';
						$rtwwwap_html1 .=     '</div>';
                        $rtwwwap_html1 .=	' <div class="rtwwwap-login-user">
                        <a href="'.esc_url(site_url()).'"class="rtwwsm_back_to_wordpress rtwwsm_home_icon" ><span>'.esc_html__('Go Back To Home','rtwwsm-woocommerce-membership').'</span></a>
                        <a href="'.esc_url(site_url()).'"class=" rtwwsm_home_icon_mobile" ><i class="fas fa-home"></i></a>
                </div>
                
            </div>
            </div>';
        
$rtwwwap_html1 .=	'<div class="rtwwwap_hide" id="rtwwwap-overview-wrapper" >
                        <div class="mdc-layout-grid">
                            <div class="mdc-layout-grid__inner">
                                <div class="mdc-layout-grid__cell mdc-card rtwwwap-grid-cell rtwwwap-card1 mdc-elevation--z9">
                                    <div class="rtwwwap-inner-padding">
                                        <div class="rtwwap-card-text">
                                            <h6 class="rtwwwap_overview_card_head">'.esc_html__( 'Total Referrals', 'rtwwwap-wp-wc-affiliate-program' ).'</h6>
                                            <h5 class="rtwwwap_overview_card_number">'.sprintf( '<span>%u</span>', ( $rtwwwap_total_referrals ) ? $rtwwwap_total_referrals : '0').'</h5>
                                        </div>
                                        <div class="rtwwwap-card-icon">
                                        
                                        </div>
                                        <div class="rtwwwap-progress">
                                            <div class="rtwwwap-progress-bar" role="progressbar"></div>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="mdc-layout-grid__cell mdc-card rtwwwap-grid-cell mdc-elevation--z9 rtwwwap-card2">
                                    <div class="rtwwwap-inner-padding">
                                        <div class="rtwwap-card-text">
                                            <h6 class="rtwwwap_overview_card_head">'.esc_html__( 'Total Commission', 'rtwwwap-wp-wc-affiliate-program' ).'</h6>
                                            <h5 class="rtwwwap_overview_card_number">'.sprintf( '<span> '.$rtwwwap_currency_sym.number_format( $rtwwwap_total_comm,$rtwwwap_decimal_place,$rtwwwap_decimal_separator, $rtwwwap_thousand_separator)).'</h5>


                                        </div>
                                        <div class="rtwwwap-card-icon">
                                        
                                        </div>
                                        <div class="rtwwwap-progress">
                                            <div class="rtwwwap-progress-bar" role="progressbar"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mdc-layout-grid__cell mdc-card rtwwwap-grid-cell mdc-elevation--z9 rtwwwap-card3">
                                    <div class="rtwwwap-inner-padding">
                                        <div class="rtwwap-card-text">
                                            <h6 class="rtwwwap_overview_card_head">'.esc_html__( 'Wallet', 'rtwwwap-wp-wc-affiliate-program' ).'</h6>
                                            <h5 class="rtwwwap_overview_card_number">'.sprintf( '<span>'.$rtwwwap_currency_sym.number_format($rtwwwap_wallet,$rtwwwap_decimal_place,$rtwwwap_decimal_separator, $rtwwwap_thousand_separator)).'</h5>


                                        </div>
                                        <div class="rtwwwap-card-icon">
                                            
                                        </div>
                                        <div class="rtwwwap-progress">
                                            <div class="rtwwwap-progress-bar" role="progressbar"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mdc-layout-grid__cell mdc-card rtwwwap-grid-cell mdc-elevation--z9 rtwwwap-card4">
                                    <div class="rtwwwap-inner-padding">
                                        <div class="rtwwap-card-text">
                                            <h6 class="rtwwwap_overview_card_head">'.esc_html__( 'Approved Commission', 'rtwwwap-wp-wc-affiliate-program' ).'</h6>
                                            <h5 class="rtwwwap_overview_card_number">'.sprintf( '<span>'.$rtwwwap_currency_sym.number_format( $rtwwwap_approved_comm,$rtwwwap_decimal_place,$rtwwwap_decimal_separator, $rtwwwap_thousand_separator)).'</h5>

                                        </div>
                                        <div class="rtwwwap-card-icon">
                                            
                                        </div>
                                        <div class="rtwwwap-progress">
                                            <div class="rtwwwap-progress-bar" role="progressbar"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mdc-layout-grid__cell mdc-card rtwwwap-grid-cell mdc-elevation--z9 rtwwwap-card5">
                                    <div class="rtwwwap-inner-padding">
                                        <div class="rtwwap-card-text">
                                            <h6 class="rtwwwap_overview_card_head">'.esc_html__( 'Pending Commission', 'rtwwwap-wp-wc-affiliate-program' ).'</h6>
                                            <h5 class="rtwwwap_overview_card_number">'.sprintf( '<span>'.$rtwwwap_currency_sym.number_format( $rtwwwap_pending_comm,$rtwwwap_decimal_place,$rtwwwap_decimal_separator, $rtwwwap_thousand_separator)).'</h5>
                                        </div>
                                        <div class="rtwwwap-card-icon">
                                        
                                        </div>
                                        <div class="rtwwwap-progress">
                                            <div class="rtwwwap-progress-bar" role="progressbar"></div>
                                        </div>


                                    </div>
                                </div>
                            </div>

                            <div id="rtwwwap-chart-bar">
                                <canvas id="rtwwwap_status"></canvas>
                            </div>
                        </div>
                    </div>';

// / commission 
// ////// commission table 
$rtwwwap_commissions = get_option( 'rtwwwap_commission_settings_opt' );

if(RTWWWAP_IS_WOO == 1 )
{
    $rtwwwap_post_type = 'product';
}
if(RTWWWAP_IS_Easy == 1 )
{
    $rtwwwap_post_type = 'download';
}
$rtwwwap_html1 .= '<div class="rtwwwap_hide"  id="rtwwwap_commission_table">';
if( $rtwwwap_commissions && !empty( $rtwwwap_commissions ) ){
            $rtwwwap_commission_settings = get_option( 'rtwwwap_commission_settings_opt' );
            $rtwwwap_comm_base 	= isset( $rtwwwap_commission_settings[ 'comm_base' ] ) ? $rtwwwap_commission_settings[ 'comm_base' ] : '1';

        if( $rtwwwap_comm_base == 1 ){

$rtwwwap_html1 .= '
                    <div class="rtwwwap-text">
                        <h4>
                            <span> <i class="fas fa-retweet mr-1" aria-hidden="true"></i>';
                            $rtwwwap_html1 .= 		esc_html__( 'Commission on all Products', 'rtwwwap-wp-wc-affiliate-program' );

                            $rtwwwap_html1 .=	"  ";
                                if( $rtwwwap_commission_settings[ 'all_commission_type' ] == 'percentage' )
                            {
                                
                                    $rtwwwap_html1 .=		sprintf( '%u%s', esc_html(  $rtwwwap_commission_settings[ 'all_commission' ]), '%' );
                            }
                            else{
                        
                                $rtwwwap_html1 .=		sprintf( '%s%u', $rtwwwap_currency_sym, esc_html( $rtwwwap_commission_settings[ 'all_commission' ] ) );
                            }
$rtwwwap_html1 .=       	   '</span>
                        </h4>
                    </div>
                    <div class="rtwwwap-text">
                        <h4>
                            <span> <i class="fas fa-retweet mr-1" aria-hidden="true"></i> '.esc_html__( 'Per Product Commission', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                         </h4>
                    </div>
                    <div class="mdc-data-table">
                        <div class="mdc-data-table__table-container">
                             <table class="mdc-data-table__table" aria-label="Dessert calories" id="rtwwwap-commission-table1">
                                <thead>
                                    <tr class="mdc-data-table__header-row">
                                        <th class="mdc-data-table__header-cell mdc-data-table__header-cell--numeric" role="columnheader" scope="col">'.esc_html__( 'Product Name', 'rtwwwap-wp-wc-affiliate-program' ).'</th>

                                        <th class="mdc-data-table__header-cell mdc-data-table__header-cell--numeric" role="columnheader" scope="col">'.esc_html__( 'Percentage commission (%)', 'rtwwwap-wp-wc-affiliate-program' ).'
                                        </th>

                                        <th class="mdc-data-table__header-cell" role="columnheader" scope="col">'.esc_html__( "Fixed commission ($rtwwwap_currency_sym)", 'rtwwwap-wp-wc-affiliate-program' ).'</th>
                                    </tr>
                                </thead>
                                <tbody class="mdc-data-table__content">';
                                 foreach( $rtwwwap_commissions as $rtwwwap_key => $rtwwwap_value ){
                                            if( $rtwwwap_key == 'per_prod_mode' ){
                                                if( $rtwwwap_value == 1 ){
                                                    $rtwwwap_args = array(
                                                        'post_type'  => $rtwwwap_post_type,
                                                        'meta_query' => array(
                                                            array(
                                                                'key' => 'rtwwwap_percentage_commission_box',
                                                                'value'   => '',
                                                                'compare' => '!='
                                                            )
                                                        ),
                                                        'fields' 		=> 'ids',
                                                        'numberposts' 	=> -1
                                                    );
                                                }
                                                elseif( $rtwwwap_value == 2 ){
                                                    $rtwwwap_args = array(
                                                        'post_type'  => $rtwwwap_post_type,
                                                        'meta_query' => array(
                                                            array(
                                                                'key' => 'rtwwwap_fixed_commission_box',
                                                                'value'   => '',
                                                                'compare' => '!='
                                                            )
                                                        ),
                                                        'fields' 		=> 'ids',
                                                        'numberposts' 	=> -1
                                                    );
                                                }
                                                else{
                                                    $rtwwwap_args = array(
                                                        'post_type'  => $rtwwwap_post_type,
                                                        'meta_query' => array(
                                                            'relation' => 'OR',
                                                            array(
                                                                'key' => 'rtwwwap_percentage_commission_box',
                                                                'value'   => '',
                                                                'compare' => '!='
                                                            ),
                                                            array(
                                                                'key' => 'rtwwwap_fixed_commission_box',
                                                                'value'   => '',
                                                                'compare' => '!='
                                                            )
                                                        ),
                                                        'fields' 		=> 'ids',
                                                        'numberposts' 	=> -1
                                                    );
                                                }
                                                $rtwwwap_products 	 = get_posts( $rtwwwap_args );

                                            

                                                if( !empty( $rtwwwap_products ) ){
                                                    foreach( $rtwwwap_products as $rtwwwap_key1 => $rtwwwap_value1 ){
                                                        $rtwwwap_perc_comm 	= get_post_meta( $rtwwwap_value1, 'rtwwwap_percentage_commission_box', true );
                                                        $rtwwwap_fix_comm 	= get_post_meta( $rtwwwap_value1, 'rtwwwap_fixed_commission_box', true );
                                                        $rtwwwap_prod_name 	= get_the_title( $rtwwwap_value1 );
    $rtwwwap_html1 .=	            '<tr class="mdc-data-table__row">
                                        <td class="mdc-data-table__cell mdc-data-table__cell--numeric">'.
                                                        $rtwwwap_prod_name.'
                                        </td>
                                        <td class="mdc-data-table__cell mdc-data-table__cell--numeric">';            
                                            if( $rtwwwap_value == 1 || $rtwwwap_value == 3 ){
                                                    $rtwwwap_html1 .= 			esc_html( $rtwwwap_perc_comm );
                                                }
$rtwwwap_html1 .=                         '</td>
                                        <td class="mdc-data-table__cell">';
                                                        if( $rtwwwap_value == 2 || $rtwwwap_value == 3 ){
                                                            $rtwwwap_html1 .= 			esc_html( $rtwwwap_fix_comm );
                                                        }
$rtwwwap_html1 .=                           '</td>
                                    </tr>';
                                                    }
                                                }
                                            }     
                                        }     


$rtwwwap_html1 .=              '</tbody>
                            </table>
                        </div>
                    </div>';
                    foreach( $rtwwwap_commissions as $rtwwwap_key => $rtwwwap_value ){
                            if( $rtwwwap_key == 'per_cat' ){

$rtwwwap_html1 .=      '<div class="rtwwwap-text">
                        <h4>
                            <span> <i class="fas fa-retweet mr-1" aria-hidden="true"></i>'.	esc_html__( 'Per Category Commission' ).'</span>
                        </h4>
                    </div>
                        <div class="mdc-data-table">
                            <div class="mdc-data-table__table-container">   
                                <table class="mdc-data-table__table" aria-label="Dessert calories" id="rtwwwap-commission-table">            
                                    <thead>    
                                        <tr class="mdc-data-table__header-row">
                                            
                                            <th class="mdc-data-table__header-cell mdc-data-table__header-cell--numeric" role="columnheader" scope="col">'.esc_html__( 'Category Name', 'rtwwwap-wp-wc-affiliate-program' ).'</th>

                                            <th class="mdc-data-table__header-cell mdc-data-table__header-cell--numeric" role="columnheader" scope="col">'.esc_html__( 'Percentage commission (%)', 'rtwwwap-wp-wc-affiliate-program' ).'</th>
                                            
                                            <th class="mdc-data-table__header-cell" role="columnheader" scope="col">'. sprintf( '%s (%s)', esc_html__( "Fixed commission", 'rtwwwap-wp-wc-affiliate-program' ), esc_html( $rtwwwap_currency_sym ) ).'</th>
                                        </tr>
                                    </thead>
                                    <tbody class="mdc-data-table__content">';

                                        $rtwwwap_cat_count = 0;
                    
                                        foreach( $rtwwwap_value as $rtwwwap_key1 => $rtwwwap_value1 ){
                                            $rtwwwap_cat_name = '';
                                            foreach( $rtwwwap_value1[ 'ids' ] as $rtwwwap_key2 => $rtwwwap_value2 ){
                                                if( $rtwwwap_key2 > 0 ){
                                                    $rtwwwap_cat_name .= ', ';
                                                }
                                                if(RTWWWAP_IS_WOO == 1 )
                                                {
                                                $rtwwwp_product_category_taxonomy = 'product_cat';
                                                }
                                                if(RTWWWAP_IS_Easy == 1 )
                                                {
                                                $rtwwwp_product_category_taxonomy = 'download_category';
                                                }
                                                
                                                $rtwwwap_term 		= get_term_by( 'id', $rtwwwap_value2, $rtwwwp_product_category_taxonomy );
                                                $rtwwwap_cat_name .= $rtwwwap_term->name;
                                            }
                                            $rtwwwap_perc_comm 	= $rtwwwap_value1[ 'cat_percentage_commission' ];
                                            $rtwwwap_fix_comm 	= $rtwwwap_value1[ 'cat_fixed_commission' ];
                    
                                            if( $rtwwwap_cat_name != '' ){
                                                $rtwwwap_cat_count = 1;

$rtwwwap_html1 .=                      '<tr class="mdc-data-table__row">
                                        
                                             <td class="mdc-data-table__cell mdc-data-table__cell--numeric">'.esc_html( $rtwwwap_cat_name ).'</td>

                                             <td class="mdc-data-table__cell mdc-data-table__cell--numeric">'.esc_html( $rtwwwap_perc_comm ).'</td>

                                             <td class="mdc-data-table__cell">'.esc_html( $rtwwwap_fix_comm ).'</td>
                                        </tr>';

                                    }
                                    if( !$rtwwwap_cat_count ){
                                        $rtwwwap_html1 .= 	'<tr>';
                                        $rtwwwap_html1 .= 		'<td colspan="3" class="rtwwwap_no_comm">'.esc_html__( 'Specific Category commission not set.' ).'</td>';
                                        $rtwwwap_html1 .= 	'</tr>';
                                    }
                                }
$rtwwwap_html1 .=                   '</tbody>
                                </table>
                            </div>
                        </div>';
                     }
                }    
                                
            }
            else{
                $rtwwwap_levels_settings = get_option( 'rtwwwap_levels_settings_opt' );

        $rtwwwap_html1 .= '<div class="rtwwwap-text">
                                <h4>
                                    <span> <i class="fas fa-retweet mr-1" aria-hidden="true"></i>'.	esc_html__( 'Level Based Commission' ).'</span>
                                </h4>
                            </div>
                                <div class="mdc-data-table">
                                    <div class="mdc-data-table__table-container">   
                                        <table class="mdc-data-table__table" aria-label="Dessert calories" id="rtwwwap-commission-table">';  
        if( !empty( $rtwwwap_levels_settings ) )
        {
            $rtwwwap_html1 .= 	'<thead >';
            $rtwwwap_html1 .= 		'<tr class="mdc-data-table__header-row">';
            $rtwwwap_html1 .= 			'<th class="mdc-data-table__header-cell " role="columnheader" scope="col">';
            $rtwwwap_html1 .= 		 		esc_html__( 'Level No.','rtwwwap-wp-wc-affiliate-program' );
            $rtwwwap_html1 .= 			'</th>';
            $rtwwwap_html1 .= 			'<th class="mdc-data-table__header-cell " role="columnheader" scope="col">';
            $rtwwwap_html1 .= 		 		esc_html__( 'Level Name','rtwwwap-wp-wc-affiliate-program' );
            $rtwwwap_html1 .= 			'</th>';
            $rtwwwap_html1 .= 			'<th class="mdc-data-table__header-cell  " role="columnheader" scope="col">';
            $rtwwwap_html1 .= 		 		esc_html__( 'Level commission','rtwwwap-wp-wc-affiliate-program' );
            $rtwwwap_html1 .= 			'</th>';
            $rtwwwap_html1 .= 			'<th class="mdc-data-table__header-cell " role="columnheader" scope="col">';
            $rtwwwap_html1 .= 		 		esc_html__( 'To Reach','rtwwwap-wp-wc-affiliate-program' );
            $rtwwwap_html1 .= 			'</th>';
            $rtwwwap_html1 .= 		'</tr>';
            $rtwwwap_html1 .= 	'</thead>';

            $rtwwwap_html1 .= 	'<tbody class="mdc-data-table__content">';
            foreach( $rtwwwap_levels_settings as $rtwwwap_levels_key => $rtwwwap_levels_val )
            {
                $rtwwwap_html1 .= 		'<tr class="mdc-data-table__row">';
                $rtwwwap_html1 .= 			'<td class="mdc-data-table__cell ">';
                $rtwwwap_html1 .= 		 		esc_html( $rtwwwap_levels_key );
                $rtwwwap_html1 .= 			'</td>';

                $rtwwwap_html1 .= 			'<td class="mdc-data-table__cell mdc-data-table__cell--numeric">';
                $rtwwwap_html1 .= 		 		esc_html( $rtwwwap_levels_val[ 'level_name' ] );
                $rtwwwap_html1 .= 			'</td ">';

                $rtwwwap_html1 .= 			'<td class="mdc-data-table__cell mdc-data-table__cell--numeric">';
                if( $rtwwwap_levels_val[ 'level_commission_type' ] == '0' )
                {
                    $rtwwwap_html1 .= sprintf( '%s%s', esc_html( $rtwwwap_levels_val[ 'level_comm_amount' ] ), '%' );
                }
                elseif( $rtwwwap_levels_val[ 'level_commission_type' ] == '1' )
                {
                    $rtwwwap_html1 .= sprintf( '%s%01.'.$rtwwwap_decimal_place, $rtwwwap_currency_sym, esc_html( $rtwwwap_levels_val[ 'level_comm_amount' ] ) );
                }
                $rtwwwap_html1 .= 			'</td>';

                $rtwwwap_html1 .= 			'<td class="mdc-data-table__cell mdc-data-table__cell--numeric">';
                if( $rtwwwap_levels_val[ 'level_criteria_type' ] == 0 )
                {
                    $rtwwwap_html1 .= sprintf( '%s', esc_html__( 'Become Affiliate' ) );
                }
                elseif( $rtwwwap_levels_val[ 'level_criteria_type' ] == 1 )
                {
                    $rtwwwap_html1 .= sprintf( '%s %s', esc_html__( 'No. of referrals' ), esc_html__( $rtwwwap_levels_val[ 'level_criteria_val' ] ) );
                }
                elseif( $rtwwwap_levels_val[ 'level_criteria_type' ] == 2 )
                {
                    $rtwwwap_html1 .= sprintf( '%s %s%01.'.$rtwwwap_decimal_place, esc_html__( 'Total sale amount' ), $rtwwwap_currency_sym, esc_html__( $rtwwwap_levels_val[ 'level_criteria_val' ] ) );
                    ;
                }
                $rtwwwap_html1 .= 			'</td>';
                $rtwwwap_html1 .= 		'</tr>';
            }
            $rtwwwap_html1 .= 	'</tbody>';
        }
              $rtwwwap_html1 .= 	'</table>';
            $rtwwwap_html1 .= 	'</div>';
        $rtwwwap_html1 .= 	'</div>';
                
        }
                  
    }
    else{
        $rtwwwap_html1 .= 	'<div class="rtwwwap_commissionws_wrapper">';
        $rtwwwap_html1 .= 		esc_html__( 'No Commission is set on any Product', 'rtwwwap-wp-wc-affiliate-program' );
        $rtwwwap_html1 .= 		'<span>';
        $rtwwwap_html1 .= 	'</div>';
    }

    $rtwwwap_html1 .=	'             
    </div>
            ';  
   

// referral tabels
    $rtwwwap_date_format = get_option( 'date_format' );
    $rtwwwap_time_format = get_option( 'time_format' );
    $rtwwwap_user_all_referrals = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$wpdb->prefix."rtwwwap_referrals WHERE `aff_id` = %d ORDER BY `date` DESC", $rtwwwap_user_id ), ARRAY_A );
    $rtwwwap_html1 .=	'   
                        <div class="rtwwwap_hide"  id="rtwwwap_referral_table">   
                                <div class="rtwwwap-text">
                                    <h4>
                                        <span> <i class="fas fa-retweet mr-1" aria-hidden="true"></i> '.esc_html__( 'Referral Table Commission', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                    </h4>
                                </div>
                               
                                    <div class="rtwwwap_table_container">
                                    
                                        <table class="mdl-data-table" aria-label="Dessert calories" id="rtwwwap-refferral-table" >
                                                
                                            <thead>
                                            
                                            <tr>
                                                
                                                <th >'.	sprintf( '%s', esc_html__( 'Type', 'rtwwwap-wp-wc-affiliate-program' ) ).'</th>
                                                <th>'.	sprintf( '%s', esc_html__( 'Amount', 'rtwwwap-wp-wc-affiliate-program' ) ).'</th>
                                                <th>'.	sprintf( '%s', esc_html__( 'Date', 'rtwwwap-wp-wc-affiliate-program' ) ).'</th>
                                                <th>'.	sprintf( '%s', esc_html__( 'Status', 'rtwwwap-wp-wc-affiliate-program' ) ).'</th>
                                              
                                            </tr>
                                            </thead>
                                            <tbody >';
                                            foreach( $rtwwwap_user_all_referrals as $rtwwwap_user_ref_key => $rtwwwap_user_ref_value ){
                                                $rtwwwap_order_id = $rtwwwap_user_ref_value[ 'order_id'];
                                                if($rtwwwap_order_id)
                                                {
                                                $rtwwwap_product_details = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$wpdb->prefix."rtwwwap_referrals WHERE `order_id`= '%d' ", $rtwwwap_order_id ) );
                                                    
                                                    $rtwwwap_product_detail =  json_decode($rtwwwap_product_details[0]->product_details,true);
                                                    $rtwwwap_product = wc_get_product($rtwwwap_product_detail[0]['product_id']);
                                                    $rtwwwap_product_price = $rtwwwap_product_detail[0]['product_price'];
                                                    $rtwwwap_product_commission = $rtwwwap_product_detail[0]['prod_commission'];
                                
                                            
                                                }
    $rtwwwap_html1 .=                      '<tr>
                                                <td>';
                                                if( $rtwwwap_user_ref_value[ 'type' ] == 1 ){
                                                    $rtwwwap_html1 .=				sprintf( '%s', esc_html__( 'Signup Bonus', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                }
                                                elseif( $rtwwwap_user_ref_value[ 'type' ] == 2 ){
                                                    $rtwwwap_html1 .=				sprintf( '%s', esc_html__( 'Performance Bonus', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                }
                                                elseif( $rtwwwap_user_ref_value[ 'type' ] == 0 ){
                                                    $rtwwwap_html1 .=				sprintf( '%s', esc_html__( 'Referral Bonus', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                }
                                                elseif( $rtwwwap_user_ref_value[ 'type' ] == 4 ){
                                                    $rtwwwap_html1 .=				sprintf( '%s', esc_html__( 'MLM Bonus', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                }
                                                elseif( $rtwwwap_user_ref_value[ 'type' ] == 5 ){
                                                    $rtwwwap_html1 .=				sprintf( '%s', esc_html__( 'Sharing Bonus', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                }
                                                elseif( $rtwwwap_user_ref_value[ 'type' ] == 6 ){
                                                    $rtwwwap_html1 .=				sprintf( '%s', esc_html__( 'Manual Referral', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                }
                                                
                                                
                                                $rtwwwap_html1 .=  '</td>
                                                <td>';
                                                if( RTWWWAP_IS_WOO == 1 ){
                                                    $rtwwwap_html1 .=  			esc_html( get_woocommerce_currency_symbol( $rtwwwap_user_ref_value[ 'currency' ] ).number_format( $rtwwwap_user_ref_value[ 'amount' ],$rtwwwap_decimal_place,$rtwwwap_decimal_separator, $rtwwwap_thousand_separator ) );
                                                }
                                                else{
                                                    $rtwwwap_html1 .=			esc_html( $rtwwwap_curr_obj->rtwwwap_curr_symbol( $rtwwwap_user_ref_value[ 'currency' ] ).number_format( $rtwwwap_user_ref_value[ 'amount' ],$rtwwwap_decimal_place,$rtwwwap_decimal_separator, $rtwwwap_thousand_separator ) );
                                                }
                                                
                                                $rtwwwap_html1 .='</td>
                                                <td>';
                                                
                                                
                                                $rtwwwap_date_time_format = $rtwwwap_date_format.' '.$rtwwwap_time_format;
                                                $rtwwwap_local_date = get_date_from_gmt( date( 'Y-m-d H:i:s
                                                    ', strtotime( $rtwwwap_user_ref_value[ 'date' ] ) ), $rtwwwap_date_time_format );
                                                    $rtwwwap_html1 .= 				esc_html( $rtwwwap_local_date );
                                                
                                                    $rtwwwap_html1 .='</td>
                                                <td>';
                                                
                                                $rtwwwap_html1 .= 					'<div >';
                                                if( $rtwwwap_user_ref_value[ 'capped' ] == '0' ){
                                                    if( in_array( $rtwwwap_user_ref_value[ 'status' ], array( '0', '1' ) ) ){
                                                        if( $rtwwwap_user_ref_value[ 'status' ] == 0 ){
                                                            $rtwwwap_html1 .=					sprintf( '%s', esc_html__( 'Pending', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                        }
                                                        elseif( $rtwwwap_user_ref_value[ 'status' ] == 1 ){
                                                            $rtwwwap_html1 .=					sprintf( '%s', esc_html__( 'Approved', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                        }
                                                    }
                                                    elseif( $rtwwwap_user_ref_value[ 'status' ] == 2 ){
                                                        $rtwwwap_html1 .=					sprintf( '%s', esc_html__( 'Paid', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                    }
                                                    elseif( $rtwwwap_user_ref_value[ 'status' ] == 3 ){
                                                        $rtwwwap_html1 .=					sprintf( '%s', esc_html__( 'Rejected', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                        if($rtwwwap_user_ref_value[ 'message' ] != ''){
                                    
                                                            $rtwwwap_html1 .=       '<p><a class="rtwbma_edit_apntmnt" rel="modal:open" href="#rtwbma_popup_'.$rtwwwap_user_ref_value[ 'id' ].'">'.esc_html__( 'View Reason', 'rtwwwap-wp-wc-affiliate-program' ).'</a> </p>';
                                                            $rtwwwap_html1 .=       '<div> ';
                                                            $rtwwwap_html1 .=  			'<div id="rtwbma_popup_'.$rtwwwap_user_ref_value[ 'id' ].'" class="modal">';
                                                            $rtwwwap_html1 .=  				'<div class="rtwwwap_modal-content">';
                                                            $rtwwwap_html1 .=			'<a href="javascript:void(0);" rel="modal:close" class="rtwbma_close">'. esc_html__( "&#10060;", "rtwwwap-wp-wc-affiliate-program" ).'</a>';
                                                            $rtwwwap_html1 .=  						'<p>';
                                                            $rtwwwap_html1 .=  							sprintf( '%s', esc_html__($rtwwwap_user_ref_value[ 'message' ] , 'rtwwwap-wp-wc-affiliate-program' ) );
                                                            $rtwwwap_html1 .=  						'</p>';
                                                            $rtwwwap_html1 .=  				'</div>';
                                                            $rtwwwap_html1 .=  			'</div>';
                                                            $rtwwwap_html1 .=  		'</div>';
                                                           

                                    
                                                        };								
                                                    }
                                                }
                                                
                                                else{
                                                    $rtwwwap_html1 .=					sprintf( '%s', esc_html__( 'Capped', 'rtwwwap-wp-wc-affiliate-program' ) );
                                                }
                                                
                                                $rtwwwap_html1 .=  		'</div></td>';
                                             

                                                $rtwwwap_html1 .= '  </tr>';
                                            }
                                    
                    $rtwwwap_html1 .=  '  </tbody>
                                        </table>
                                    </div>
                                </div>';
                            $rtwwwap_html1 .= '<div class="rtwwwap_member_modal">';
                            $rtwwwap_html1 .= 	'<div class="rtwwwap_member_modal-content">';
                            $rtwwwap_html1 .= 			'<div class="rtwwwap_member_modal-header">';
                            $rtwwwap_html1 .= 					'<span class="rtwwwap_member_close">&times;</span>';
                            $rtwwwap_html1 .=  						'<h2 ><spam class="rtwwwap_member_heading">';
                            $rtwwwap_html1 .=  						 esc_html__("O","rtwwwap-wp-wc-affiliate-program"); 
                            $rtwwwap_html1 .=   				'</spam>';
                            $rtwwwap_html1 .=  esc_html__('rder','rtwwwap-wp-wc-affiliate-program');
                            $rtwwwap_html1 .= 	'<spam class="rtwwwap_member_heading">'.esc_html__("D","rtwwwap-wp-wc-affiliate-program").'</spam>';
                            
                            $rtwwwap_html1 .= esc_html__('etail','rtwwwap-wp-wc-affiliate-program'); 
                            $rtwwwap_html1 .= '</h2>';
                                    $rtwwwap_html1 .=  '</div>';
                                    $rtwwwap_html1 .=  '<div class="rtwwwap_member_modal-body">';
                                    $rtwwwap_html1 .= '	<table class="rtwwwap-profile-detail-table">';
                                    $rtwwwap_html1 .= 	'<tbody>';
                                    $rtwwwap_html1 .= 	'<tr>';
                                    $rtwwwap_html1 .= 		'<td >'.esc_html__( 'Product Name','rtwwwap-wp-wc-affiliate-program').'</td>';
                                    $rtwwwap_html1 .= 			'<td ><span id="rtwwwap_product_name"></span></td>';
                                                        
                                    $rtwwwap_html1 .= 	'<tr>';
                                    $rtwwwap_html1 .= 	'<tr>';
                                    $rtwwwap_html1 .= 		'<td >'.esc_html__( 'Product Price','rtwwwap-wp-wc-affiliate-program').'</td>';
                                    $rtwwwap_html1 .= 			'<td ><span id="rtwwwap_product_price"></span></td>';
                                                        
                                    $rtwwwap_html1 .= 	'<tr>';
                                    $rtwwwap_html1 .= 	'<tr>';
                                    $rtwwwap_html1 .= 		'<td >'.esc_html__( 'Commission Received','rtwwwap-wp-wc-affiliate-program').'</td>';
                                    $rtwwwap_html1 .= 			'<td ><span id="rtwwwap_commission_received"></span></td>';
                                                        
                                    $rtwwwap_html1 .= 	'<tr>';
                                    $rtwwwap_html1 .= 	'<tr>';
                                    $rtwwwap_html1 .= 		'<td >'.esc_html__( 'Payment Method','rtwwwap-wp-wc-affiliate-program').'</td>';
                                    $rtwwwap_html1 .= 			'<td ><span id="rtwwwap_payment_method"></span></td>';		
                                    $rtwwwap_html1 .= 	'<tr>';
                
                                    $rtwwwap_html1 .= 	'<tr>';
                                    $rtwwwap_html1 .= 		'<td >'.esc_html__( 'Order Status','rtwwwap-wp-wc-affiliate-program').'</td>';
                                    $rtwwwap_html1 .= 			'<td ><span id="rtwwwap_order_status"></span></td>';							
                                    $rtwwwap_html1 .= 	'<tr>';
                            
                            
                                                    
                                    $rtwwwap_html1 .= 		'</tbody>';
                                    $rtwwwap_html1 .= '</table>';
                                    $rtwwwap_html1 .= '</div>';
                                    $rtwwwap_html1 .= '<div class="rtwwwap_member_modal-footer">';
                                    $rtwwwap_html1 .= ' <button  class=" rtwwwap_close_button" >'.esc_html__('CLOSE','rtwwwap-wp-wc-affiliate-program').'</button>';
                            
                                    $rtwwwap_html1 .=  '</div>';
                                    $rtwwwap_html1 .= '</div>';
                                   
        $rtwwwap_html1 .= '</div>';



///coupon

        $rtwwwap_commission_settings = get_option( 'rtwwwap_commission_settings_opt' );
        $rtwwwap_is_coupon_activated = isset( $rtwwwap_commission_settings[ 'coupons' ] ) ? $rtwwwap_commission_settings[ 'coupons' ] : 0;
        $rtwwwap_coupons = get_user_meta( $rtwwwap_user_id, 'rtwwwap_coupons', true );
if( $rtwwwap_is_coupon_activated)
{
        $rtwwwap_html1 .= '
    <div class="rtwwwap_coupon_section rtwwwap_hide" id= "rtwwwap_coupon">
        <div class="rtwwwap_coupon_wrapper_row">
                <div class="rtwwwap-request-section">
                    <h4 class="rtwwwap-coupon-header">'.esc_html__( ' Create Coupon', 'rtwwwap-wp-wc-affiliate-program' ).'</h4>
                    <div class="mdc-card mdc-elevation--z9">
                        <div class="rtwwwap-msg-card">
                            <div class="rtwwwap-coupon-image">
                                <img src="'.esc_url( RTWWWAP_URL.'/assets/images/coupon.png' ).'" class="rtwwwap-img-fluid">
                            </div>';
                            if( $rtwwwap_is_coupon_activated && RTWWWAP_IS_WOO == 1 ){
                                $rtwwwap_min_amount_for_coupon = isset( $rtwwwap_commission_settings[ 'min_amount_for_coupon' ] ) ? $rtwwwap_commission_settings[ 'min_amount_for_coupon' ] : 0;
                                $rtwwwap_html1 .= 		'
                                <div class="rtwwwap_coupon_message_cart">';
                                    if( $rtwwwap_wallet >= $rtwwwap_min_amount_for_coupon ){
                                            $rtwwwap_html1 .= 		' <label class="mdc-text-field mdc-text-field--outlined">
                                            <input type="number" name="product_name" class="mdc-text-field__input" min="'.esc_attr( $rtwwwap_min_amount_for_coupon ).'" max="'.esc_attr( $rtwwwap_wallet ).'" id = "rtwwwap_coupon_amount">
                                            <div class="mdc-notched-outline mdc-notched-outline--upgraded">
                                                <div class="mdc-notched-outline__leading"></div>
                                                <div class="mdc-notched-outline__notch">
                                                <span class="mdc-floating-label"> '.esc_html__( ' Create Coupon', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                                </div>
                                                <div class="mdc-notched-outline__trailing"></div>
                                            </div>
                                        </label>';
                                    }
                                    else{
                                        $rtwwwap_html1 .=         '
                                    
                                    <p class="rtwwwap-coupon-text">'.esc_html__( 'You can create', 'rtwwwap-wp-wc-affiliate-program' ).' <span>'.esc_html__( 'Coupons', 'rtwwwap-wp-wc-affiliate-program' ).'</span>'.esc_html__( 'Once your Wallet amount is greater than', 'rtwwwap-wp-wc-affiliate-program' ).'                                                               <span>'.$rtwwwap_currency_sym . $rtwwwap_min_amount_for_coupon.'</span></p>';
                                    }

                                    $rtwwwap_html1 .= '      </div>
                                <div class="rtwwwap-create-btn">
                                    <a href="#rtwwwap_coupon" data-id="1" id="rtwwwap_create_coupon" class="mdc-button mdc-button--raised mdc-theme--primary mdc-ripple-upgraded">'.esc_html__( ' Create Coupon', 'rtwwwap-wp-wc-affiliate-program' ).'</a>
                                </div>';
                                    
                                    
                                       
                        
$rtwwwap_html1 .=     ' </div>';
$rtwwwap_html1 .=     '
                        </div>
                    </div>
                

                  

                ';

            }


                if( $rtwwwap_coupons && RTWWWAP_IS_WOO == 1){

                    $rtwwwap_html1 .=         '
                <div class="rtwwwap-coupon-table-wrapper" id="rtwwap_coupon_table">
            
                    <div class="rtwwwap-text">
                        <h4>
                            <span> <i class="fas fa-retweet mr-1"></i>'.esc_html__( 'Coupon Table', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                        </h4>
                    </div>
                   
                        <div class="mdc-card mdc-elevation--z9">
                            <table id="rtwwwap_coupon_table" class="mdl-data-table">
                                <thead>
                                    <tr>
                                        <th>'.esc_html__( 'Coupon', 'rtwwwap-wp-wc-affiliate-program' ).'</th>
                                        <th>'.esc_html__( 'Amount', 'rtwwwap-wp-wc-affiliate-program' ).'</th>
                                        </tr>
                                </thead>
                                <tbody>';
                                $rtwwwap_valid_coupon = true;
                                foreach( $rtwwwap_coupons as $rtwwwap_key => $rtwwwap_coupon_id ){
                                if( get_post_status( $rtwwwap_coupon_id ) == 'publish' ){
                                $rtwwwap_valid_coupon = false;
                                $rtwwwap_coupon = esc_html( get_the_title( $rtwwwap_coupon_id ) );
                                $rtwwwap_amount = esc_html( get_post_meta( $rtwwwap_coupon_id, 'coupon_amount', true ) )   ;
$rtwwwap_html1 .=         '             <tr>
                                        <td>'.sprintf( '%s', $rtwwwap_coupon ).'</td>
                                        <td>'.sprintf( '%u', $rtwwwap_amount ).'</td>
                                    </tr>';
                                if( $rtwwwap_valid_coupon ){
                                    $rtwwwap_html1 .= 			'<tr>';
                                    $rtwwwap_html1 .= 				'<td colspan="2">';
                                    $rtwwwap_html1 .= 					sprintf( '%s', esc_html__( 'No Coupons', 'rtwwwap-wp-wc-affiliate-program' ) );
                                    $rtwwwap_html1 .= 				'</td>';
                                    $rtwwwap_html1 .= 			'</tr>';
                                        }  
                                     }
                                 }

$rtwwwap_html1 .=         '      </tbody>
                            </table>
                        </div>
                </div>';
                }

$rtwwwap_html1 .=   '
        </div>
    </div>';
            }



// link generation 

$rtwwwap_user_name = wp_get_current_user();
$rtwwwap_user_name = $rtwwwap_user_name->data->user_login;
$rtwwwap_extra_features_opt 	= get_option( 'rtwwwap_extra_features_opt' );
$rtwwwap_social_share_setting 	= isset( $rtwwwap_extra_features_opt[ 'social_share' ] ) ? $rtwwwap_extra_features_opt[ 'social_share' ] : 0;
$rtwwwap_qr_code_setting 		= isset( $rtwwwap_extra_features_opt[ 'qr_code' ] ) ? $rtwwwap_extra_features_opt[ 'qr_code' ] : 0;
$rtwwwap_affiliate_slug 		= isset( $rtwwwap_extra_features_opt[ 'affiliate_slug' ] ) ? $rtwwwap_extra_features_opt[ 'affiliate_slug' ] : esc_html__( 'rtwwwap_aff', 'rtwwwap-wp-wc-affiliate-program' ) ;

$rtwwwap_html1 .=   '          <div class="rtwwwap-tools-section rtwwwap_hide" id="rtwwwap_generate_link">
<div class="rtwwwwap-social-image-div">
<img src="'.esc_url( RTWWWAP_URL.'/assets/images/Social-Media.png' ).'" class="rtwwwap-img-fluid">
</div>
                                        <h4>Generate Links</h4>
                                        <div class="rtwwwap-generate-link-box">
                                            <label class="mdc-text-field mdc-text-field--outlined rtwwwap-w-100">
                                                <input type="text" class="mdc-text-field__input" aria-labelledby="my-label-id"  id="rtwwwap_aff_link_input" placeholder="'.esc_attr__( 'Enter any product\'s URL from this website', 'rtwwwap-wp-wc-affiliate-program' ).'" value="'.esc_attr( home_url() ).'">
                                                <span class="mdc-notched-outline">
                                                    <span class="mdc-notched-outline__leading"></span>
                                                    <span class="mdc-notched-outline__notch">
                                                    <!-- <span class="mdc-floating-label" id="my-label-id">'.esc_html__( 'Your Name', 'rtwwwap-wp-wc-affiliate-program' ).'</span> -->
                                                    </span>
                                                    <span class="mdc-notched-outline__trailing"></span>
                                                </span>
                                            </label>
                                        </div>
                                        <div class="rtwwwap-copy-link-box">
                                        <p  id="rtwwwap_generated_link"></p>
                                        </div>
                                        <button class="mdc-button mdc-button--raised" id="rtwwwap_generate_button" data-rtwwwap_aff_id="'.esc_attr( get_current_user_id() ).'"  data-rtwwwap_aff_slug="'.$rtwwwap_affiliate_slug.'" data-rtwwwap_aff_name="'.esc_attr( $rtwwwap_user_name ).'">
                                            <span class="mdc-button__label">'.esc_html__( 'Generate link', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                        </button>
                                      
                                        <div class="rtwwwap_span_copied">
                                        <button class="mdc-button mdc-button--raised"  id="rtwwwap_copy_to_clip">
                                        <span class="mdc-button__label">Copy link</span>
                                    </button>
                                        <span id="rtwwwap_copy_tooltip_link">'.esc_html__( 'Copied', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                        </div>';

$rtwwwap_html1 .=	  	'<div class="rtwwwap_share_qr">';
    //social share
if( $rtwwwap_social_share_setting === 'on' ){
    $rtwwwap_twitter_img_url 	= esc_url( RTWWWAP_URL.'/assets/images/twitter-share.png' );
    $rtwwwap_facebook_img_url 	= esc_url( RTWWWAP_URL.'/assets/images/facebook-share.png' );
    $rtwwwap_mail_img_url 		= esc_url( RTWWWAP_URL.'/assets/images/mail-share.png' );
    $rtwwwap_whatsapp_img_url 	= esc_url( RTWWWAP_URL.'/assets/images/whatsapp-share.png' );
    $rtwwwap_html1 .=	  	'<div class="rtwwwap_social_share">';
    $rtwwwap_html1 .=	  		'<div class="rtwwwap_btn">';
    $rtwwwap_html1 .=	  			'<a class="twitter-share-button rtwwwap_twitter" href="javascript:void(0);">';
    $rtwwwap_html1 .=	  				'<img src="'.$rtwwwap_twitter_img_url.'">';
    $rtwwwap_html1 .=	  				esc_html__( 'Tweet', 'rtwwwap-wp-wc-affiliate-program' );
    $rtwwwap_html1 .=	  			'</a>';
    $rtwwwap_html1 .=	  		'</div>';
    $rtwwwap_html1 .=	  		'<a class="rtwwwap_fb_share" href="javascript:void(0);">';
    $rtwwwap_html1 .=	  			'<img src="'.$rtwwwap_facebook_img_url.'">';
    $rtwwwap_html1 .=	  			esc_html__( 'Facebook', 'rtwwwap-wp-wc-affiliate-program' );
    $rtwwwap_html1 .=	  		'</a>';
    $rtwwwap_html1 .=	  		'<a class="rtwwwap_mail_button" href="mailto:enteryour@addresshere.com?subject=Click on this link &body=Check%20this%20out:%20" rel="nofollow">';
    $rtwwwap_html1 .=	  			'<img src ="'.$rtwwwap_mail_img_url.'">';
    $rtwwwap_html1 .=	  			esc_html__( 'Mail', 'rtwwwap-wp-wc-affiliate-program' );
    $rtwwwap_html1 .=	  		'</a>';
    $rtwwwap_html1 .=	  		'<a class="rtwwwap_whatsapp_share" href="javascript:void(0);" data-action="share/whatsapp/share">';
    $rtwwwap_html1 .=	  			'<img src="'.$rtwwwap_whatsapp_img_url.'">';
    $rtwwwap_html1 .=	  			esc_html__( 'Whatsapp', 'rtwwwap-wp-wc-affiliate-program' );
    $rtwwwap_html1 .=	  		'</a>';
    $rtwwwap_html1 .=	  	'</div>';
}

    //qrcode
if( $rtwwwap_qr_code_setting ){
    $rtwwwap_html1 .=	'<div id="rtwwwap_qrcode_main"><a id="rtwwwap_qrcode"></a><a id="rtwwwap_download_qr" download><span class="rtwwwap_download_qr">'.esc_html__( 'Download QR', 'rtwwwap-wp-wc-affiliate-program' ).'</span></a></div>';
}

$rtwwwap_html1 .=	  	'</div>';                                          

$rtwwwap_html1 .=                           '</div>';
                              



//Report tab
$rtwwwap_user_referrals_links = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$wpdb->prefix."rtwwwap_referral_link WHERE `aff_id` = %d ORDER BY `id` DESC", $rtwwwap_user_id ), ARRAY_A );
$rtwwwap_total_order = $wpdb->get_results( $wpdb->prepare( "SELECT COUNT(`id`) as total_order, DATE(date) as date_wise FROM `".$wpdb->prefix."rtwwwap_referrals` WHERE `aff_id`=%d GROUP BY DATE(date_wise) ORDER BY `date` DESC", $rtwwwap_user_id ),ARRAY_A );



$rtwwwap_total_commission = $wpdb->get_results( $wpdb->prepare( "SELECT SUM(amount) as commission , DATE(date) as date_wise FROM `".$wpdb->prefix."rtwwwap_referrals` WHERE `aff_id`=%d AND `status`= %d OR `status`= %d  GROUP BY DATE(date_wise)"  , $rtwwwap_user_id, 1,2 ),ARRAY_A );


$rtwwwap_order_ids = $wpdb->get_results( $wpdb->prepare( "SELECT `order_id` as order_wise, DATE(date) as date_wise  FROM `".$wpdb->prefix."rtwwwap_referrals` WHERE `aff_id`=%d "  , $rtwwwap_user_id ),ARRAY_A );

$rtwwwap_order_id = array();

foreach ($rtwwwap_order_ids as $key => $value) {

    if(array_key_exists($value['date_wise'],$rtwwwap_order_id))
    {
            $rtwwwap_product_details = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$wpdb->prefix."rtwwwap_referrals WHERE `order_id`= '%d' ", $value["order_wise"] ) );
            $rtwwwap_product_detail =  json_decode($rtwwwap_product_details[0]->product_details,true);
            $rtwwwap_product = wc_get_product($rtwwwap_product_detail[0]['product_id']);
            $rtwwwap_product_price = $rtwwwap_product_detail[0]['product_price'];
            $rtwwwap_order_id[$value["date_wise"]][$value["order_wise"]] = $rtwwwap_product_price;
    }
    else {
        $rtwwwap_product_details = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$wpdb->prefix."rtwwwap_referrals WHERE `order_id`= '%d' ", $value["order_wise"] ) );
                                                                
        $rtwwwap_product_detail =  json_decode($rtwwwap_product_details[0]->product_details,true);
        $rtwwwap_product = wc_get_product($rtwwwap_product_detail[0]['product_id']);
        $rtwwwap_product_price = $rtwwwap_product_detail[0]['product_price'];

        $rtwwwap_order_id[$value["date_wise"]][$value["order_wise"]] =  $rtwwwap_product_price ;
        
    }
}

$rtwwwap_total_sales = array();

foreach($rtwwwap_order_id as $key => $value)
{
    $total= 0;
    foreach($value as $key1 => $value1)
    {
        
        $total +=  $value1;
    }
        $rtwwwap_total_sales[ $key] = $total; 
}


$rtwwap_commision = array();
foreach ($rtwwwap_total_commission as $key => $value) {
    $rtwwap_commision[(string)$value["date_wise"]] = $value["commission"];
}
    $rtwwwap_html1 .=         '
    
    <div class="rtwwwap_hide" id="rtwwwap_report_section">
    <div class="mdc-tab-bar" role="tablist">
    <div class="mdc-tab-scroller">
    <div class="mdc-tab-scroller__scroll-area mdc-tab-scroller__scroll-area--scroll">
    <div class="mdc-tab-scroller__scroll-content">
    <button class="mdc-tab mdc-tab--active rtwwwap_car_width rtwwwap_link_table" role="tab" aria-selected="true" tabindex="0">
    <span class="mdc-tab__content">
    <span class="mdc-tab__icon material-icons" aria-hidden="true">'.esc_html__( 'report', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
    <span class="mdc-tab__text-label">'.esc_html__( 'Report Wise', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
    </span>
    <span class="mdc-tab-indicator mdc-tab-indicator--active">
    <span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span>
    </span>
    <span class="mdc-tab__ripple mdc-ripple-upgraded"></span>
    </button>
    <button class="mdc-tab rtwwwap_car_width rtwwwap_date_wise" role="tab" aria-selected="false" tabindex="-1">
    <span class="mdc-tab__content">
    <span class="mdc-tab__icon material-icons" aria-hidden="true">'.esc_html__( 'date_range', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
    <span class="mdc-tab__text-label">'.esc_html__( 'Day Wise', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
    </span>
    <span class="mdc-tab-indicator">
    <span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span>
    </span><span class="mdc-tab__ripple mdc-ripple-upgraded"></span>
    </button>
    </div>
    </div>
    </div>
    </div>
                   



                <div class="rtwwwap_main_part_display">

                    <div class="rtwwwap_report_tab_date">
                
                        <div class="rtwwwap-text">
                            <h4>
                                <span> <i class="fas fa-retweet mr-1"></i> '.esc_html__( 'Report Table', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                            </h4>
                        </div>
            

                        <div class="mdc-card mdc-elevation--z9">
                            <table id="rtwwwap_report_date_wise" class="mdl-data-table">
                                <thead>';
                    
                                $rtwwwap_html1 .= 			'<tr>';
                                $rtwwwap_html1 .= 				'<th>';
                                $rtwwwap_html1 .= 					sprintf( '%s', esc_html__( 'Total Order', 'rtwwwap-wp-wc-affiliate-program' ) );
                                $rtwwwap_html1 .= 				'</th>';
                                $rtwwwap_html1 .= 				'<th>';
                                $rtwwwap_html1 .= 					sprintf( '%s (%s)', esc_html__( 'Date', 'rtwwwap-wp-wc-affiliate-program' ), $rtwwwap_currency_sym );
                                $rtwwwap_html1 .= 				'</th>';
                                $rtwwwap_html1 .= 				'<th>';
                                $rtwwwap_html1 .= 					sprintf( '%s', esc_html__( 'Total Coomission earned ', 'rtwwwap-wp-wc-affiliate-program' ) );
                                $rtwwwap_html1 .= 				'</th>';
                                $rtwwwap_html1 .= 				'<th>';
                                $rtwwwap_html1 .= 					sprintf( '%s', esc_html__( 'Total Sales amount ', 'rtwwwap-wp-wc-affiliate-program' ) );
                                $rtwwwap_html1 .= 				'</th>';
                                $rtwwwap_html1 .= 			'</tr>';
                                $rtwwwap_html1 .=            ' </thead>
                                <tbody>';

                                $rtwwwap_from_name 		= esc_html( get_bloginfo( 'name' ) );
                                $rtwwwap_from_email 	= esc_html( get_bloginfo( 'admin_email' ) );
                                
                                foreach($rtwwwap_total_order as $key => $value)    
                                {
                             
                                    $rtwwwap_html1 .= 		'<tr>';
                                    $rtwwwap_html1 .= 			'<td>'.(int)$value['total_order'].'</td>';
                                    $rtwwwap_html1 .= 			'<td>'. $value['date_wise'].'</td>';
                                    if(array_key_exists($value['date_wise'],$rtwwap_commision)){
                                        $rtwwwap_html1 .= 			'<td>'.wc_price( $rtwwap_commision[$value['date_wise']]).'</td>';
                                    }else{
                                        $rtwwwap_html1 .= 			'<td>'. wc_price(0).'</td>';
                                    }

                                    if(array_key_exists($value['date_wise'],$rtwwwap_total_sales)){
                                        $rtwwwap_html1 .= 			'<td>'.wc_price( $rtwwwap_total_sales[$value['date_wise']]).'</td>';
                                    }else{
                                        $rtwwwap_html1 .= 			'<td>'. wc_price(0).'</td>';
                                    }
                                    $rtwwwap_html1 .= 		'</tr>';                                
                                }
                        

                    $rtwwwap_html1 .=                     ' </tbody>
                            </table>
                        
                        </div>

                    </div>

                    <div class="rtwwwap_report_tab">
                        <div class="rtwwwap-text">
                            <h4>
                                <span> <i class="fas fa-retweet mr-1"></i>'.esc_html__( 'Report Table', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                            </h4>
                        </div>
                

                            <div class="mdc-card mdc-elevation--z9">
                                <table id="rtwwwap_report_sec_table" class="mdl-data-table">
                                    <thead>';
                                    $rtwwwap_html1 .= 			'<tr>';
                                    $rtwwwap_html1 .= 				'<th>';
                                    $rtwwwap_html1 .= 					sprintf( '%s', esc_html__( 'Link', 'rtwwwap-wp-wc-affiliate-program' ) );
                                    $rtwwwap_html1 .= 				'</th>';
                                    $rtwwwap_html1 .= 				'<th>';
                                    $rtwwwap_html1 .= 					sprintf( '%s (%s)', esc_html__( 'Number of Hits', 'rtwwwap-wp-wc-affiliate-program' ), $rtwwwap_currency_sym );
                                    $rtwwwap_html1 .= 				'</th>';
                                    $rtwwwap_html1 .= 				'<th>';
                                    $rtwwwap_html1 .= 					sprintf( '%s', esc_html__( 'Purchase Done', 'rtwwwap-wp-wc-affiliate-program' ) );
                                    $rtwwwap_html1 .= 				'</th>';
                                    $rtwwwap_html1 .= 			'</tr>';
                                    $rtwwwap_html1 .=            ' </thead>
                                    <tbody>';

                
                                    
                                    
                                    foreach($rtwwwap_user_referrals_links as $key => $value)
                                    {
                                    $rtwwwap_html1 .= 		'<tr>';
                                    $rtwwwap_html1 .= 			'<td>'.$value['aff_link'].'</td>';
                                    $rtwwwap_html1 .= 			'<td>'.$value['link_open'].'</td>';
                                    $rtwwwap_html1 .= 			'<td>'.$value['link_purchase'].'</td>';
                                    $rtwwwap_html1 .= 		'</tr>';
                                    }
                                    


                        $rtwwwap_html1 .=                     ' </tbody>
                                </table>
                            </div>
                                <div class="report_chart">
                                    <div id="rtwwwap_report_line_chart">
                                            <canvas id="rtwwwap_report"></canvas>
                                    </div>
                                </div>
                     </div>
            </div>
    </div>';





// Download Tab start 

if(RTWWWAP_IS_WOO == 1)
{
$rtwwwap_all_categories = get_categories( array(
    'hide_empty' 	=> 0,
    'taxonomy'   	=> 'product_cat'
));
}
// display download categories
if(RTWWWAP_IS_Easy == 1)
{
    $rtwwwap_all_categories = get_categories( array(
    'hide_empty' 	=> 0,
    'taxonomy'   	=> 'download_category'
));
}



$rtwwwap_html1 .= ' <div class="rtwwwap-download-wrapper mdc-layout-grid rtwwwap_hide" id="rtwwwap_download_tab">';
                           

$rtwwwap_html1 .=	   	'<select class="rtwwwap_select_cat" id="" name="rtwwwap_select_cat" data-action="" data-exclude="">';
if( !empty( $rtwwwap_all_categories ) ){
    $rtwwwap_html1 .=	'<option value="" >';
    $rtwwwap_html1 .=		esc_html__( 'Select Category', 'rtwwwap-wp-wc-affiliate-program' );
    $rtwwwap_html1 .= 	'</option>';
    foreach ( $rtwwwap_all_categories as $rtwwwap_key => $rtwwwap_category ) {
        $rtwwwap_html1 .=	'<option value="'.esc_attr( $rtwwwap_category->cat_ID ).'" >';
        $rtwwwap_html1 .=		esc_html( $rtwwwap_category->cat_name );
        $rtwwwap_html1 .= 	'</option>';
    }
}
else{
    $rtwwwap_html1 .=	'<option value="" >';
    $rtwwwap_html1 .=		esc_html__( 'No Category', 'rtwwwap-wp-wc-affiliate-program' );
    $rtwwwap_html1 .= 	'</option>';
}
$rtwwwap_html1 .=	  	'</select>';
$rtwwwap_html1 .=	    '        <button class="mdc-button mdc-button--raised" id="rtwwwap_generate_csv"">
                        <span class="mdc-button__label">Generate CSV</span>
                    </button>';
$rtwwwap_html1 .= 	'</div>';
                        
          
// payout tab
  

$rtwwwap_referral_mail 	= get_user_meta( $rtwwwap_user_id, 'rtwwwap_referral_mail', true );
$rtwwwap_payment_method = get_user_meta( $rtwwwap_user_id, 'rtwwwap_payment_method', true );
$rtwwwap_paypal_email 	= get_user_meta( $rtwwwap_user_id, 'rtwwwap_paypal_email', true );
$rtwwwap_stripe_email 	= get_user_meta( $rtwwwap_user_id, 'rtwwwap_stripe_email', true );
$rtwwwap_direct_details = get_user_meta( $rtwwwap_user_id, 'rtwwwap_direct', true );

$rtwwwap_commission_settings = get_option( 'rtwwwap_commission_settings_opt' );
$rtwwwap_comm_base = isset( $rtwwwap_commission_settings[ 'comm_base' ] ) ? $rtwwwap_commission_settings[ 'comm_base' ] : '1';

$rtwwwap_admin_paypal 	= isset( $rtwwwap_extra_features[ 'activate_paypal' ] ) ? $rtwwwap_extra_features[ 'activate_paypal' ] : 0;
$rtwwwap_admin_stripe 	= isset( $rtwwwap_extra_features[ 'activate_stripe' ] ) ? $rtwwwap_extra_features[ 'activate_stripe' ] : 0;
$rtwwwap_level_name = '';
if( $rtwwwap_comm_base == 2 )
{
    $rtwwwap_levels_settings 	= get_option( 'rtwwwap_levels_settings_opt' );
    if( !empty( $rtwwwap_levels_settings ) )
    {
        $rtwwwap_user_level 	= get_user_meta( $rtwwwap_user_id, 'rtwwwap_affiliate_level', true );
        $rtwwwap_user_level 	= ( $rtwwwap_user_level ) ? $rtwwwap_user_level : 0;
        $rtwwwap_level_name 	= $rtwwwap_levels_settings[ $rtwwwap_user_level ][ 'level_name' ];
        $rtwwwap_level_comm 	= $rtwwwap_levels_settings[ $rtwwwap_user_level ][ 'level_comm_amount' ];
        $rtwwwap_level_comm_type = $rtwwwap_levels_settings[ $rtwwwap_user_level ][ 'level_commission_type' ];

        if( $rtwwwap_level_comm_type == 0 ){
            $rtwwwap_level_comm_type = '%';
        }
        elseif( $rtwwwap_level_comm_type == 1 ){
            $rtwwwap_level_comm_type = $rtwwwap_currency_sym;
        }
    }
}

$rtwwwap_user_name       =          wp_get_current_user();

$rtwwwap_referral_code_active = isset( $rtwwwap_extra_features[ 'signup_bonus_type' ] ) ? $rtwwwap_extra_features[ 'signup_bonus_type' ] : 0;
$rtwwwap_user_name 		= $rtwwwap_user_name->data->user_login;


$rtwwwap_referral_code 	= $rtwwwap_user_name.'_'.$rtwwwap_user_id;

$rtwwwap_html1 .=	'   
                            
                                <!-- payout section start -->
                                <div class=" mdc-layout-grid rtwwwap-payout-card-section  rtwwwap_hide" id="rtwwwap_payout_tab">
                                    ';
                                 if( $rtwwwap_referral_code_active ){
                                 
$rtwwwap_html1 .=                  '<div id="rtwwwap_refferal-code-box">
                                        <span class="rtwwwap_referral_span">'.esc_html__( 'Your Referral Code : ', 'rtwwwap-wp-wc-affiliate-program' ).'</span><span>'.$rtwwwap_referral_code.'</span>
                                    </div>';

                                    }
$rtwwwap_html1 .=                  '<div class="mdc-layout-grid__inner">';

                                    if( $rtwwwap_comm_base == 2 && $rtwwwap_level_name != '' ){
                
$rtwwwap_html1 .=	'                    <div class="mdc-layout-grid__cell mdc-card rtwwwap-payout-grid-cell mdc-elevation--z9">
                                            <div class="rtwwwap-inner-padding ">
                                                <div class="rtwwwap-card-progress-wrapper-row">
                                                    <div class="rtwwwap-card-number">
                                                        <span>'.esc_html__( 'Your Affiliate Level', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                                    </div>
                                                    <div class="rtwwwap-progress">
                                                        <div class="rtwwwap-progress-bar  rtwwwap_progress1" role="progressbar"></div>
                                                    </div>
                                                </div>
                                                <div class="rtwwwap-card-text">
                                                    <p>'.esc_html__( $rtwwwap_level_name, "rtwwwap-wp-wc-affiliate-program" ).'</p>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <div class="mdc-layout-grid__cell mdc-card rtwwwap-payout-grid-cell mdc-elevation--z9">
                                        <div class="rtwwwap-inner-padding">
                                            <div class="rtwwwap-card-progress-wrapper-row">
                                                <div class="rtwwwap-card-number">
                                                    <span>'.esc_html__( 'Your Commission Level', 'rtwwwap-wp-wc-affiliate-program' ).'</span>	
                                                </div>
                                                <div class="rtwwwap-progress">
                                                    <div class="rtwwwap-progress-bar rtwwwap_progress2" role="progressbar"></div>
                                                </div>
                                            </div>
                                            <div class="rtwwwap-card-text">
                                                <p>'.sprintf( '%s%s', esc_html( $rtwwwap_level_comm ), esc_html( $rtwwwap_level_comm_type ) ).'</p>
                                            </div>
                                        </div>
                                    </div>';
                                    }
                    
$rtwwwap_html1 .=	 '                  <div class="mdc-layout-grid__cell mdc-card rtwwwap-payout-grid-cell mdc-elevation--z9">
                                            <div class="rtwwwap-inner-padding">
                                                <div class="rtwwwap-referral-row">
                                                    <div class="rtwwwap-refferal-card-text rtwwwap-card-number">'.esc_html__( 'Activate Refferral Emails', 'rtwwwap-wp-wc-affiliate-program' ).'</div>
                                                    <div class="mdc-touch-target-wrapper">
                                                        <div class="mdc-checkbox mdc-checkbox--touch">';

                                                        if( isset( $rtwwwap_referral_mail ) && $rtwwwap_referral_mail == "true" ){
                                                            $rtwwwap_html1 .=	 ' <input type="checkbox"
                                                                    class="mdc-checkbox__native-control"
                                                                    id="rtwwwap_referral_email" checked="checked"/>';
                                                        }
                                                        else{
                                                            $rtwwwap_html1 .=	 ' <input type="checkbox"
                                                            class="mdc-checkbox__native-control"
                                                            id="rtwwwap_referral_email" />';
                                                        }
                                                        
$rtwwwap_html1 .=	 '                                  <div class="mdc-checkbox__background">
                                                            <svg class="mdc-checkbox__checkmark"
                                                                    viewBox="0 0 24 24">
                                                                <path class="mdc-checkbox__checkmark-path"
                                                                    fill="none"
                                                                    d="M1.73,12.91 8.1,19.28 22.79,4.59"/>
                                                            </svg>
                                                            <div class="mdc-checkbox__mixedmark"></div>
                                                            </div>
                                                            <div class="mdc-checkbox__ripple"></div>
                                                        </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mdc-layout-grid__cell mdc-card rtwwwap-payout-grid-cell mdc-elevation--z9">
                                            <div class="rtwwwap-inner-padding">
                                                <div class="rtwwwap-referral-row">
                                                    <div class="rtwwwap-refferal-card-text rtwwwap-card-number">'.esc_html__( 'Select payment method :', 'rtwwwap-wp-wc-affiliate-program' ).'</div>
                                                    <div class="rtwwwap_select_wrapper">
                                                        <div>';
                                                        
    $rtwwwap_html1 .=	 '                                  <div>';
                                                                
                                    $rtwwwap_html1 .= 			'<select class="rtwwwap_payment_method" name="rtwwwap_payment_method">';
                                    $rtwwwap_html1 .=				'<option value="rtwwwap_payment_not">';
                                    $rtwwwap_html1 .=					esc_html__( 'Select payment Method', 'rtwwwap-wp-wc-affiliate-program' );
                                    $rtwwwap_html1 .= 				'</option>';
                                    $rtwwwap_html1 .=				'<option value="rtwwwap_payment_direct" '.selected( $rtwwwap_payment_method, 'rtwwwap_payment_direct', false ).'>';
                                    $rtwwwap_html1 .=					esc_html__( 'Direct Bank', 'rtwwwap-wp-wc-affiliate-program' );
                                    $rtwwwap_html1 .= 				'</option>';

                                    if( $rtwwwap_admin_paypal ){
                                        $rtwwwap_html1 .=			'<option value="rtwwwap_payment_paypal" '.selected( $rtwwwap_payment_method, 'rtwwwap_payment_paypal', false ).'>';
                                        $rtwwwap_html1 .=				esc_html__( 'Paypal', 'rtwwwap-wp-wc-affiliate-program' );
                                        $rtwwwap_html1 .= 			'</option>';
                                    }

                                    if( $rtwwwap_admin_stripe ){
                                        $rtwwwap_html1 .=			'<option value="rtwwwap_payment_stripe" '.selected( $rtwwwap_payment_method, 'rtwwwap_payment_stripe', false ).'>';
                                        $rtwwwap_html1 .=				esc_html__( 'Stripe', 'rtwwwap-wp-wc-affiliate-program' );
                                        $rtwwwap_html1 .= 			'</option>';
                                    }

                                    $rtwwwap_html1 .=	  		'</select>
                                                            </div>
                                                                
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <section class="rtwwwap-_payemrnt_method_section">
                                    <form method="post">
                                        <div class="rtwwwap_payment_main_wrapper">
                                            <div class="rtwwwap-request-section">
                                                <h3 class="rtwwwap-payment-header">'.esc_html__( 'Request for Withdraw', 'rtwwwap-wp-wc-affiliate-program' ).'</h3>
                                                <div class="mdc-card mdc-elevation--z9">
                                                    <div class="rtwwwap-msg-card">
                                                        <div class="rtwwwap-withdra-image">
                                                            <img src="'.esc_url( RTWWWAP_URL.'/assets/images/download.jpeg' ).'">
                                                        </div>
                                                    
                                                        <span>
                                                            <label class="mdc-text-field  mdc-text-field--textarea mdc-text-field--no-label rtwwwap-w-100">
                                                                <textarea class=" mdc-text-field__input rtwwwap_privacy_policy_content rtwwwap_request_msg rtwwwap_request_msg"  aria-label="Label" placeholder="'.esc_attr__( 'Enter Your Message for Commission to Admin', 'rtwwwap-wp-wc-affiliate-program' ).'" ></textarea>
                                                                <span class="mdc-notched-outline mdc-notched-outline--no-label">
                                                                    <span class="mdc-notched-outline__leading"></span>
                                                                    <span class="mdc-notched-outline__trailing"></span>
                                                                </span>
                                                            </label>
                                                            <div class="rtwwwap-send-mail-btn rtwwwap-create-btn" id="rtwwwap_rqst_mail">
                                                                <span id="rtwwwap-send-mail" class="mdc-button mdc-button--raised mdc-theme--primary mdc-ripple-upgraded" >'.esc_html__( 'Send', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                                            </div>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="rtwwwap-payment-method-wrapper">
                                                <h3 class="rtwwwap-payment-header">Select payment method</h3>
                                                <div class="mdc-card mdc-elevation--z9">
                                                    <div class="mdc-tab-bar" role="tablist">
                                                        <div class="mdc-tab-scroller">
                                                            <div class="mdc-tab-scroller__scroll-area mdc-tab-scroller__scroll-area--scroll" style="margin-bottom: 0px;">
                                                                <div class="mdc-tab-scroller__scroll-content rt">
                                                                    <span class="mdc-tab mdc-tab--stacked mdc-tab--active" role="tab" aria-selected="true" tabindex="0" id="rtwwwap-btn-1">
                                                                        <span class="mdc-tab__content">
                                                                            <i class="fas fa-university mdc-tab__icon"></i>
                                                                            <span class="mdc-tab__text-label">'.esc_html__( 'Direct bank', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                                                            <span class="mdc-tab-indicator mdc-tab-indicator--active">
                                                                                <span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span>
                                                                            </span>
                                                                        </span>
                                                                        <span class="mdc-tab__ripple mdc-ripple-upgraded"></span>
                                                                    </span>
                                                                    <span class="mdc-tab mdc-tab--stacked" role="tab" aria-selected="false" tabindex="-1" id="rtwwwap-btn-2">
                                                                        <span class="mdc-tab__content">
                                                                            <i class="fab fa-paypal mdc-tab__icon "></i>
                                                                            <span class="mdc-tab__text-label">'.esc_html__( 'Paypal', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                                                            <span class="mdc-tab-indicator">
                                                                                <span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span>
                                                                            </span>
                                                                        </span>
                                                                        <span class="mdc-tab__ripple mdc-ripple-upgraded"></span>
                                                                    </span>
                                                                    <span class="mdc-tab mdc-tab--stacked" role="tab" aria-selected="false" tabindex="-1" id="rtwwwap-btn-3">
                                                                        <span class="mdc-tab__content">
                                                                            <i class="fab fa-stripe-s mdc-tab__icon"></i>
                                                                        <span class="mdc-tab__text-label">'.esc_html__( 'Stripe', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                                                            <span class="mdc-tab-indicator">
                                                                                <span class="mdc-tab-indicator__content mdc-tab-indicator__content--underline"></span>
                                                                            </span>
                                                                        </span>
                                                                        <span class="mdc-tab__ripple mdc-ripple-upgraded"></span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="rtwwwap-payment-content-box">
                                                        <div class="rtwwwap-bank-deatil rtwwwap-content-active-tab">
                                                            <h4>'.esc_html__( 'Bank Account Deatils', 'rtwwwap-wp-wc-affiliate-program' ).'</h4>
                                                            
                                                                <div class="rtwwwap-input-padding">
                                                                <label class="mdc-text-field  mdc-text-field--textarea mdc-text-field--no-label rtwwwap-w-100">
                                                                <textarea class=" mdc-text-field__input rtwwwap_privacy_policy_content" aria-label="Label" placeholder="'.esc_html__( 'Enter Your Message for Commission to Admin', 'rtwwwap-wp-wc-affiliate-program' ).'" id="rtwwwap_direct"> '.	$rtwwwap_direct_details.'</textarea>
                                                                <span class="mdc-notched-outline mdc-notched-outline--no-label">
                                                                    <span class="mdc-notched-outline__leading"></span>
                                                                    <span class="mdc-notched-outline__trailing"></span>
                                                                </span>
                                                            </label>
                                                              
                                                                 
                                                                </div>
                                                           
                                                        </div>
                                                        <div class="rtwwwap-paypal-deatil">
                                                            <div class="rtwwwap-paypal-imag">
                                                                <img src="'.esc_url( RTWWWAP_URL.'/assets/images/paypal.png' ).'">
                                                            </div>
                                                           
                                                                <div class="rtwwwap-paypal-input-padding">
                                                                    <label class="mdc-text-field mdc-text-field--outlined rtwwwap-payment-text-field">
                                                                        <input type="text" class="mdc-text-field__input" id="rtwwwap_paypal_email" value="'.$rtwwwap_paypal_email.'">
                                                                        <div class="mdc-notched-outline mdc-notched-outline--upgraded">
                                                                            <div class="mdc-notched-outline__leading"></div>
                                                                            <div class="mdc-notched-outline__notch">
                                                                            <span class="mdc-floating-label">'.esc_html__( 'Enter Your Paypal Email here', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                                                            </div>
                                                                            <div class="mdc-notched-outline__trailing"></div>
                                                                        </div>
                                                                    </label>
                                                                </div>
                                                          
                                                        </div>
                                                        <div class="rtwwwap-stripe-deatil">
                                                            <div class="rtwwwap-paypal-imag">
                                                                <img src="'.esc_url( RTWWWAP_URL.'/assets/images/stripe.png' ).'">
                                                            </div>
                                                            
                                                           
                                                            <label class="mdc-text-field mdc-text-field--outlined rtwwwap-payment-text-field">
                                                                    <input type="text" class="mdc-text-field__input" id="rtwwwap_stripe_email" value="'.$rtwwwap_stripe_email.'">
                                                                    <div class="mdc-notched-outline mdc-notched-outline--upgraded">
                                                                        <div class="mdc-notched-outline__leading"></div>
                                                                        <div class="mdc-notched-outline__notch">
                                                                        <span class="mdc-floating-label">'.esc_html__( 'Enter Your Stripe Email here', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                                                        </div>
                                                                        <div class="mdc-notched-outline__trailing"></div>
                                                                    </div>
                                                                </label>
                                                        </div>
                                                    </div>
                                                    <div class="rtwwwap-payment-detail-btn">
                                                        <span 
                                                        name="rtwwwap_payout_save" id="rtwwwap_payout_save" class="mdc-button mdc-button--raised mdc-ripple-upgraded" >
                                                            <span class="mdc-button__label">'.esc_html__( 'Save Details', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                     </form>
                                   </section>
                                </div>
                            ';

//custom field function 

if(!function_exists('rtwwwap_custom_form_fields_data'))
{
function rtwwwap_custom_form_fields_data($rtwwwap_userdata){
    $rtwwwap_reg_temp_features = get_option( 'rtwwwap_reg_temp_opt' );
    $rtwwwap_reg_custom_fields = isset($rtwwwap_reg_temp_features['custom-input']) ? $rtwwwap_reg_temp_features['custom-input'] : array();

    $rtwwwap_html = '';
    if(is_array($rtwwwap_reg_custom_fields) && !empty($rtwwwap_reg_custom_fields)){
        foreach ($rtwwwap_reg_custom_fields as $custom_fields) {
            $rtwwwap_reg_user_custom_field = isset($rtwwwap_userdata[$custom_fields['custom-input-id']][0]) ? $rtwwwap_userdata[$custom_fields['custom-input-id']][0] : '';
            if(isset($custom_fields['custom-input-type'])){
                if(($custom_fields['custom-input-type'] == 'text' || $custom_fields['custom-input-type'] == 'number')){
                    $rtwwwap_html .=  '<div class="rtwwwap-input-padding">';
                    $rtwwwap_html .=  '<div class="mdc-text-field rtwwwap-payment-text-field mdc-ripple-upgraded">';
                    $rtwwwap_html .= 	'<input type="'.$custom_fields['custom-input-type'].'" name="'.$custom_fields['custom-input-id'].'"  id="'.$custom_fields['custom-input-id'].'" class="'.$custom_fields['custom-input-class'].' rtwwwap_custom_fields mdc-text-field__input" placeholder="'.esc_attr__( $custom_fields['custom-input-label'], "rtwwwap-wp-wc-affiliate-program" ).'"" value="'.$rtwwwap_reg_user_custom_field.'" />';
                    $rtwwwap_html .=  '<div class="mdc-line-ripple"></div>';
                    $rtwwwap_html .= 		'<label class="mdc-floating-label">'.esc_html__( $custom_fields['custom-input-label'], "rtwwwap-wp-wc-affiliate-program" ).'</label>';
                    $rtwwwap_html .= '</div>';
                    $rtwwwap_html .= '</div>';
                }elseif ($custom_fields['custom-input-type'] == 'textarea') {
            
                    $rtwwwap_html .=  ' <div class="rtwwwap-input-padding"> 
                    <label class="mdc-text-field  mdc-text-field--textarea mdc-text-field--no-label rtwwwap-w-100">Address</label>
                    <label class="mdc-text-field mdc-text-field--filled mdc-text-field--textarea mdc-text-field--no-label rtwwwap-w-100">
<span class="mdc-text-field__ripple"></span>

<textarea name="'.$custom_fields['custom-input-id'].'"  id="'.$custom_fields['custom-input-id'].'" class=" mdc-text-field__input rtwwwap_custom_fields '.$custom_fields['custom-input-class'].'" placeholder="'.esc_attr__( $custom_fields['custom-input-label'], "rtwwwap-wp-wc-affiliate-program" ).'">'.$rtwwwap_reg_user_custom_field.'</textarea>

<span class="mdc-line-ripple"></span>
</label>';
                  
                    $rtwwwap_html .= '</div>';
                }
                elseif ($custom_fields['custom-input-type'] == 'checkbox') {
                    $rtwwwap_html .=  '<div class="rtwwwap-input-padding rtwwwap-custom-checkbox">';
                    $rtwwwap_html .=  '<div class="mdc-touch-target-wrapper rtwwwap_row_check">';
                    $rtwwwap_html .=  '<div class="mdc-checkbox mdc-checkbox--touch">';
                    $rtwwwap_html .=  '<input type="'.$custom_fields['custom-input-type'].'" name="'.$value.'"  id="'.$custom_fields['custom-input-id'].'" class="mdc-checkbox__native-control rtwwwap_custom_fields '.$custom_fields['custom-input-class'].'" placeholder="'.esc_attr__( $custom_fields['custom-input-label'], "rtwwwap-wp-wc-affiliate-program" ).'"" value="'.esc_attr__(trim($value),"rtwwwap-wp-wc-affiliate-program").'" '.checked($rtwwwap_value_checked,$value,false). ' />';
                    $rtwwwap_html .=  '<div class="mdc-checkbox__background">';
                    $rtwwwap_html .=  '<svg class="mdc-checkbox__checkmark" viewBox="0 0 24 24">
                    <path class="mdc-checkbox__checkmark-path" fill="none" d="M1.73,12.91 8.1,19.28 22.79,4.59"></path>
                </svg>';
                    $rtwwwap_html .=   '</div>';
                    $rtwwwap_html .=  '<div class="mdc-checkbox__ripple"></div>';
                    $rtwwwap_html .=   '</div>';
                    $rtwwwap_html .= 	'<label>'.esc_html__( $custom_fields['custom-input-label'], "rtwwwap-wp-wc-affiliate-program" ).'</label>';
                    $rtwwwap_html .=   '</div>';
                    
                    $rtwwwap_checkbox_options = explode('|',$custom_fields['custom-input-options']);
                    if(is_array($rtwwwap_checkbox_options) && !empty($rtwwwap_checkbox_options)){
                        $rtwwwap_html .= '<div class="rtwwwap-custom-checkbox">';
                        foreach ($rtwwwap_checkbox_options as $value) {
                            $rtwwwap_value_checked          =         isset($rtwwwap_userdata[$value][0]) ? $rtwwwap_userdata[$value][0] : ''; 
                            $rtwwwap_html .= 	'<label><input type="'.$custom_fields['custom-input-type'].'" name="'.$value.'"  id="'.$custom_fields['custom-input-id'].'" class="'.$custom_fields['custom-input-class'].'  rtwwwap_custom_fields" placeholder="'.esc_attr__( $custom_fields['custom-input-label'], "rtwwwap-wp-wc-affiliate-program" ).'"" value="'.esc_attr__(trim($value),"rtwwwap-wp-wc-affiliate-program").'" '.checked($rtwwwap_value_checked,$value,false). ' />'.esc_html__($value,"rtwwwap-wp-wc-affiliate-program").'</label>';

                        }
                        $rtwwwap_html .= '</div>';
                        $rtwwwap_html .= '</div>';
                    }
                }elseif ($custom_fields['custom-input-type'] == 'radio') {
                    $rtwwwap_html .= 					'<label>'.esc_html__( $custom_fields['custom-input-label'], "rtwwwap-wp-wc-affiliate-program" ).'</label>';
                    $rtwwwap_checkbox_options = explode('|',$custom_fields['custom-input-options']);
                    if(is_array($rtwwwap_checkbox_options) && !empty($rtwwwap_checkbox_options)){
                        $rtwwwap_html .= '<div class="rtwwwap-custom-radio">';
                        foreach ($rtwwwap_checkbox_options as $value) {
                            $rtwwwap_html .= 	'<label for="'.$custom_fields['custom-input-id'].'"><input type="'.$custom_fields['custom-input-type'].'" name="'.$custom_fields['custom-input-id'].'"  id="'.$custom_fields['custom-input-id'].'" class="'.$custom_fields['custom-input-class'].' rtwwwap_custom_fields" placeholder="'.esc_attr__( $custom_fields['custom-input-label'], "rtwwwap-wp-wc-affiliate-program" ).'"" value="'.esc_attr__(trim($value),"rtwwwap-wp-wc-affiliate-program").'" '.checked(isset($rtwwwap_userdata[$custom_fields['custom-input-id']][0]) ? $rtwwwap_userdata[$custom_fields['custom-input-id']][0] : ''  ,$value,false). ' />'.esc_html__($value,"rtwwwap-wp-wc-affiliate-program").'</label>';

                        }
                        $rtwwwap_html .= '</div>';
                    }
                }
                elseif ($custom_fields['custom-input-type'] == 'select') {
                    $rtwwwap_html .= 					'<label>'.esc_html__( $custom_fields['custom-input-label'], "rtwwwap-wp-wc-affiliate-program" ).'</label>';
                    $rtwwwap_checkbox_options = explode('|',$custom_fields['custom-input-options']);
                    if(is_array($rtwwwap_checkbox_options) && !empty($rtwwwap_checkbox_options)){
                        $rtwwwap_html .= 	'<div class="rtwwwap-text"><span class="rtwwwap-text-icon"><i class="far fa-envelope"></i></span><select name="'.$custom_fields['custom-input-id'].'"  id="'.$custom_fields['custom-input-id'].'" class="'.$custom_fields['custom-input-class'].' rtwwwap_custom_fields" >';
                        foreach ($rtwwwap_checkbox_options as $options_value) {
                            $rtwwwap_html .= 	'<option '.selected(isset($rtwwwap_userdata[$custom_fields['custom-input-id']][0]) ? $rtwwwap_userdata[$custom_fields['custom-input-id']][0] : '',$options_value,false). ' value="'.esc_attr__(trim($options_value ),"rtwwwap-wp-wc-affiliate-program").'" >'.esc_html__(trim($options_value),"rtwwwap-wp-wc-affiliate-program").'</option>';
                        }
                        $rtwwwap_html .= 	'</select></div>';
                    }
                }
            }
        }
    }
    return $rtwwwap_html;
}
}

// profile tab //

$rtwwwap_userdata = get_user_meta($rtwwwap_user_id);
$rtwwwap_user = get_userdata($rtwwwap_user_id);


$rtwwwap_reg_temp_features = get_option( 'rtwwwap_reg_temp_opt' );

// $rtwwwap_custom_fields = array();
// $rtwwap_custom_firlds_array = $rtwwwap_reg_temp_features['custom-input'];

//  foreach($rtwwap_custom_firlds_array as $custom => $value)
//  {
//     $rtwwwap_custom_fields[] =  $value['custom-input-id'] ;
//  }

//   $rtwwwap_custom_fields = json_encode($rtwwwap_custom_fields);


$rtwwwap_html1 .= '  <form method="post">
                        <section class="rtwwwap-profile-section rtwwwap_hide" id="rtwwwap_profile_tab">

                        <div class="mdc-layout-grid rtwwwap-payment-section-wrapper mdc-elevation--z9">
                            <div class="mdc-elevation--z4 rtwwwap-payment-input-box">
                                    <span class="rtwwwap-login-form-logo">
                                        <i class="fas fa-user" aria-hidden="true"></i>
                                    </span>
                                <h4 class="rtwwwap-login-form-title">Profile</h4>
                                <div class="rtwwwap-input-padding">
                                    <div class="mdc-text-field rtwwwap-payment-text-field mdc-ripple-upgraded">
                                        <input class="mdc-text-field__input  rtwwwap_custom_fields" name="user_login" id="username" value="'.$rtwwwap_userdata['nickname'][0].'" disabled ">
                                        <div class="mdc-line-ripple"></div>
                                        <label class="mdc-floating-label color_white">'.esc_html__( 'Usename', 'rtwwwap-wp-wc-affiliate-program' ).'</label>
                                    </div>
                                </div>
                                <div class="rtwwwap-input-padding">
                                    <div class="mdc-text-field rtwwwap-payment-text-field mdc-ripple-upgraded">
                                        <input class="mdc-text-field__input rtwwwap_custom_fields" name="user_email" id="unseremail" value="'.$rtwwwap_user->user_email.'" disabled>
                                        <div class="mdc-line-ripple"></div>
                                        <label class="mdc-floating-label color_white">'.esc_html__( 'Email', 'rtwwwap-wp-wc-affiliate-program' ).'</label>
                                    </div>
                                </div>	
                                <div class="rtwwwap-input-padding">
                                    <div class="mdc-text-field rtwwwap-payment-text-field mdc-ripple-upgraded">
                                        <input class="mdc-text-field__input rtwwwap_custom_fields" name="first_name" id="userfirstname" value="'.$rtwwwap_userdata['first_name'][0].'">
                                        <div class="mdc-line-ripple"></div>
                                        <label class="mdc-floating-label">'.esc_html__( 'First Name', 'rtwwwap-wp-wc-affiliate-program' ).'</label>
                                    </div>
                                </div>
                                <div class="rtwwwap-input-padding">
                                    <div class="mdc-text-field rtwwwap-payment-text-field mdc-ripple-upgraded">
                                        <input class="mdc-text-field__input rtwwwap_custom_fields" name="last_name" id="userlastname" value="'.$rtwwwap_userdata['last_name'][0].'">
                                        <div class="mdc-line-ripple"></div>
                                        <label class="mdc-floating-label">'.esc_html__( 'Last name', 'rtwwwap-wp-wc-affiliate-program' ).'</label>
                                    </div>
                                </div>';
    $rtwwwap_html1 .= 	rtwwwap_custom_form_fields_data($rtwwwap_userdata);

$rtwwwap_html1 .=              '<div class="rtwwwap-update-btn">
                                    <span class="mdc-button mdc-button--raised mdc-theme--primary mdc-ripple-upgraded rtwwwap_payment_submit_button rtwwwap_profile_save"  id="rtwwwap_profile_save"  name="rtwwwap_profile_save" >'.esc_html__('Update Detail',"rtwwwap-wp-wc-affiliate-program").'</span>
                                </div>
                            </div>
                        </div>
                 
                </section>
                </form> ';


/// create banner//      

$rtwwwap_custom_banner = get_option( 'rtwwwap_custom_banner_opt' );
    if(	$rtwwwap_custom_banner != '' )
    {
        $rtwwwap_count = 1;
        
        $rtwwwap_html1 .= 	'<div class="rtwwwap_custom_banner_container rtwwwap_hide" id="rtwwwap_custom_banner_tab">';
        $rtwwwap_html1 .= 	'<div class="rtwwwap_custom_banner_row">';
        foreach($rtwwwap_custom_banner as $key => $value) 
        {
            
            $rtwwwap_image_src = wp_get_attachment_url($value['image_id']);		
            $rtwwwap_image_width = $value['image_width']/2;
            $rtwwwap_image_height = (int)$value['image_height'];
            if( $rtwwwap_image_height > 350)
            {	
                $rtwwwap_image_height = $rtwwwap_image_height/2 ; 
            }
        
    
            $rtwwwap_html1 .= 	'<div class ="rtwwwap_custom_banner_product" style=" width:'.$rtwwwap_image_width.'px;height:auto;">';
            
            $rtwwwap_html1 .=        '<div class = "rtwwwap_banner_no">'.esc_html("Banner No.").esc_attr__($rtwwwap_count).'</div>';
            $rtwwwap_html1 .= 				'<div class ="rtwwwap_custom_banner_product_image" style="height:'.$rtwwwap_image_height.'px;">';
            $rtwwwap_html1 .=					'<img class="rtwwwap_banner_image"  src="'.$rtwwwap_image_src.'" >';
            $rtwwwap_html1 .=				 '</div>';
            $rtwwwap_html1 .=				'<div>';
            $rtwwwap_html1 .=				'<span class="rtwwwap_image_size_detail">Image Size : '.$value['image_width'].'</span>';
            $rtwwwap_html1 .=				'<span class="rtwwwap_image_size_detail"> '.esc_html__( " x ", "rtwwwap-wp-wc-affiliate-program" ).$value['image_height'].'</span>';
            $rtwwwap_html1 .=				'</div>';
            $rtwwwap_html1 .=				 '<label class="rtwwwap_copy_info" >'.esc_html__( " Copy and paste the code into your Website", "rtwwwap-wp-wc-affiliate-program" ).'</label>';	
            $rtwwwap_html1 .=				 '<div class="rtwwwap_banner_copy_text" >'.esc_html__( "Copied", "rtwwwap-wp-wc-affiliate-program" ).'</div>';
            $rtwwwap_html1 .= 			'<button  data-image_id ="'.$rtwwwap_image_src.'" data-target_link ="'.$value['target_link'].'" name="rtwwwap_custom_banner_copy_html" class="rtwwwap_custom_banner_copy_html" data-image_width ="'.$value['image_width'].'" data-image_height ="'.$value['image_height'].'">'.esc_html__( "COPY HTML", "rtwwwap-wp-wc-affiliate-program" ).'</button>';
            $rtwwwap_html1 .= 	'</div>'; 

            $rtwwwap_count  = $rtwwwap_count + 1;	 
        
        }
        $rtwwwap_html1 .= 	'</div>';

        $rtwwwap_html1 .= 	'</div>';
    }




    
///create Banner tab start ///

if(RTWWWAP_IS_WOO == 1)
{
$rtwwwap_all_categories = get_categories( array(
    'hide_empty' 	=> 0,
    'taxonomy'   	=> 'product_cat'
));
}
// display download categories
if(RTWWWAP_IS_Easy == 1)
{
    $rtwwwap_all_categories = get_categories( array(
    'hide_empty' 	=> 0,
    'taxonomy'   	=> 'download_category'
));
}



$rtwwwap_html1 .= '  <div class="rtwwwap_hide" id="rtwwwap_create_banner_tab" ><h4>Create Banners</h4>
                            <div class="rtwwwap-search-prdct-input">
                                <label class="mdc-text-field mdc-text-field--outlined rtwwwap-w-100">
                                    <input type="text" name="product_name" class="mdc-text-field__input"  id="rtwwwap_banner_prod_search">
                                    <div class="mdc-notched-outline mdc-notched-outline--upgraded">
                                        <div class="mdc-notched-outline__leading"></div>
                                        <div class="mdc-notched-outline__notch">
                                        <span class="mdc-floating-label"> '.esc_html__( 'Search products', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                        </div>
                                        <div class="mdc-notched-outline__trailing"></div>
                                    </div>
                                </label>
                            </div>
                           
                            <div class="rtwwwap-search-wrapper">
                                <select class="rtwwwap_search_product ">';
                            
                            if( !empty( $rtwwwap_all_categories ) ){
        
                                foreach ( $rtwwwap_all_categories as $rtwwwap_key => $rtwwwap_category ) {
                                    
                                    if($rtwwwap_category->cat_name == 'uncategorized')
                                    {
                                    $rtwwwap_html1 .=		'<option value="'.esc_attr( $rtwwwap_category->cat_ID ).'" selected>';
                                    $rtwwwap_html1 .=			esc_html( $rtwwwap_category->cat_name );
                                    $rtwwwap_html1 .= 		'</option>';
                                    }
                                    else{
                                    $rtwwwap_html1 .=		'<option value="'.esc_attr( $rtwwwap_category->cat_ID ).'" >';
                                    $rtwwwap_html1 .=			esc_html( $rtwwwap_category->cat_name );
                                    $rtwwwap_html1 .= 		'</option>';
                                    }
                                    
                                }
                            }
                            else{
                                $rtwwwap_html1 .=		'<option value="" >';
                                $rtwwwap_html1 .=			esc_html__( 'No Category', 'rtwwwap-wp-wc-affiliate-program' );
                                $rtwwwap_html1 .= 		'</option>';
                            }


            $rtwwwap_html1 .= ' </select><button class="mdc-button  mdc-ripple-upgraded mdc-button--raised" id="rtwwwap-search-icon">
                                    <span class=" fas fa-search"> </span>
                                </button>
                            </div>
                            <p id="rtwwwap_banner_link">                         
                            </p>

                            <button class="mdc-button  mdc-ripple-upgraded mdc-button--raised" id="rtwwwap_copy_banner_link">
                            '.esc_html__( 'Copy Link', 'rtwwwap-wp-wc-affiliate-program' ).'
                          
                            </button>
                            <span id="rtwwwap_copy_link_tooltip">'.esc_html__( 'Copied', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                            <section class="rtwwwap-search-prdct-section">
                                <div class="rtwwwap-prdct-row">
                                </div>
                               
                            </section>
                        </div>
                        
                    ';


/// MLM


$rtwwwap_mlm = get_option( 'rtwwwap_mlm_opt' );
if( isset( $rtwwwap_mlm[ 'activate' ] ) && $rtwwwap_mlm[ 'activate' ] == 1 )
{
    $rtwwwap_mlm_childs = isset( $rtwwwap_mlm[ 'child' ] ) ? $rtwwwap_mlm[ 'child' ] : '1';
    global $wpdb;
        $rtwwwap_mlm_type = '';
        if( isset( $rtwwwap_mlm[ 'mlm_type' ] ) )
        {
            if( $rtwwwap_mlm[ 'mlm_type' ] == 0 )
            {
                $rtwwwap_mlm_type = esc_html__( "Binary", "rtwwwap-wp-wc-affiliate-program" );
            }
            if( $rtwwwap_mlm[ 'mlm_type' ] == 1 )
            {
                $rtwwwap_mlm_type = esc_html__( "Forced Matrix", "rtwwwap-wp-wc-affiliate-program" );
            }
            if( $rtwwwap_mlm[ 'mlm_type' ] == 2 )
            {
                $rtwwwap_mlm_type = esc_html__( "Unilevel", "rtwwwap-wp-wc-affiliate-program" );
            }
            if( $rtwwwap_mlm[ 'mlm_type' ] == 3 )
            {
                $rtwwwap_mlm_type = esc_html__( "Unlimited", "rtwwwap-wp-wc-affiliate-program" );
            }
        }
        
                    
$rtwwwap_html1 .= '
                <section class="rtwwwap-mlm-section rtwwwap_hide" id="rtwwwap_mlm_tab" >
                    <div class="rtwwwap-mlm-card-row">
                        <div class="rtwwwap-mlm-left-side">
                            <div class="rtwwwap-mlm-card1 mdc-elevation--z9">
                                <p class="rtwwwap-mlm-card-content">
                                    <span>'.esc_html__( 'MLMP Plan :', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                    <span>'.$rtwwwap_mlm_type.'</span>
                                </p>';

                                if( isset( $rtwwwap_mlm[ 'mlm_type' ] ) )
                                {
                                    if( $rtwwwap_mlm[ 'mlm_type' ] == 0 )
                                    {
$rtwwwap_html1 .= '               <div class="rtwwwap-mlm-image">
                                    <img src="'.esc_url( RTWWWAP_URL.'/assets/images/binary.gif' ).'">
                                 </div>';
                                    }
                                    if( $rtwwwap_mlm[ 'mlm_type' ] == 1 )
                                    {
 $rtwwwap_html1 .= '               <div class="rtwwwap-mlm-image">
                                        <img src="'.esc_url( RTWWWAP_URL.'/assets/images/forced.gif' ).'">
                                     </div>';
                                    }
                                    if( $rtwwwap_mlm[ 'mlm_type' ] == 2 )
                                    {
 $rtwwwap_html1 .= '               <div class="rtwwwap-mlm-image">
                                    <img src="'.esc_url( RTWWWAP_URL.'/assets/images/unilevel.gif' ).'">
                                 </div>';
                                    }
                                    if( $rtwwwap_mlm[ 'mlm_type' ] == 3 )
                                    {
 $rtwwwap_html1 .= '               <div class="rtwwwap-mlm-image">
                                    <img src="'.esc_url( RTWWWAP_URL.'/assets/images/unlimited_mlm.jpeg' ).'">
                                 </div>';
                                    }
                                }
$rtwwwap_html1 .= '       
                            </div>
                            <div class="rtwwwap-mlm-card2 mdc-elevation--z9">
                                <p>Number of Childs to start earning commission</p>
                                <div class="rtwwwap-card-number-wrapper">
                                    <div class="rtwwwap-loader"></div>
                                    <div class="rtwwwap-number">
                                        <span>'. $rtwwwap_mlm_childs
                                        .'</span>
                                    </div>
                                
                                </div>
                            </div>
                            <div class="rtwwwap-mlm-btn">
                                <a class="mdc-button mdc-button--raised mdc-theme--primary mdc-ripple-upgraded rtwwwap_payment_submit_button" id="rtwwwap_show_mlm_chain" data-user_id="'.$rtwwwap_user_id.'">
                                    <div class="mdc-button__ripple"></div>
                                    <span class="mdc-button__label" >'.esc_html__( 'Show MLM Chain', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                </a>
                            </div>
                                <p class="rtwwwap_mlm_chain_not">'.
                                esc_html__( "MLM chain is not proper, activate/ deactivate the members to make the chain according to your MLM plan. Once done reload the page to see the updated MLM chain.", 'rtwwwap-wp-wc-affiliate-program' ).'
                                </p>
                            <div id="rtwwwap_mlm_chain_struct"></div>
                            <div id="rtwwwap_mlm_show"></div>
                        </div>
                        <div class="rtwwwap-mlm-right-side">
                                    <div class="rtwwwap-text">
                                        <h4>
                                            <span> <i class="fas fa-retweet mr-1" aria-hidden="true"></i> '.esc_html__( 'MLM Table', 'rtwwwap-wp-wc-affiliate-program' ).'</span>
                                        </h4>
                                    </div>
                           
                                
                                <div class="rtwwwap_table_container">
                                    
                                    <table class="mdl-data-table" id="rtwwwap_mlm_table" aria-label="Dessert calories">
                                            <!-- <caption>MLM Levels</caption> -->
                                        <thead>
                                        
                                        <tr>
                                            
                                            <th>'.esc_html__( 'Level', 'rtwwwap-wp-wc-affiliate-program' ).'</th>
                                            <th>'.esc_html__( 'Commission Type', 'rtwwwap-wp-wc-affiliate-program' ).'</th>
                                            <th>'.esc_html__( 'Commission Amount', 'rtwwwap-wp-wc-affiliate-program' ).'</th>
                                        </tr>
                                        </thead>
                                        <tbody>';
                                        
                                    
                                        
        if( !empty( $rtwwwap_mlm[ 'mlm_levels' ] ) )
        {
            foreach( $rtwwwap_mlm[ 'mlm_levels' ] as $rtwwwap_mlm_key => $rtwwwap_mlm_value )
            {
                $rtwwwap_selected_level = '';
                if( isset( $rtwwwap_mlm[ 'mlm_levels' ][ $rtwwwap_mlm_key ][ 'mlm_level_comm_type' ] ) )
                {
                    if( $rtwwwap_mlm[ 'mlm_levels' ][ $rtwwwap_mlm_key ][ 'mlm_level_comm_type' ] == 0 )
                    {
                        $rtwwwap_selected_level = esc_html__( "Percentage", 'rtwwwap-wp-wc-affiliate-program' );
                    }
                    if( $rtwwwap_mlm[ 'mlm_levels' ][ $rtwwwap_mlm_key ][ 'mlm_level_comm_type' ] == 1 )
                    {
                        $rtwwwap_selected_level = esc_html__( "Fixed", 'rtwwwap-wp-wc-affiliate-program' );
                    }
                }
                $rtwwwap_comm_amount = ( isset( $rtwwwap_mlm[ 'mlm_levels' ][ $rtwwwap_mlm_key ][ 'mlm_level_comm_amount' ] ) ) ? $rtwwwap_mlm[ 'mlm_levels' ][ $rtwwwap_mlm_key ][ 'mlm_level_comm_amount' ] : '0';

                $rtwwwap_html1 .=  '<tr>
                                        
                                            <td>'.$rtwwwap_mlm_key.'</td>
                                            <td>'.$rtwwwap_selected_level.'</td>
                                            <td>'.$rtwwwap_comm_amount.'</td>
                                </tr>';
            }
        }
                                        '</tbody>
                                    </table>
                                </div>
                            </div>
                   
                        </div>
                    </div>
                    
            </section>
            ';	
        
     
    
}
$rtwwwap_html1 .=	'</div>';





        return $rtwwwap_html1;
?>
