<?php
/*
Author: zulfahmyrizal
Website: https://www.zulfahmyrizal.ml/
*/
?>
<?php
session_start();
session_destroy();
echo '<script>alert("Logout Success");window.location.assign("index.php");</script>';
?>