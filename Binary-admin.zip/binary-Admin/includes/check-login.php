<?php
/*
Author: zulfahmyrizal
Website: https://www.zulfahmyrizal.ml/
*/
?>
<?php
session_start();
// check login authenticated
if(isset($_SESSION['userid']) && $_SESSION['login_type']=='user'){
}
else{
	echo '<script>alert("Access denied");window.location.assign("index.php");</script>';
}
?>