<div class="col-md-12" id="mlm-main-div">        
    <?php 
    wpmlm_user_area();
    ?>    
</div>