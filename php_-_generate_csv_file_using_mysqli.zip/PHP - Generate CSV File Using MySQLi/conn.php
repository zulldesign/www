<?php
	$conn = new mysqli('localhost', 'root', '', 'db_csv');
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>