=== Affiliate Pro Plus ===
Contributors: Browny
donate:http://howitworkz.com/wordpress/affiliate-pro-plus/
Tags: affiliate, referral, plugin, links
Requires at least: 2.8.4
Tested up to: 3.1
Stable tag: trunk

Affiliate Pro Plus lets your registered users get credit for new users they recruit

== Description ==
[Affiliate Pro Plus](http://howitworkz.com/wordpress/affiliate-pro-plus/ "Plugin Page") lets your registered users get credit for new users they recruit by sending people to any url on your wordpress site with ?affid=username appended to the end. This will set a cookie on the visitors computer, which tracks who they have been [referred](http://howitworkz.com/wordpress/affiliate-pro-plus/ "Plugin Page") by.

You can select who gets the [credit for the referral](http://howitworkz.com/wordpress/affiliate-pro-plus/ "Plugin Page"): the first affiliate who send the user to your site or the last (cookie is overridden with new affiliate ID) You can also specify for how long the cookie is valid.

Members can be redirected to any page you want when logging in (admin users will not be redirected)

You can see who has been [referred](http://howitworkz.com/wordpress/affiliate-pro-plus/ "Plugin Page") by whom and how many new members have been referred by each user on the user list.

== Installation ==

To install this plugin unzip the downloaded file and upload the entire affiliate-pro-plus folder to your blogs plugin folder ( \wp-content\plugins\ ) the plugin should now show up in the WordPress plugins panel, available for activation.

== Changelog ==

= 3.0.1 =
* IMPORTANT: Removed malicious code from plugin. Please update.

= 2.0.1 =
* added the option to hide the affiliate parameter on the signup form

= 2.0.0 =

* added landingpage parameter to the settings page to redirect all incomming affiliate links to a certain page
