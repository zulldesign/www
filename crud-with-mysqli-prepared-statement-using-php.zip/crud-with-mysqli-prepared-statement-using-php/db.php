<?php
		$conn =new mysqli('localhost', 'root', '' , 'blog_samples');
?>