=== WZ M2UPay for WooCommerce ===
Contributors: wanzulnet
Tags: maybank2upay,paymentgateway,fpx,malaysia
Tested up to: 4.8
Stable tag: 1.00
Donate link: https://www.billplz.com/hpojtffm3
Requires at least: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Accept Internet Banking Payment by using Maybank2u Pay. 

== Description ==
Install this plugin to accept payment using Maybank2u. 

== Upgrade Notice == 

None

== Screenshots ==
* Will available soon

== Changelog ==

= 1.00 =

* Initial Release

== Installation ==

* Will available soon

== Frequently Asked Questions ==

= Later =

Later

= Troubleshooting =

* Will available soon

== Links ==

* Will available soon

== Thanks ==

Will available soon