<?php
$nama=$_POST['nama'];
$email=$_POST['email'];
$telefon=$_POST['tel'];
$harga=$_POST['rm'];

//insert POST data ke tblorder
$qinsorder=sqlquery("insert into tblorder (nama, email, telefon,harga, status, tarikh) values (?,?,?,?,?,now())");
$qinsorder->bindValue(1,$nama);
$qinsorder->bindValue(2,$email);
$qinsorder->bindValue(3,$telefon);
$qinsorder->bindValue(4,$harga);
$qinsorder->bindValue(5,0);
$qinsorder->execute();

//get orderid
$qgetoid=sqlquery("select id from tblorder order by id desc limit 1");
$qgetoid->execute();
$getoid = $qgetoid->fetch(PDO::FETCH_ASSOC);
$oid=$getoid['id']; 

//convert RM1=100
$rm=($harga*100);

$some_data = array(
    'userSecretKey'=> 'SecretKey dari ToyyibPay',
    'categoryCode'=> 'CategoryCode dari ToyyibPay',
    'billName'=> 'LANGGANAN VIDEO PENDIDIKAN',
    'billDescription'=> '1 UNIT RM'.$rm.' video kredit',
    'billPriceSetting'=>0,
    'billPayorInfo'=>1,
    'billAmount'=>$amount,
    'billReturnUrl'=>'',
    'billCallbackUrl'=>$homeurl.'toyyibcallbackurl.php',
    'billExternalReferenceNo'=>$oid,
    'billTo'=>$nama,
    'billEmail'=>$email,
    'billPhone'=>$telefon,
    'billSplitPayment'=>0,
    'billSplitPaymentArgs'=>'',
    'billPaymentChannel'=>0,

  );  

  $curl = curl_init();
  curl_setopt($curl, CURLOPT_POST, 1);
  curl_setopt($curl, CURLOPT_URL, 'https://toyyibpay.com/index.php/api/createBill');  
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $some_data);

  $result = curl_exec($curl);
  $info = curl_getinfo($curl);  
  curl_close($curl);
  $obj = json_decode($result,true);
  $billcode=$obj[0]['BillCode'];
?>
<!--SEND USER TO TOYYIBPAY PAYMENT-->
<script type="text/javascript">
   window.location.href="https://toyyibpay.com/<?php echo $billcode;?>"; 
 </script>