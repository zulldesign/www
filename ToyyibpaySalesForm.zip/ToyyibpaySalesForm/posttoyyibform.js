 $('#frmtambahkredit').validator().on('submit', function (e) {
  if (e.isDefaultPrevented()) {} else {
	var formdata=$("#frmtambahkredit").serialize();
	var posto=posturl+'stdtambahkredit';
	$.post(posto,formdata,function(data){
        $(".stdbuycreditprosect").html(data);
	});
	return false;
  }
});