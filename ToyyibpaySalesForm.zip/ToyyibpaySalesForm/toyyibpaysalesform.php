<form data-toggle="validator" role="form" name="frmtambahkredit" id="frmtambahkredit">   
<div class="card border-0  mb-3">

<div class="card-body">
 <h4>Pembelian Kredit</h4>   

<div class="form-group">
<label for="nama" class="control-label">Nama</label>
<input type="text" class="form-control" id="nama" name="nama" value="<?php echo $nama;?>" placeholder="" data-error="Sila masukkan nama anda" required>
<div class="help-block with-errors text-danger small"></div>
</div>
     
<div class="form-group">
<label for="email" class="control-label">Email</label>
<input type="email" class="form-control" id="email" name="email" value="<?php echo $email;?>" placeholder="" data-error="Sila masukkan email anda" required>
<div class="help-block with-errors text-danger small"></div>
</div>
    
<div class="form-group">
<label for="email" class="control-label">Telefon</label>
<input type="number" class="form-control" id="tel" name="tel" value="<?php echo $mobile;?>" placeholder="" data-error="Sila masukkan telefon anda" required>
<div class="help-block with-errors text-danger small"></div>
</div>

<div class="form-group">
<label for="RM" class="control-label">Nilai</label>
<select class="form-control" id="rm" name="rm" data-error="Sila pilih Nilai Kredit" required>
<option value="">--Pilih Nila Kredit</option>  
<?php
 $qorderrm=sqlquery("SELECT id, rm FROM tblpack");
 $qorderrm->execute();
$orderrm = $qorderrm->fetchAll(PDO::FETCH_ASSOC);
while($oderrm = array_shift($orderrm)){
$rmid=$oderrm['id'];    
$rmkredit=$oderrm['rm'];
echo "<option value=\"".$rmid."\">RM".$rmkredit."</option>";
}
?>
</select>
<div class="help-block with-errors text-danger small"></div>
</div>

<div class="form-group">
<div class="stdbuycreditprosect"></div>
</div>

<div class="form-group">
<button class="btn btn-primary btnbuycredit" type="submit">Teruskan <i class="fa fa-caret-right"></i></button>
</div>

</div>

</div>
</form>