<?php
$refno=$_POST['refno'];
$status=$_POST['status'];
$reason=$_POST['reason'];
$billcode=$_POST['billcode'];
$order_id=$_POST['order_id'];
$amount=$_POST['amount'];

$quporder=sqlquery("update tblorder set status=?, tarikh=now() where id=?");
$quporder->bindValue(1, $status);
$quporder->bindValue(2, $order_id);
$quporder->execute();

if($status==1){
?>
<div class="text-center mt-5">
<h2 class="text-success">Thank You For You Payment</h2>
<p class="lead">We have received your payment. Our staff will process your order shortly.</p>
<p>Please refer to <a href="<?php echo $home;?>profile/account.html">My Purchase</a> section for order status</p>
</div>
<?php
}
if($status==2){
?>
<div class="text-center mt-5">
<h2 class="text-success">Thank You For You Purchase</h2>
<p class="lead">Your payment status is <span class="text-warning font-weight-bold">PENDING</span><br>We will process your order after payment is success</p>
<p>Please refer to <a href="<?php echo $home;?>profile/account.html">My Purchase</a> section for order status</p>
</div>
<?php   
}
if($status==3){
?>
<div class="text-center mt-5">
<h2 class="text-success">Thank You For You Purchase</h2>
<p class="lead">Your payment status is <span class="text-danger font-weight-bold">FAIL</span></p>
<p>Click <a href="https://toyyibpay.com/<?php echo $billcode;?>">HERE</a> to make a payment</p>
</div>
<?php    
}
?>