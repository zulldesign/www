CREATE TABLE `tblorder` (
  `id` int(11) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefon` varchar(15) DEFAULT NULL,
  `harga` float(6,2) NOT NULL,
  `status` int(11) NOT NULL,
  `tarikh` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;