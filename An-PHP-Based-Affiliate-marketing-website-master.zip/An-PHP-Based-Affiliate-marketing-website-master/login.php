
<?php

include("functions/functions.php");
include("includes/db.php");

include ('header.php');
?>
<div class="crumb_navigation"> Navigation: <span class="current">Home</span>
    

    <?php
    
    if(isset($_GET['cat'])){
    
    $get_id = $_GET['cat'];
    
    $query = "select cat_title from categories where cat_id='$get_id'";
    $run_query = mysqli_query($con,$query);
    
    $row = mysqli_fetch_array($run_query);
    
    $cat = $row['cat_title'];
    
    echo"<span class=current>>$cat</span>";
    
    }
    
    ?>

 </div>
    <div class="left_content">
      <div class="title_box">Categories</div>
      <ul class="left_menu">
        
 <?php 
     getcats(); 
     

 ?>
        
      </ul>
     
<div class="title_box">Manufacturers</div>
      <ul class="left_menu">
        

    <?php  getbrands();  ?>


 
</ul>
 <br>
 <br>

     
      <div class="banner_adds"> <a href="#"><img src="images/bann2.jpg" alt="" border="0" /></a> </div>
      
           <br>
 <br>
 <br>
     
 
        <?php

         special();

        ?>

    </div>
    <!-- end of left content -->
    <div class="center_content">
  <div id="form">


	<div class="formbox">

		<h1>Sign In</h1>
		<form method="POST" action="includes/signin.php">

		<p><input id="text1" name="user_name" type="text" placeholder="&nbsp;&nbsp;&nbsp;Username / E-mail"/></p>

		<p><input id="text1" name="password" type="password" placeholder="&nbsp;&nbsp;&nbsp;Password"/></p>

		<p><input id="btn" type="submit" name="submit" value="Log In&nbsp;&nbsp;&nbsp"/>
		
		<a href="register.php">
		<input id="create" type="button" value=" Create New Account&nbsp;&nbsp;&nbsp"; /></a>&nbsp;</p>
        </form>
	</div>

</div>



  </div>
  
 
  
  
 
    <!-- end of center content -->
<div class="right_content">
      <div class="shopping_cart">
        <div class="cart_title"><i>Welcome Guest!</i><br>Shopping cart</div>
        <div class="cart_details"><font color="blue"><?php total_items(); ?></font>&nbsp;item(s) <br />
          <span class="border_cart"></span> Total:<span class="price"><?php total_price(); ?> </span> </div>
        <div class="cart_icon"><a href="cart.php" title="header=[Checkout] body=[&nbsp;] fade=[on]"><img src="images/shoppingcart.png" alt="" width="48" height="48" border="0" /></a></div>
      </div>
      
       
       <br>
     
            <?php
 
            special();

           ?> 

        <br>
     
 
        <?php

         special();

        ?>
        
             <br>
     
 
        <?php

         special();

        ?>
     <br>
     
 
        <?php

         special();

        ?>


      
        <!-- end of right content -->
</div>
  


<?php

include("footer.php");

?>

</div>
</body>

</html>