# Ecommerce Using an Affiliate marketing

## A PHP e-commerce web application.

1. To set this web application, make sure PHP and PHPMyAdmin is installed on your server.
2. Next open PHPMyAdmin,import the db.sql file located at database/db.sql. This will generate tables in your database on your server.
3. The admin user which I have made has an username electronixadmin and the password is 12345678. (Please confirm this in db or create one manually.
4. Open config.php file and add the details of your PHPMyAdmin's id and password to access the database. Now re-upload this file to the server.
5. Once this is done, go to the url of your website and it should be up and running.

Enjoy!

Currently only COD (Cash on Delivery), has been implemented. Working on email delivery on purchase and payment gateway. Stay tuned for the updates.