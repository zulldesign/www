<meta name="description" content="Letsliftgh is a Multi-level Marketing Company in Ghana.">
  <meta name="keywords" content="mlm, matrix, multi-level, marketing, multi-level marketing, business, commission, lets, lift, ghana" />
  
  <link href="img/letsliftgh-fav.png" rel="shortcut icon">