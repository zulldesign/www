<div class="footer-links row">
      <div class="divider2"></div>
      <div class="col-xs-12" style="padding-top:20px; text-align: center;">&copy; 2015 Letsliftgh <br>
      <span style="text-align: right;"> <a href="http://www.letsliftgh.com">Home</a> &nbsp;|&nbsp; <a href="http://www.letsliftgh.com/about">
      About Us </a>&nbsp;|&nbsp; <a href="http://www.letsliftgh.com/contact">Contact Us</a>|&nbsp; <a href="http://www.letsliftgh.com/terms">Terms & Conditions</a></span>
      &nbsp;&nbsp;
      </div>
      
      </div>