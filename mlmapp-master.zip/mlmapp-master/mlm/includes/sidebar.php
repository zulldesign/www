<div class="sidebar clearfix navbar-fixed-top">

<ul class="sidebar-panel nav">
  <li class="sidetitle">MAIN MENU</li>
  <li><a href="#"><span class="icon color9"><i class="fa fa-th"></i></span>Dashboard<span class="caret"></span></a>
    <ul>
        <li><a href="viewProfile.php">View Profile</a></li>
      <li><a href="updateProfile.php">Update Profile</a></li>
    </ul>
  </li>
    
  <li><a href="#"><span class="icon color9"><i class="fa fa-user"></i></span>My Account<span class="caret"></span></a>
    <ul>
      <li><a href="genealogy_tree">Genealogy Report</a></li>
      <li><a href="downline_status">Downline Status</a></li>
      <li><a href="g_print">Print Report</a></li>
      <li><a href="g_income">Total Income Earned</a></li>
    </ul>
  </li>
  <li><a href="#"><span class="icon color9"><i class="fa fa-wrench"></i></span>Support<span class="caret"></span></a>
    <ul>
      <li><a href="admin_contact">Contact Admin</a></li>
      <li><a href="faqs">FAQs</a></li>
    </ul>
  </li>
</ul>

</div>