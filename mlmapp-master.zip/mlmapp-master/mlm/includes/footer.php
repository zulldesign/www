<div class="row footer">
  <div class="col-md-6 text-left">
      Copyright &COPY; 2015 <a href="http://http://www.letsliftgh.com" target="_blank">Letsliftgh</a> All rights reserved.
  </div>
  <div class="col-md-6 text-right">
    Powered by <a href="http://www.blanqcheq.com" target="_blank">Blanqcheq</a>
  </div> 
</div>