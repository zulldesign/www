<?php
    session_start();
    //error_reporting(0);
    
    require 'dbconnect.php';
    require 'all_functions.php';
    require 'members.php';
    
    $errors = array();
?>