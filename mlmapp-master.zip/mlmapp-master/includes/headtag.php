<meta name="description" content="Letsliftgh is a Multi-level Marketing Company in Ghana.">
    <meta name="keywords" content="mlm, matrix, multi-level, marketing, multi-level marketing, business, commission, lets, lift, ghana" />
	<meta name="author" content="Blanqcheq">
        
        <link href="images/llgh-favicon.png" type="image/x-icon" rel="shortcut icon">