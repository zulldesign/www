<footer id="footer">
    	<div class="container">
            <!-- begin footer top -->
            <div id="footer-top">
                <div class="one-fourth">
                	<div class="widget">
                        <h3>About Us</h3>
                        <p>Letsliftgh is a Multi-level Marketing Company in Ghana.</p>
                    </div>
                </div>
                <div class="one-fourth">
                	<div class="widget">
                        <h3>Quick Links</h3>
                        <ul class="arrow">
                            <a href="#"><li>Sign Up</li></a>
                        <a href="#"><li>Member Login</li></a>
                        <a href="#"><li>Support</li></a>
                        <a href="#"><li>Contact Us</li></a>
                        <a href="#"><li>Terms and Conditions</li></a>
                    </ul>

                    </div>
                </div>
                <div class="one-fourth">
                	<div class="widget twitter-widget">
                    	<h3>Social Media Share</h3>
                        <div class="tweet"></div>
                    </div>
                </div>
                <div class="one-fourth column-last">
                	<div class="widget contact-info">
                    	<h3>Contact Info</h3>
                        <p class="address"><strong>Address:</strong> 123 Street, Brong Ahafo, Ghana</p>
                        <p class="phone"><strong>Phone:</strong> +233208 312 264</p>
                        <p class="email"><strong>Email:</strong> <a href="mailto:info@letsliftgh.com">info@letsliftgh.com</a></p>
                        <div class="social-links">
                        	<h4>Follow Us</h4>
                            <ul>
                            	<li class="twitter"><a href="#" title="Twitter" target="_blank">Twitter</a></li>
                                <li class="facebook"><a href="#" title="Facebook" target="_blank">Facebook</a></li>
                                <li class="youtube"><a href="#" title="YouTube" target="_blank">YouTube</a></li>
                                <li class="skype"><a href="#" title="Skype" target="_blank">Skype</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end footer top -->

            <!-- begin footer bottom -->
            <div id="footer-bottom">
            	<div class="one-half">
                	<p>Copyright &copy; 2015 Letsliftgh. Powered by <a href="http://www.blanqcheq.com">Blanqcheq</a>.</p>
                </div>

                <div class="one-half column-last">
                	<nav id="footer-nav">
                        <ul>
                            <li><a href="#">Home</a> &middot;</li>
                            <li><a href="#">About Us</a> &middot;</li>
                            <li><a href="#">Privacy Policy</a> &middot;</li>
                            <li><a href="#">FAQs</a> &middot;</li>
                            <li><a href="#">Support</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
            <!-- end footer bottom -->
        </div>
	</footer>