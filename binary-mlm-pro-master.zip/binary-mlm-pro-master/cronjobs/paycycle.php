<?php 
require_once('../../../../wp-config.php');
wpmlm_run_pay_cycle();
?>