<?php 
require_once('../../../../wp-config.php');
mlmDistributeCommission();
mlmDistributeBonus();
?>