<?php 
function adminMLMUsers()
{?>
<div class="userslist">
	<div class="heading">
		<div id="icon-users" class="icon32"></div>
		<h1>MLM Users</h1>
	</div>






</div>





<?php 
}
?>