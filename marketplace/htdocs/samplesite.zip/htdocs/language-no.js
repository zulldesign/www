//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Beklager, men handekurven er full, vennligst g� til kassen.";
strAdded  = " Legg til i handlekurven.";
strRemove = "Klikk 'Ok' for � slette varen fra handlekurven.";
strILabel = "Produkt Id";
strDLabel = "Produkt Navn/Beskrivelse";
strQLabel = "Antall";
strPLabel = "Pris";
strSLabel = "Forsendelse";
strRLabel = "Ta ut av handlekurven";
strRButton= "Slett";
strSUB    = "SUBTOTAL";
strSHIP   = "FORSENDELSE";
strTAX    = "MOMS";
strTOT    = "TOTAL";
strErrQty = "Ugyldig Antall.";
strNewQty = 'Venligst angi antall:';

Language = 'no';
bLanguageDefined = true;
