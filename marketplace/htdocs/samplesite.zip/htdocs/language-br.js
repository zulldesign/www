//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Desculpe, seu carrinho est� cheio, por favor v� at� o caixa.";
strAdded  = " adicionado ao seu carrinho.";
strRemove = "Clique 'Ok' para remover este produto de seu carrinho.";
strILabel = " Id do Produto";
strDLabel = "Nome do Produto/Descri��o";
strQLabel = "Quantidade";
strPLabel = "Pre�o";
strSLabel = "Envio";
strRLabel = "Remover do Carrinho";
strRButton= "Remover";
strSUB    = "SUBTOTAL";
strSHIP   = "Envio";
strTAX    = "IMPOSTO";
strTOT    = "TOTAL";
strErrQty = "Quantidade inv�lida.";
strNewQty = 'Por favor digite uma nova Quantidade:';

Language = 'br';
bLanguageDefined = true;


