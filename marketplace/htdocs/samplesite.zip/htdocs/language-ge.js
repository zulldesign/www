//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Oh, Ihr Warenkorb ist voll, bitte gehen Sie zur Kasse!";
strAdded  = " - dieser Artikel wurde in Ihren Warenkorb aufgenommen.";
strRemove = "Bitte drüSie 'Ok', um das Produkt zu entfernen.";
strILabel = "PRODUKT";
strQLabel = "ANZAHL";
strDLabel = "BESCHREIBUNG";
strPLabel = "PREIS";
strSLabel = "VERSANDKOSTEN";
strRLabel = "WARENKORB";
strRButton= "ENTFERNEN";
strSUB    = "ZWISCHENSUMME";
strSHIP   = "VERSANDKOSTEN";
strTAX    = "MwSt.:";
strTOT    = "TOTAL";
strErrQty = "Ungü Anzahl";
strNewQty = 'Bitte geben Sie eine neue Anzahl ein:';

Language = 'ge';
bLanguageDefined = true;


