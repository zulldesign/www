//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Je mi ��to, ale V� ko��k je u� pln�. Pokra�ujte pros�m k pokladni.";
strAdded  = " bolo pridan� do ko��ka.";
strRemove = "Kliknite na 'OK' pre vymazanie tejto polo�ky z ko��ka.";
strILabel = "Id produktu";
strDLabel = "Meno produktu/popis";
strQLabel = "Mno�stvo";
strPLabel = "Cena";
strSLabel = "Doprava";
strRLabel = "Vybra� z ko��ka";
strRButton= "Vybra�";
strSUB    = "MEDZIS��ET";
strSHIP   = "DOPRAVA";
strTAX    = "DA�";
strTOT    = "CELKOM";
strErrQty = "Neplatn� mno�stvo.";
strNewQty = 'Pros�m zadajte nov� mno�stvo:';

Language = 'sk';
bLanguageDefined = true;

