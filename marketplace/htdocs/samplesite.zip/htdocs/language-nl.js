//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Sorry, Uw winkelwagen is vol, gaat u aub naar de Kassa !!!";
strAdded  = " aan uw winkelwagen toegevoegd.";
strRemove = "Klik op 'Ok' om dit product uit uw winkelwagen te verwijderen.";
strILabel = "Bestelcode";
strQLabel = "Aantal";
strDLabel = "Product Omschrijving";
strPLabel = "Prijs";
strSLabel = "Verzendkosten";
strRLabel = "Verwijder";
strRButton= "Verwijder";
strSUB    = "SUBTOTAAL";
strSHIP   = "VERZENDKOSTEN";
strTAX    = "BTW";
strTOT    = "TOTAAL";
strErrQty = "Ongeldig Aantal.";
strNewQty = 'Voer een nieuw aantal in aub:';

Language = 'nl';
bLanguageDefined = true;

