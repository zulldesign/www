//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Il tuo Carrello \350 al massimo della capienza, procedi con l'Invio Ordine.";
strAdded  = " nel tuo Carrello.";
strRemove = "Clicca su 'OK' per rimuovere il Prodotto dal tuo Carrello.";
strILabel = "ID Prodotto";
strDLabel = "Descrizione Prodotto";
strQLabel = "Quantit\340";
strPLabel = "Prezzo";
strSLabel = "Spese di Spedizione";
strRLabel = "Rimuovi dal Carrello";
strRButton= "Rimuovi";
strSUB    = "SUBTOTALE";
strSHIP   = "SPESE DI SPEDIZIONE";
strTAX    = "I.V.A.";
strTOT    = "TOTALE";
strErrQty = "Quantit\340 Errata.";
strNewQty = 'Per favore inserisci la nuova quantit\340:';

Language = 'it';
bLanguageDefined = true;

