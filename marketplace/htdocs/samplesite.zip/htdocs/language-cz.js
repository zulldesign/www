//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Je mi l�to, V� ko��k je ji� pln�. Pokra�ujte pros�m k pokladn�.";
strAdded  = " bylo p�id�no do ko��ku.";
strRemove = "Klikn�te na 'OK' pro vymaz�n� t�to polo�ky z ko��ku.";
strILabel = "Id produktu";
strDLabel = "Jm�no produktu/popis";
strQLabel = "Mno�stv�";
strPLabel = "Cena";
strSLabel = "Doprava";
strRLabel = "Odebrat z ko��ku";
strRButton= "Odebrat";
strSUB    = "MEZISOU�ET";
strSHIP   = "DOPRAVA";
strTAX    = "DA�";
strTOT    = "CELKEM";
strErrQty = "Neplatn� mno�stv�.";
strNewQty = 'Pros�m zadejte nov� mno�stv�:';

Language = 'cz';
bLanguageDefined = true;

