//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//                                                                     ||
//      Script translated in romanian by Robert H.                     ||
//               robert.horvath@klausenburg.com                         ||
//---------------------------------------------------------------------||
strSorry  = "Sajn�ljuk, de az �n bev�s�rl�kosara megtelt. K�rj�n fizessen most.";
strAdded  = " hozz�adva a bev�s�rl�kos�r tartalm�hoz.";
strRemove = "Kattintson az OK-ra az �ru t�rl�s�hez.";
strILabel = "Term�kazonos�t�";
strDLabel = "�ru neve/le�r�sa";
strQLabel = "Mennyis�g";
strPLabel = "�r";
strSLabel = "Post�z�s";
strRLabel = "Kos�rb�l t�r�l";
strRButton= "T�r�l";
strSUB    = "�FA N�LK�L";
strSHIP   = "POST�Z�S";
strTAX    = "�FA";
strTOT    = "V�G�SSZEG";
strErrQty = "Nem megengedett mennyis�g.";
strNewQty = 'K�rj�k adja meg a k�v�nt mennyis�get.';

Language = 'hu';
bLanguageDefined = true;
