//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "Lo siento, el carro est� lleno. Proceda con la compra";
strAdded  = " a�adido al carro de compra.";
strRemove = "Pulse 'Aceptar' para eliminar este producto del carro de la compra.";
strILabel = "Referencia";
strDLabel = "Descripci�n";
strQLabel = "Cantidad";
strPLabel = "Precio Unit.";
strSLabel = "Gastos Env�o";
strRLabel = "Eliminar";
strRButton= "Eliminar";
strSUB    = "SUBTOTAL";
strSHIP   = "GASTOS DE ENV�O";
strTAX    = "IVA";
strTOT    = "TOTAL";
strErrQty = "Cantidad incorrecta";
strNewQty = 'Por favor, introduzca una nueva cantidad:';

Language = 'sp';
bLanguageDefined = true;

