//=====================================================================||
//       NOP Design JavaScript Shopping Cart Language Pack             ||
//                                                                     ||
//                      Language Strings                               ||
//                     ------------------                              ||
// Strings displayed to end users, in language specific encoding.      ||
// only modify these strings if you wish to change language specific   ||
// wording for your site.  If you add a new language, please send it   ||
// back to NOP Design (http://www.nopdesign.com/forum) so we can add   ||
// it to the distribution.                                             ||
//---------------------------------------------------------------------||
strSorry  = "I'm Sorry, your cart is full, please proceed to checkout.";
strAdded  = " added to your shopping cart.";
strRemove = "Click 'Ok' to remove this product from your shopping cart.";
strILabel = "Product Id";
strDLabel = "Product Name/Description";
strQLabel = "Quantity";
strPLabel = "Price";
strSLabel = "Shipping";
strRLabel = "Remove From Cart";
strRButton= "Remove";
strSUB    = "SUBTOTAL";
strSHIP   = "SHIPPING";
strTAX    = "TAX";
strTOT    = "TOTAL";
strErrQty = "Invalid Quantity.";
strNewQty = 'Please enter new quantity:';

Language = 'en';
bLanguageDefined = true;

