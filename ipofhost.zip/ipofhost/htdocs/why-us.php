<?
// This is used to constuct the cPanel login ur>ol
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
<head>
<title>Why Us?</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700' rel='stylesheet' type='text/css'>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="js/go-top.js"></script>
</head>
<body>
<div id="top">
<div class="main">
  <div class="header">
    <div class="header-holder">
         <div class="header-login"><a href="signup.php">Sign up</a> | <a href="http://cpanel.<? echo "$yourdomain" ;?>">Login</a></div>
    <div class="ground"></div>
   <div class="header-holder-in">
    <div class="logo"><a href="index.php"><?echo $yourdomain;?></a></div>
      <div style="float:right;">
        <? include ('navigation.php'); ?>
        </div>
        <div class="ground"></div>
      </div>
      <div class="head2">
      <div class="text">
      <h2>Why Us</h2>
      <p>We no that it's hard to find a good free hosting provider. Here are some things you must know before making your decision!</p>
	  </div>
      </div>
      <div class="ground"></div>
    </div>
  </div>
    <div class="body">
    <div class="body-holder">
    <div class="body-large">
		<h2>The top 7 reasons</h2>
	<div id="links">
    <ul>
      <li>
      <img src="images/wu-instantactivation.png">
      <a>1. Instant activation
        <em>You will get your account up and running within 3 minutes right after you submit your account information.</a></li> 
      <hr />
      <li>
      <img src="images/wu-cloudhost.png">
      <a>2. Cloud Hosting
        <em>Our free hosting plan is based on Cloud, which means, our servers are integrated to share all resources providing high resource availability.</a></li> 
      <hr />
      <li>
      <img src="images/wu-security.png">
      <a>3. Security
        <em>100% secure hosting with 24/7 monitoring, firewal & hotlink protection.</a></li> 
      <hr />
      <li>
      <img src="images/wu-complete.png">
      <a>4. Complete Solution
        <em>We provide a complete free hosting solution, easy-to-use tools for building, managing and tracking powered by quality technical support!</a></li> 
      <hr />
      <li>
      <img src="images/wu-professional.png">
      <a>5. Professional
        <em>You'll have access to VistaPanel, a control panel packed with all the features you'll ever need! Website builder, SEO tools, Script installer...</a></li> 
      <hr />
      <li>
      <img src="images/wu-lowcostupgrades.png">
      <a>6. Low-cost upgrades
        <em>After you're website becomes popular, and when you're ready to upgrade, we got the best shared, vps & dedicated plans for the lower prices!</a></li> 
      <hr />
      <li>
      <img src="images/wu-professionalsupport.png">
      <a>7. Professional Support
        <em>You hate waiting hours and maybe days to get an answer? So do we! That's why we provide 24/7 fast response support service.</a></li> 
    </ul>
    </div> 
      <div class="ground"></div>
	<div class="hr"></div>    
    <h2>Why us</h2>
    <p>We use a powerful cluster of web servers that are all interconnected to act as one giant super computer. This technology is years ahead of most other hosting companies. Combining the power of many servers creates lightning fast website speed. Not only is the service extremely fast, it is resistant to failures that effect 'single server' hosting, used by most other free and paid hosting providers. If one of our clustered servers were to fail or have a problem, your website will continue to run normally using the working servers!</p>    
    </div>
      <div class="ground"></div>
    </div>
    <div class="ground"></div>
    </div>
    <div class="footer">
    <div class="footer_resize">
      <p class="copyright">© <?echo $yourdomain;?>, Powered By <a href="https://ifastnet.com">iFastNet</a>.</p>
    <div class="social">
	  <ul>
		<li class="youtube">
      <a href="" target="_blank">YouTube</a>
    </li>
    <li class="googleplus">
      <a href="" target="_blank">Google +r</a>
    </li>
    <li class="twitter">
      <a href="" target="_blank">Twitter</a>
    </li>
    <li class="facebook">
      <a href="" target="_blank">Facebook</a>
		</li>
	  </ul>
	</div>
      <div class="ground"></div>
    </div>
    <div class="ground"></div>
  </div>
</div>
<a href="#" class="go-top">Go Top</a>
</body>
<!-- Template designed by iFastNet (iFastNet.com) exclusively for MyOwnFreeHost.com users -->
</html>