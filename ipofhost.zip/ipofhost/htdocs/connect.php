<?php

$con = mysqli_connect("sql110.ipofhost.com","ipof_23047656","wednesday200155","ipof_23047656_tmnseri");
if (!$con) {
	die("Connection failed: " . mysqli_connect_error());
}
 
?>