        <div class="menu">
          <ul>
            <li><a href="index.php"><span>Home</span></a></li>
            <li><a href="free-hosting.php"><span>Free Hosting</span></a></li>                       
            <li><a href="premium-hosting.php"><span>Premium Hosting</span></a></li>
            <li><a href="domains.php"><span>Domain Names</span></a></li>
            <li><a href="why-us.php"><span>Why Us</span></a></li>
            <li><a href="support.php"><span>Support</span></a></li>
          </ul>
        </div>