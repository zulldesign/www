<?php
session_start();
include_once("database/db_conection.php");
//here getting result from the post array after submitting the form.
$username = mysqli_real_escape_string($db_conn, $_POST['username']);
$password = md5(mysqli_real_escape_string($db_conn, $_POST['password']));
$email = mysqli_real_escape_string($db_conn, $_POST['email']);

//here query check weather if user already registered so can't register again.
$check_email_query = "select * from temp_users WHERE email='$email'";
$result = mysqli_query($db_conn, $check_email_query);

$row = mysqli_fetch_array($result);
$count = mysqli_num_rows($result);

$confirm_code = md5(unixtojd(rand()));

if ($count <= 0){
	mysqli_query($db_conn,"insert into temp_users (confirm_code,username,password,email) VALUE ('$confirm_code','$username','$password','$email')")or die(mysqli_error($db_conn));
	$_SESSION['user']=$username;
	$_SESSION['email']=$email;
	include_once("sendmail.php");
}else{
	echo 'false';
}

?>