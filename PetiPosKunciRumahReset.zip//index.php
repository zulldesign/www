<?php
session_start();
include_once("database/db_conection.php");
if(isset($_SESSION['user'])!="")
{
 header("Location: home.php");
}
// define variables and set to empty values
$nameErr = $emailErr = $passErr = "";
$username = $password = $email = "";  
if(isset($_POST['login'])){	
    $password=md5(mysqli_real_escape_string($db_conn,$_POST['password']));//same  
    $email=mysqli_real_escape_string($db_conn,$_POST['email']);//same
    $query="SELECT * FROM users WHERE email='$email'";  
    $result = mysqli_query($db_conn, $query);
    if(!$result) {
        die("Database query failed");
    }
    $row = mysqli_fetch_array($result);
   	//$_SESSION['user'] = $row['user_name'];
    
    if($row['password']== $password)
	 {
	  $_SESSION['user'] = $row['username'];
	  $_SESSION['email'] = $row['email'];
	  header("Location: home.php");
	 }
	 else
	 {
	  echo "<div role='alert' class='alert alert-warning alert-dismissible fade in'><strong>Hey !</strong> You Provided Wrong Details, Please try another one!</div>";
	 }
} 
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    
<link rel="stylesheet" href="css/app.v1.css" type="text/css" />
<style type="text/css">html {
    overflow-y: scroll;
background: url(images/shutterstock_4067401_b5c2014.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

</style>
</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <input class="btn btn-lg btn-success btn-block" type="submit" value="login" name="login" >
                            </fieldset>
                        </form>
                        <center><b>New User ?</b> <br></b><a href="register.php">Sign UP Here</a></center>
                        <center><b>Forgot Password ?</b> <br></b><a href="password.php">Click Here</a></center>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>
