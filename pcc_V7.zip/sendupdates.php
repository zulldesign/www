<?php
session_start();
include("pcc_config.php");
include("pcc_funs.php");
$link = dbconnect();
//Check for chat sessions created in last 20 secs
$wm = $_POST['wmid'];
$loggedinasoftime = time();

$q="INSERT INTO webmasterlog SET wmid = '$wm', loggedinasof = $loggedinasoftime ON DUPLICATE KEY UPDATE loggedinasof = $loggedinasoftime";
mysql_query($q);

$timetocheck = time() - 20;
//Check sites for the webmaster
$q="SELECT * FROM chatthreads WHERE wmid = '$wm' AND startedon > '$timetocheck'";
if($r=mysql_query($q))
{
	if(mysql_num_rows($r) > 0)
	{
		echo "yes";
	}
}

dbclose($link);
?>