<?php
//Site base url. This is where you are uploading all the script files. Do not forget the trailing '/'. It should start with 'http://'
$siteurl = "http://";

//No reply email. This is the email that will be used to send out all communications. Need not be a valid email. Just needs your domain name in it.
$noreply_email = "";

//Name of the site. What do you want to call the site? Something like - your domain Support Center or helpdesk or something like that. This will be shown at the top center of each page.
$sitename = "";

$dbhost = "";   //Host of the DataBase
$dbname = "";   //DB Name
$dbuser = "";   //DB user name
$dbpwd = "";    //DB user password

//Header of every email. This information will be attached to the top of each email going out to the users.
$email_header = <<<TXT
THIS IS NOT SPAM. THIS IS AN AUTOMATICALLY GENERATED EMAIL. PLEASE DO NOT REPLY.
--------------------------------------------------------------------------------

TXT;

//Footer of every email. Use this to enter typical anti-spam disclaimer required by anti-spam regulations. You can include ads also. Make sure your physical address is in this or you will be violating the Anti-SPAM regulations. Change the add at the bottom. Right now it is our hosting site. We will appreciate if you retain it! Do not change the link to our site. It is required as per the license agreement.
$email_footer = <<<TXT

---------------------------------------------

Anti-Spam Notice: This email is generated automatically when you requested for support using our support center or helpdesk application.
 
Address: <<< Your physical address goes here >>>


--------------------------------------------
Advertisement: Profit sharing host- http://www.ProfitSharingHost.com
--------------------------------------------

TXT;

//-----------DO NOT CHANGE ANYTHING FROM THIS LINE BELOW --------------
//-----------RETAIN THE LINK BELOW AS PER LICENSE AGREEMENT -------
$creditLink = "Helpdesk application powered by - http://www.monitor-line.com/contactus";

$email_footer .= $creditLink;

?>