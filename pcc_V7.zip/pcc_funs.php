<?php
//Functions included in this file
//Send plain email
function send_mail_plain($mailid,$fromid,$sub,$msg)
{
	global $email_header, $email_footer;
	//print "$mailid,$fromid,$sub,$msg";
  $headers  = "MIME-Version: 1.0\r\n";
  $headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
  /* additional headers */
  $headers .= "From: $fromid\r\n";
  $headers .= "Reply-To: $fromid\r\n";
	$msg = $email_header . $msg . $email_footer;
	//this will send mail to each person individually.
	$mailid=split(",",$mailid);
  for($i=0;$i<count($mailid);$i++)
  {
  	//echo"Message : $msg";
		$msg = $emailadcode . $msg;
		
    if(mail($mailid[$i], $sub, $msg,$headers))
  	{
  	}
  	else
  	{
  		print "<br>Error sending email to $mailid[$i]";
  		exit;
  	}
 	}
  return 1;
}

//function to reader contents of a file
function file_reader($fileurl)
{
	$file=fopen($fileurl,'r') or die("$fileurl File Does'nt Exists");
  if (filesize($fileurl) > 0 )
	{
  	$contents=fread($file,filesize($fileurl));
    fclose($file);
    return $contents;
  }
}

//function to establish a connection to MySQL and selecting a database to work
function dbconnect()
{
	global $siteadds,$dbhost,$dbname,$dbuser,$dbpwd;
	if($link = mysql_connect($dbhost,$dbuser,$dbpwd))
	{
		$res=mysql_select_db($dbname) or die(mysql_error());
		if($res)
			return $link;
	}
	else
		print "There is some internal error in retrieving the records. Sorry for the inconvinence.";
}
//function  to close the opened link
function dbclose($link)
{
	global $link;
	if(mysql_close($link))
	{}
}

//Show main page
function showMain()
{
	global $pagecontent, $sitename, $ticketrate, $default_user;

	
	
	$pagecontent .= <<<HTM
		<p><b><font size="4">Welcome to $sitename!</font></b></p>
		<p><font size="4">Setup an instant helpdesk/support center for your site(s) in minutes!</font></p>
		<p><font size="3" color="green"><b>Looking to add a simple free contact form to your site or looking for a feature-rich helpdesk or looking for a live help agent service, this is your one-stop shop!</b></font></p>
		<table summary="" align="center" border="0" cellpadding="10" cellspacing="10" width="70%">
			<tr>
				<td align="left">
					<p align="center"><font size="4" color="green"><u>Features</u></font></p>
					<p><img src="images/q-mark.jpg"><font size="3"> Completely anonymous - no one needs to share emails/phone numbers with each other if they don't want to.</font></p>
					<p><img src="images/q-mark.jpg"><font size="3"> Users need not waste time creating separate account logins to get support without compromising on information security.</font></p>
					<p><img src="images/q-mark.jpg"><font size="3"> Choose from Free (ads-supported) and Paid ($ticketrate Cents per ticket/chat session) option</font></p>
					<p><img src="images/q-mark.jpg"><font size="3"> Ticketing system as well as live agent (live help using chat) functionality - both are available in free and paid options.</font></p>
					<p><img src="images/q-mark.jpg"><font size="3"> Pay for service (SaaS - Software as a Service) model - no software purchase, no installations, no upgrades, no licese fees.</font></p>
					<p><img src="images/q-mark.jpg"><font size="3"> Setup unlimited helpdesks for any number of sites under one single webmaster account.</font></p>
					<p><img src="images/q-mark.jpg"><font size="3"> No chance of spam. No one can see each others emails or mis-use any contact information.</font></p>
					<p><img src="images/q-mark.jpg"><font size="3"> Complete CAPTCHA security to make sure real humans are creating support requests and not any automated bots.</font></p>
				</td>
			</tr>
		</table>
		<p><a href="index.php?a=wmjoin">Start with the setup here ...</a></p>
		<p>Existing webmasters? <a href="index.php?a=wmlogin">Login here ...</a></p>

HTM;

}

//Webmaster signup
function wmjoin()
{
	global $pagecontent, $default_user;
	
	$cbref=$_COOKIE["refeml"];
	if($cbref != "")
	{
		//$pagecontent .= "<p>Referral found - $cbref</P>";
	}
	else
	{
		//$pagecontent .= "<p>Referral NOT found. Using default.</P>";
		$cbref = $default_user;
	}
	
	$pagecontent .= <<<HTM
		<p><b>Webmasters Join Here</b></p>
		<form action="index.php?a=wmjoin1" method="post">
			<p>Select Username: <input type="text" name="wmid" size="20" maxlength="20"><br>
			(Note: Less than 20 characters. Use only numbers and alphabets. No Spaces.)</p>
			<p>Enter Email: <input type="text" name="wmeml" size="50" maxlength="200"><br>
			(Note: If you want multiple support staff to support your users, create an email group like google-group or some form of distribution list and use the distribution list email address here. This way, when a new support request is created, automatically, all the support staff will be notified and they can act on the request. However, also be careful here because the activation code (also used as passcode later) will be mailed to this email address. We will send the activation code to this email.)</p>
			<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
			Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
			<p>(referred by - $cbref)</p>
			<p><input type="submit" value="Send Activation Code"></p>
		</form>
	
HTM;

}

//Save the webmaster information
function wmjoin1($un, $ueml)
{
	global $pagecontent, $noreply_email, $sitename, $siteurl, $default_user;
	$cbref = $_COOKIE["refeml"];
	if($cbref != "")
	{
		//$pagecontent .= "<p>Referral found - $cbref</P>";
	}
	else
	{
		//$pagecontent .= "<p>Referral NOT found. Using default.</P>";
		$cbref = $default_user;
	}

	//Check security code
	if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
		return;
	}
	//Variables cannot be blank
	if($un == "" or $ueml == "")
	{
		$pagecontent .= "<p>ERROR! All fields are necessary.";
		return;
	}
	//Username cannot have anything but numbers and letter
	if(!ctype_alnum($un))
	{
		$pagecontent .= "<p>ERROR! Username must have alphabets and/or digits.";
		return;
	}
	$wmjoinedon = time();
	$cbcode=rand(0,9);
 	$cbcode.=rand(0,9);
 	$cbcode.=rand(0,9);
 	$cbcode.=rand(0,9);
 	$cbcode.=rand(0,9);
 	$cbcode.=rand(0,9);
 	$cbcode.=rand(0,9);
 	$cbcode.=rand(0,9);
 	$cbcode.=rand(0,9);
 	$cbcode.=rand(0,9);

	
	$q="INSERT INTO webmasters SET wmid = '$un', wmeml = '$ueml', wmjoinedon = '$wmjoinedon', wmaccesscode = '$cbcode', ref='$cbref'";
	if($r=mysql_query($q))
	{
		$sub = $sitename . " Access code";
		$msg = <<<TXT

This is your Access Code for $sitename

Username = $un
Email = $ueml
Access Code/Pass code = $cbcode

Please keep this code safe as this will be required to access the messages related to your site.

You can access the site here - $siteurl

Thanks for your participation!

Site Admin
$sitename
$siteurl

TXT;

		if(send_mail_plain($ueml,$noreply_email,$sub,$msg))
		{
			$pagecontent .= "SUCCESS! You must have received your access code in your email. Please check it to come back and add your sites. You will need it to perform every action on this site.";
		}
		
		//Send out referral mails
		if(function_exists("send_ref_mail_notices"))
		{
			send_ref_mail_notices($cbref);
		}
	}
	else
	{
		$pagecontent .= "ERROR! " . mysql_error();
	}
}

//Webmaster add new site
function wmaddsite()
{
	global $pagecontent, $sitename;
	$pagecontent .= getMemMenu();
	$pagecontent .= <<<HTM
		<p><b>Webmasters Add Site</b></p>
		<p>Every new site that you want to use the $sitename service for, must be registered before the service can be used.</p>
		<form action="index.php?a=wmaddsite1" method="post">
			<p>Enter the site domain: <input type="text" name="wmsiteid" size="50" maxlength="200"></p>
			<p>Enter the URL for your Logo (please enter complete URL starting with http://): <br>
			<input type="text" name="wmsitelogo" size="50" maxlength="200"></p>
			<p><input type="submit" value="Add Site"></p>
		</form>
	
HTM;

}

//Save the new site information
function wmaddsite1()
{
	global $pagecontent, $noreply_email, $sitename, $siteurl;
	$pagecontent .= getMemMenu();
	
	$uname = $_SESSION['uname'];
	
	$siteid = $_POST['wmsiteid'];
	$sitelogo = $_POST['wmsitelogo'];
	$sitechat24X7 = $_POST['chat24X7'];
	if($sitechat24X7 == "Y")
	{
		$chat24X7flag = "Y";
	}
	else
	{
		$chat24X7flag = "N";
	}
	
	//Variables cannot be blank
	if($siteid == "")
	{
		$pagecontent .= "<p>ERROR! You must enter a site domain.";
		return;
	}

	$q1="INSERT INTO sites SET sitedomain = '$siteid', wmid = '$uname', sitelogo = '$sitelogo', chat24X7 = '$chat24X7flag'";
	if($r1=mysql_query($q1))
	{
		$pagecontent .= "SUCCESS! Your site was added successfully.";
	}
	else
	{
		$pagecontent.= "ERROR! " . mysql_error(); 
	}
}

//Show the contact center
function showcc($sid)
{
	global $pagecontent;
	if(checksite($sid) == false)
	{
		$pagecontent .= "<p>ERROR! This site is not registered.</p>";
		return;
	}
	$pagecontent .= <<<HTM
		<p><b>Welcome to the Contact Center for $sid!</b></p>
		<p>Please select from the following options:</p>
		<p><li><a href="index.php?a=createticket&siteid=$sid">Create a new ticket</a> - Use this option to contact the webmaster of $sid. A new discussion thread will be started.</li></p>
		<!-- <p><li><a href="index.php?a=checkticket&siteid=$sid">Check existing ticket</a> - Use this option to check the current status on previously started thread. You will need the thread ID that was sent in your email first time you started the thread.</li></p> -->
HTM;
	
}

//Create new thread of the support ticket
function createticket($sid)
{
	global $pagecontent, $sitename ;
	//Check site id
	if(checksite($sid) == false)
	{
		$pagecontent .= "<p>ERROR! This site is not registered.</p>";
		return;
	}
	
	//Get logo of the site
	$logourl = getlogourl($sid);
	if($logourl != "")
	{
		$logohtml = <<<HTM
			<center><img src="$logourl" alt="$sid"></center>
			
HTM;
	}
	$pagecontent .= <<<HTM
		$logohtml
		<p><font size="4"><b>Welcome to Helpdesk of <u>$sid</u></b></font></p>
		<p><font size="2">Powered by <a href="index.php" target="_blank">$sitename</a>.</font></p>
		<p><b>Create new ticket/thread for the support staff at <u>$sid</u>.</b></p>
		<form action="index.php?a=createticket1" method="post">
			<p>Enter your Email: <input type="text" name="ueml" size="50" maxlength="200"><br>
			(Note: This is the email where we will notify you when the support staff responds to your message. Please enter carefully. If the email is misspelled, we will not be able to contact you back.)</p>
			<p>Enter subject: <input type="text" name="usub" size="60" maxlength="200"><br>
			(Note: Briefly describe your support request.)</p>
			<p>Enter message text: <br>
			<textarea name="utxt" cols="60" rows="10"></textarea></p>
			<input type="hidden" name="sid" value="$sid">
			<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
			Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
					
			<p><input type="submit" value="Submit"></p>
			
		</form>
HTM;
}

//Save the ticket
function createticket1($uemail, $usubject, $utext, $sid)
{
	global $pagecontent, $noreply_email, $sitename, $siteurl, $ticketrate, $adsFlag;
	//Security code must match
	//Check security code
	if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
		return;
	}
	//All fields are mandatory
	if($uemail == "" or $usubject == "" or $utext == "" or $sid == "")
	{
		$pagecontent .= "<p>ERROR! All fields are mandatory.</p>";
		return;
	}
	//Clean the contents
	$uemail = strip_tags($uemail);
	$usubject = strip_tags($usubject);
	$utext = strip_tags($utext);
	//Entry date and time
	$msgenteredon = time();
	//Create random code
	$rndcd = rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	
	//Insert and create thread id
	$q="INSERT INTO threads SET startedon = '$msgenteredon', siteid = '$sid', emailid = '$uemail', passcode = '$rndcd'";
	if($r=mysql_query($q))
	{
		//Now enter the message
		$lastthreadid = mysql_insert_id();
		if($lastthreadid > 0)
		{
			$q1="INSERT INTO messages SET threadid = $lastthreadid, addedon = '$msgenteredon', subj = '$usubject', msgtext = '$utext'";
			if($r1=mysql_query($q1))
			{
				//Now send mail to the support staff
				//Read the webmaster's email address and id
				$q2="SELECT a.wmeml, a.wmid FROM webmasters a, sites b WHERE b.sitedomain = '$sid' AND a.wmid = b.wmid";
				if($r2=mysql_query($q2))
				{
					$wmdata = mysql_fetch_array($r2);
					$wmeml = $wmdata[0];
					$wmid = $wmdata[1];
					
					//Update the balance of the webmaster if positive balance exists
					if(function_exists("update_balance"))
					{
						if($adsFlag == "Y")
						{
						}
						else
						{
							update_balance($wmid, $ticketrate);
							update_ref_credits($wmid);
						}
					}
					
					if($wmeml != "")
					{
						//Build subject line
						$sub = $sid . " New support ticket No. " . $lastthreadid;
						//Build the reply link
						//For webmaster
						$replylink = $siteurl . "index.php?a=showthread&threadid=$lastthreadid&c=$rndcd&wmaccess=1";
						$replylinkuser = $siteurl . "index.php?a=showthread&threadid=$lastthreadid&c=$rndcd";
						$msg .= <<<TXT

A new support ticket is created at $sitename for your site $sid

In order to respond to this ticket, please click on the link below:

$replylink

$sitename


TXT;
						if(send_mail_plain($wmeml,$noreply_email,$sub,$msg))
						{
							$pagecontent .= "<p>SUCCESS! Your message added successfully. Site support staff has been notified. Please wait for response.</p>";
							//Now send an email to the user also
							$sub = $sid . " Support request created - No. " . $lastthreadid;
							$msg = <<<TXT

Thank you for using $sitename to submit your support request regarding $sid.

You or someone using this email created a support ticket.

Note that support staff has been notified and you should get a response from them soon. 

You can check the status of your support ticket using the following link:

$replylinkuser

You will be notified once your support request has been updated by the support staff.

$sitename


TXT;
							if(send_mail_plain($uemail,$noreply_email,$sub,$msg))
							{
								$pagecontent .= "<p>SUCCESS! An email confirmation with the link to check updates is also sent to $uemail.</p>";
							}
						}
					}
				}
				
			}
			else
			{
				$pagecontent .= "ERROR! " . mysql_error();
			}
		}
		else
		{
			$pagecontent .= "ERROR! " . mysql_error();
		}
	}

}

//Show the ticket information
function showthread()
{
	global $pagecontent, $adsFlag, $ticketrate;
	$tid = $_GET['threadid'];
	$wac = $_GET['wmaccess'];
	$pcd = $_GET['c'];
		
	//Thread ID is mandatory
	if($tid == "" or $pcd == "")
	{
		$pagecontent .= "<p>ERROR! Ticket ID and/or passcode is missing. Email sent to you has these details. Please try again.</p>";
		return;
	}
	//Check if the email and the thread id match
	$q="SELECT * FROM threads WHERE threadid = $tid AND passcode = '$pcd'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) <= 0)
		{
			$pagecontent .= "<p>ERROR! Access denied.</p>";
			return;
		}
		else
		{
			//Read the site id
			$tiddata=mysql_fetch_array($r);
			$siteid = $tiddata['siteid'];
			$tstatus = $tiddata['status'];
			
			//Update the status and response time
			$rtime = time();
			$qu = "UPDATE threads SET status = 'Work in progress', respon = '$rtime' WHERE threadid = $tid AND status != 'Closed'";
			mysql_query($qu);
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! " . mysql_error();
		return;
	}
	
	//adsFlag to be set
	if(function_exists("checkwmbalance"))
	{
		$wmbal = checkwmbalance("", $siteid);
		if($wmbal < $ticketrate)
		{
			$adsFlag = "Y";
		}
	}
	
	//Do not show the reply button if thread is closed.
	$replyButtonCode = "<p><font color='blue'><b>This ticket is <i><u>$tstatus</u></i>.</b></font></p>";
	if($tstatus != 'Closed')
	{
		$replyButtonCode .= <<<HTM
		<form action="index.php?a=updateticket" method="post">
			<input type="hidden" name="wmaccess" value="$wac">
			<input type="hidden" name="t" value="$tid">
			<input type="hidden" name="c" value="$pcd">
			<p><input type="submit" value="Click here to update/reply"></p>
		</form>
		
		<p><a href="index.php?a=closeThread&t=$tid&c=$pcd">Click here to close this support request</a></p>

HTM;
	}
	
	
	$pagecontent .= <<<HTM
		<p><b>Support Center for <font color="#006600">$siteid</font></b></p>	
		<p><b>Showing support request no. $tid</b> - Messages are shown in sorted manner. The most recent message is on top.</p>
		$replyButtonCode
		<hr size="1">
HTM;

	//Select all messages under this thread
	$q="SELECT * FROM messages WHERE threadid = $tid ORDER BY msgid DESC";
	if($r=mysql_query($q))
	{
		while($tdata=mysql_fetch_array($r))
		{
			$timeadded = $tdata['addedon'];
			$msgsub = $tdata['subj'];
			$msgtxt = $tdata['msgtext'];
			$msgflag = $tdata['wmaccess'];
			if($msgflag == "1")
			{
				$addedby = "<font color='#006600'><b>Support Staff</b></font>";
				$addedbycolor = "#006600";
			}
			else
			{
				$addedby = "User";
				$addedbycolor = "#000000";
			}
			$datetoshow = date("F j, Y, g:i a", $timeadded);

			$msgtextbox = get_message_text_box($msgtxt, $addedbycolor);
			
			$pagecontent .= <<<HTM
				<p>Message added on - $datetoshow<br>
				<p>Message added by - $addedby</p>
				<p>Subject - $msgsub<br>
				<p>Text - <br>$msgtextbox
				<hr size="1">
HTM;
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! ". mysql_error();
	}
}

//Update the thread with new message
function updatethread()
{
	global $pagecontent, $adsFlag, $ticketrate;
	$tid = $_POST['t'];
	$wac = $_POST['wmaccess'];
	$pcd = $_POST['c'];
	
	//First check the thread id and email match
	//Check if the passcode and the thread id match
	$q="SELECT * FROM threads WHERE threadid = $tid AND passcode = '$pcd'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) <= 0)
		{
			$pagecontent .= "<p>ERROR! Access denied.</p>";
			return;
		}
		else
		{
			$threaddata=mysql_fetch_array($r);
			$sid = $threaddata['siteid'];
			
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! " . mysql_error();
		return;
	}
	
	//adsFlag to be set
	if(function_exists("checkwmbalance"))
	{
		$wmbal = checkwmbalance("", $sid);
		if($wmbal < $ticketrate)
		{
			$adsFlag = "Y";
		}
	}
	//Select the message details
	$q="SELECT * FROM messages WHERE threadid = $tid ORDER BY addedon DESC";
	if($r=mysql_query($q))
	{
		while($tdata=mysql_fetch_array($r))
		{
			$subje = $tdata['subj'];
			$mt = $tdata['msgtext'];
			$md = date("F j, Y, g:i a", $tdata['addedon']);
			$wma = $tdata['wmaccess'];
			
			if($wma)
			{
				$fc = "#009900";
			}
			else
			{
				$fc = "#000000";
			}
			
			$msgtextbox = get_message_text_box($mt, $fc);
			
			$resubje = "Re: " . $subje;
			$historytext .= <<<HTM
			<hr width="50%" size="1">
			<font color="$fc">
			<p>$md</p>
			<p>$resubje</p>
			<p>$msgtextbox</p>
			</font>
HTM;
			
		}
	}
	
	//Show the form to enter info
	$pagecontent .= <<<HTM
		<p><b>Updating support request no. - $tid</b></p>
		<form action="index.php?a=updateticket1" method="post">
			<input type="hidden" name="wmaccess" value="$wac">
			<input type="hidden" name="t" value="$tid">
			<input type="hidden" name="c" value="$pcd">
			<input type="hidden" name="s" value="$resubje">
			<p>Subject: $resubje</p>
			<p>Enter text: <br>
			<textarea name="textre" cols="50" rows="10"></textarea></p>
			<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
			Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
			<p><input type="submit" value="Submit"></p>
			<p><u>History:</u></p>
			$historytext
		</form>
HTM;
}

//Update the thread
function updatethread1()
{
	global $pagecontent, $noreply_email, $sitename, $siteurl, $adsFlag, $ticketrate;
	//Check security code
	if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
		return;
	}
	
	$tid = $_POST['t'];
	$pcd = $_POST['c'];
	$sub = $_POST['s'];
	$wac = $_POST['wmaccess'];
	$ret = $_POST['textre'];
		
	//All fields are mandatory
	if($tid == "" or $pcd == "" or sub == "" or $ret == "")
	{
		$pagecontent .= "<p>ERROR! All fields are necessary.</p>";
		return;
	}
	//Check if the passcode and the thread id match
	$q="SELECT * FROM threads WHERE threadid = $tid AND passcode = '$pcd'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) <= 0)
		{
			$pagecontent .= "<p>ERROR! Access denied.</p>";
			return;
		}
		else
		{
			//Read the siteid and email
			$tdata1=mysql_fetch_array($r);
			$sid = $tdata1['siteid'];
			$eml = $tdata1['emailid'];
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! " . mysql_error();
		return;
	}
	
	//adsFlag to be set
	if(function_exists("checkwmbalance"))
	{
		$wmbal = checkwmbalance("", $sid);
		if($wmbal < $ticketrate)
		{
			$adsFlag = "Y";
		}
	}
	
	//Select email of the webmaster from the siteid
	$q="SELECT a.wmeml FROM webmasters a, sites b WHERE b.sitedomain = '$sid' AND a.wmid = b.wmid";
	if($r=mysql_query($q))
	{
		$wmemdata=mysql_fetch_array($r);
		$wmasteml = $wmemdata['wmeml'];
	}
	//Now save the message
	$addedon = time();
	$q="INSERT INTO messages SET threadid = $tid, wmaccess = '$wac', addedon = '$addedon', subj = '$sub', msgtext = '$ret'";
	if($r=mysql_query($q))
	{
		$pagecontent .= "<p>SUCCESS! Message updated.</p>";
		//Now send email to the user indicating the same
		$emlsub = $sid . " Support request is updated - No. " . $tid;
		//Link for webmaster
		$tlinkwm = $siteurl . "index.php?a=showthread&threadid=$tid&c=$pcd&wmaccess=1";
		$tlink = $siteurl . "index.php?a=showthread&threadid=$tid&c=$pcd";
		$emlmsg = <<<TXT

You had created a support request number $tid regarding $sid. 

You are receiving this email because that support ticket has been updated.

This is the message that was updated on the support request:

"$ret"

Please click on the link below or copy paste it in your browser if you wish to respond to this message or update the ticket further:

$tlink

Thank you for your participation!

$sitename


TXT;
		if(send_mail_plain($eml,$noreply_email,$emlsub,$emlmsg))
		{
			$pagecontent .= "<p>SUCCESS! An email is sent to the user.</p>";
			
			//Send email to the webmaster
			$emlmsg = <<<TXT

Your support request is updated. Please click on the link below to check the support request:

$tlinkwm

Thank you for your participation!

$sitename


TXT;

			if(send_mail_plain($wmasteml,$noreply_email,$emlsub,$emlmsg))
			{
				$pagecontent .= "<p>SUCCESS! An email is also sent to the support staff.</p>";
			}
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! ". mysql_error();
	}
}

//Check the site
function checksite($c)
{
	$q="SELECT * FROM sites WHERE sitedomain = '$c'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}	
	return false;
}

function wmrtrpasscode()
{
	global $pagecontent;
	$pagecontent .= <<<HTM
		<form action="index.php?a=wmrtrpasscode1" method="post">
			<p><font color="green" size="4"><b>Webmasters Retrieve Passcode</b></font></p>
			<p>Enter Email: <input type="text" name="wmeml" size="50" maxlength="200"><br>
			(We will send the passcode to this email. This must match the email on file with us.)</p>
			<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
			Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
			<p><input type="submit" value="Send the Passcode"></p>
		</form> 
HTM;
}

function wmrtrpasscode1($eml)
{
	global $pagecontent, $noreply_email, $sitename, $siteurl;
	//Check security code
	if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
		return;
	}
	
	//Check email
	if($eml == "")
	{
		$pagecontent .= "<p>ERROR! Email is not provided.</p>";
		return;
	}
	//Select the passcode
	$q="SELECT wmaccesscode FROM webmasters WHERE wmeml = '$eml'";
	if($r=mysql_query($q))
	{
		$wdata=mysql_fetch_array($r);
		$wmacode = $wdata['wmaccesscode'];
		if($wmacode != "")
		{
			$esub = $sitename . " Passcode notification";
			$emsg = <<<TXT
			
This is the passcode you requested: $wmacode

You can log back in at - $siteurl

Site Admin
$sitename
$siteurl

TXT;

			if(send_mail_plain($eml, $noreply_email, $esub, $emsg))
			{
				$pagecontent .= "<P>SUCCESS! Your passcode has been emailed to $eml.</p>";
			}
			else
			{
				$pagecontent .= "<P>ERROR! Email could not be sent. Contact Site Admin.</p>";
				return;
			}
		}
		else
    {
    	$pagecontent .= "<p>ERROR! " . mysql_error();
    }
	}
	else
	{
		$pagecontent .= "<p>ERROR! " . mysql_error();
	}
}

//Login
function login()
{
	global $pagecontent;
	$pagecontent .= <<<HTM
		<p><font size="3"><b>Login Form</b></font></p>
		<form action="index.php?a=login1" method="post">
			<p>Email address - <input type="text" name="uname" size="50" maxlength="200"></p>
			<p>Passcode - <input type="password" name="upass" size="20" maxlength="30"></p>
			<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
			Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>			
			<p><input type="submit" value="Login"></p>
		</form>
		<p align="center">Forgot passcode? <a href="index.php?a=wmrtrpasscode">retrieve passcode here ...</a></p>
HTM;

}

function login1($cbuname, $cbupass)
{
	global $pagecontent;
	//Check security code
	if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
		return;
	}
	
	$q="SELECT * FROM webmasters WHERE wmeml = '$cbuname'";
	if($r=mysql_query($q))
	{
		$cbudata = mysql_fetch_array($r);
		$cbpass = $cbudata['wmaccesscode'];
		$cbmemid = $cbudata['wmid'];
		if($cbpass == $cbupass)
		{
			$_SESSION['ueml'] = $cbuname;
			$_SESSION['uname'] = $cbmemid;
			
			header("Location: index.php?a=mem");
		}
		else
		{
			$pagecontent .= "<p>ERROR! Username and/or passcode incorrect.";
		}
	}
	else
	{
		$pagecontent .= mysql_error();
	}
}

function mem()
{
	global $pagecontent;
	$pagecontent .= getMemMenu();
	$pagecontent .= showSellerDashboard();
	
	if(file_exists("pcc_money_funs.php"))
	{
		$pagecontent .= showBalance();
	}
	
}

function check_login()
{
	$flag = false;
	if(isset($_SESSION['uname']))
	{
		$flag = true;
	}
	return $flag;
}

function getMemMenu()
{
	global $baseurl;

	$uname = $_SESSION['uname'];
	
	$codetoreturn .= <<<HTM
		<p align="center">Hello <div id="wmid">$uname</div></p>
		<p align="center">(<a href="index.php?a=mem">Main Menu</a> : <a href="index.php?a=logoff">Logoff</a>)</p>
		<table summary="" align="center" border="0" cellspacing="20" cellpadding="2">
			<tr>
				<td bgcolor="#99FF99">
					<a href="index.php?a=wmaddsite">Add Site</a>&nbsp;<img src="images/q-mark.jpg" align="middle" width="15" alt="Use option to add new sites under your account. This step is mandatory before you can use helpdek or any other facility for that site.">
				</td>
				<td bgcolor="#99FF99">
					<a href="index.php?a=wmmanagesites">Get codes</a>&nbsp;<img src="images/q-mark.jpg" align="middle" width="15" alt="Use option to get code for your helpdesk and new/update feed that you can add to your site(s)">
				</td>
				<td bgcolor="#99FF99">
					<a href="index.php?a=wmsearchmsg">Search Messages</a>&nbsp;<img src="images/q-mark.jpg" align="middle" width="15" alt="Use option to add search support requests waiting for you.">
				</td>
				<!-- <td width="50%" bgcolor="#99FF99">
					<a href="index.php?a=manageNewsUpdates">News and updates</a>&nbsp;<img src="images/q-mark.jpg" align="middle" width="15" alt="Use option to add news/update entries for your sites. The feed is updated real time.">
				</td> -->
			</tr>
		</table>
		
		<script type="text/javascript" src="checkupdates.js"></script>
HTM;

	return $codetoreturn;
}

//Show the last n chat and helpdesk requests
function showSellerDashboard()
{
	global $baseurl;

	$uname = $_SESSION['uname'];
	
	//Build active threads table
	$activethreadstable = <<<HTM
		<table align="center" cellspacing="0" cellpadding="5" border="1">
			<tr>
				<td align="center">
					<b>Message ID</b>
				</td>
				<td align="center">
					<b>Created on</b>
				</td>
				<td align="center">
					<b>Site ID</b>
				</td>
				<td align="center">
					<b>Status</b>
				</td>
			</tr>
				
HTM;
	
	$q="SELECT a.threadid, a.startedon, a.siteid, a.status, a.passcode FROM threads a, sites b WHERE b.wmid = '$uname' AND b.sitedomain = a.siteid AND a.status != 'Closed' ORDER BY a.threadid DESC";
	if($r=mysql_query($q))
	{
		while($tdata = mysql_fetch_array($r))
		{		
			$activethreads += 1;
			$tid = $tdata[0];
			$tcreatedon = date("Y-m-d H:i:s", $tdata[1]);
			$tsid = $tdata[2];
			$tstatus = $tdata[3];
			$tcode = $tdata[4];
			
			$activethreadstable .= <<<HTM
			
				<tr>
					<td align="center">
						<a href="index.php?a=showthread&threadid=$tid&c=$tcode&wmaccess=1" target="_blank">$tid</a>
					</td>
					<td align="center">
						$tcreatedon
					</td>
					<td align="center">
						$tsid
					</td>
					<td align="center">
						$tstatus
					</td>
				</tr>
					
HTM;
		}
	}
	else
	{
		$codetoreturn .= "<b>ERROR!</b> " . mysql_error();
	}
	$activethreadstable .= <<<HTM
		</table>
				
HTM;

	//Build active chats table
	$activechatstable = <<<HTM
		<table align="center" cellspacing="0" cellpadding="5" border="1">
			<tr>
				<td align="center">
					<b>Chat Session ID</b>
				</td>
				<td align="center">
					<b>Created on</b>
				</td>
				<td align="center">
					<b>Site ID</b>
				</td>
				<td align="center">
					<b>Status</b>
				</td>
			</tr>
				
HTM;
	
	$q="SELECT a.threadid, a.startedon, a.siteid, a.status, a.passcode FROM chatthreads a, sites b WHERE b.wmid = '$uname' AND b.sitedomain = a.siteid AND a.status != 'Closed' ORDER BY a.threadid DESC";
	if($r=mysql_query($q))
	{
		while($tdata = mysql_fetch_array($r))
		{		
			$activechats += 1;
			$tid = $tdata[0];
			$tcreatedon = date("Y-m-d H:i:s", $tdata[1]);
			$tsid = $tdata[2];
			$tstatus = $tdata[3];
			$tcode = $tdata[4];
			
			$activechatstable .= <<<HTM
			
				<tr>
					<td align="center">
						<a href="index.php?a=showchat&threadid=$tid&c=$tcode&wmaccess=1" target="_blank">$tid</a>
					</td>
					<td align="center">
						$tcreatedon
					</td>
					<td align="center">
						$tsid
					</td>
					<td align="center">
						$tstatus
					</td>
				</tr>
					
HTM;
		}
	}
	else
	{
		$codetoreturn .= "<b>ERROR!</b> " . mysql_error();
	}
	$activechatstable .= <<<HTM
		</table>
				
HTM;


	//Build active chats table
	
	$codetoreturn .= <<<HTM
		<table width="90%" cellspacing="0" cellpadding="5" border="0" align="center">
			<tr>
				<td valign="top" align="center" width="50%">
					<p align="center"><b>Active Support Requests</b> (<i>$activethreads</i>)</p>
					<p align="center"><font color="red">(Note: Click on the thread ID to access the request. Request will show in the list below unless manually marked as Closed/Complete.)</font></p>
				</td>
				<td valign="top" align="center" width="50%">
					<p align="center"><b>Active Chat Sessions</b> (<i>$activechats</i>)</p>
					<p align="center"><font color="red">(Note: Click on the chat session ID to access the request. Request will show in the list below unless manually marked as Closed/Complete.)</font></p>
				</td>
			</tr>
			<tr>
				<td valign="top">
					$activethreadstable
				</td>
				<td valign="top">
					$activechatstable
				</td>
			</tr>
		</table>
HTM;

	return $codetoreturn;
}

//Search support messages
function wmsearchmsg()
{
	global $pagecontent;
	$uname = $_SESSION['uname'];
	$pagecontent .= getMemMenu();
	
	//Select the sites for this webmaster
	$q="SELECT * FROM sites WHERE wmid = '$uname'";
	if($r=mysql_query($q))
	{
		$siteiddropdown .= <<<HTM
			<select name="sitedomain">
				<option value="">Select site</option>
HTM;
		while($sdata=mysql_fetch_array($r))
		{
			$sid = $sdata['sitedomain'];
			$siteiddropdown .= <<<HTM
				<option value="$sid">$sid</option>
HTM;
		}
		$siteiddropdown .= <<<HTM
			</select>
HTM;
	}
	else
	{
		$pagecontent .= "<p>ERROR! There was some problem reading the webmaster sites details. Cannot continue.";
		return;
	}
	
	$curstamp = date("Y-m-d h:i:s", time());
	
	$pagecontent .= <<<HTM
		<p><b>Search Support Requests</b></p>
		<p>Note: Current server time is - $curstamp</p>
		<form action="index.php?a=wmsearchmsg1" method="post">
			<p>Enter Date Range in YYYY-MM-DD format: From <input type="text" size="10" maxlength="10" name="fdt"> - To: <input type="text" size="10" maxlength="10" name="tdt"></p>
			<p>Select Site: $siteiddropdown </p>
			<p>Show messages of status: <br>
			<INPUT TYPE=CHECKBOX CHECKED NAME=tnew VALUE="new"> New<br>
			<INPUT TYPE=CHECKBOX NAME=twip VALUE="wip"> Work in progress<br>
			<INPUT TYPE=CHECKBOX NAME=tclosed VALUE="closed"> Closed</p>
			<p><input type="submit" value="Search Messages"></p>
		</form>
HTM;
}

//Search message
function wmsearchmsg1()
{
	global $pagecontent;
	$uname = $_SESSION['uname'];
	$pagecontent .= getMemMenu();
	
	//Read the post variables
	$fromdt = $_POST['fdt'];
	$todt = $_POST['tdt'];
	$siteid = $_POST['sitedomain'];
	$ttypenew = $_POST['tnew'];
	$ttypewip = $_POST['twip'];
	$ttypeclosed = $_POST['tclosed'];
	
	$pagecontent .= "<p>Searching tickets of status: $ttypenew - $ttypewip - $ttypeclosed</P>";
	
	//All fields are mandatory
	if($fromdt == "" or $todt == "" or $siteid == "")
	{
		$pagecontent .= "<p>ERROR! Please enter all fields. Try again.";
		return;
	}
	//Change dates to unix timestamp
	$fromdatearray = date_parse($fromdt);
	$fromdtunix = mktime($fromdatearray["hour"], $fromdatearray["minute"], $fromdatearray["second"], $fromdatearray["month"], $fromdatearray["day"], $fromdatearray["year"]);
	
	$todatearray = date_parse($todt);
	$todtunix = mktime($todatearray["hour"], $todatearray["minute"], $todatearray["second"], $todatearray["month"], $todatearray["day"], $todatearray["year"]);

	$pagecontent .= <<<HTM
		<p><b>Search results for:</b></p>
		<p>From date: <i>$fromdt ($fromdtunix) </i>; To date: <i>$todt ($todtunix)</i>; Site: <i>$siteid</i></p>
HTM;

	//Build part of the where clause
	
	if($ttypenew == "new")
	{
		$whereclause .= " status = 'New' ";
	}
	
	if($whereclause != "" and $ttypewip == "wip")
	{
		$whereclause .= " OR ";
	}
	
	if($ttypewip == "wip")
	{
		$whereclause .= " status = 'Work in progress' ";
	}
	
	if($whereclause != "" and $ttypeclosed == "closed")
	{
		$whereclause .= " OR ";
	}
	
	if($ttypeclosed == "closed")
	{
		$whereclause .= " status = 'Closed' ";
	}
	
	
	//Search the messages
	$q="SELECT * FROM threads WHERE ( " . $whereclause . " ) AND startedon >= '$fromdtunix' AND startedon <= '$todtunix' AND siteid = '$siteid'";
	
	//$pagecontent .= "<p> $q </p>";
	if($r=mysql_query($q))
	{
		$pagecontent .= <<<HTM
		<table align="center" border="1" cellspacing="0" cellpadding="2" width="80%">
			<tr>
				<td align="center">
					<b>Ticket #</b>
				</td>
				<td align="center">
					<b>Created on</b>
				</td>
				<td align="center">
					<b>Current status</b>
				</td>
			</tr>
				
HTM;
		while($tdata=mysql_fetch_array($r))
		{
			$tid = $tdata['threadid'];
			$tst = date("Y-m-d h:i:s", $tdata['startedon']);
			$tstatus = $tdata['status'];
			
			$tpcd = $tdata['passcode'];
			$tlinkwm = $siteurl . "index.php?a=showthread&threadid=$tid&c=$tpcd&wmaccess=1";
			$pagecontent .= <<<HTM
			<tr>
				<td align="center">
					<a href="$tlinkwm" target="_blank">$tid</a>
				</td>
				<td align="center">
					$tst
				</td>
				<td align="center">
					$tstatus
				</td>
			</tr>
HTM;
		}
		$pagecontent .= "</table>";
	}
	else
	{
		$pagecontent .= "<p>ERROR! There was some problem reading the message threads. Cannot continue.";
		return;
	}
	
}

//Return stats of the site
function getSiteStats()
{
	$q="SELECT COUNT(*) FROM threads";
	$r=mysql_query($q);
	$tdata=mysql_fetch_array($r);
	$totalthreads = $tdata[0];
	
	$q="SELECT COUNT(*) FROM sites";
	$r=mysql_query($q);
	$tdata=mysql_fetch_array($r);
	$totalsites = $tdata[0];
	
	$q="SELECT COUNT(*) FROM chatthreads";
	$r=mysql_query($q);
	$tdata=mysql_fetch_array($r);
	$totalchatthreads = $tdata[0];
	
	return <<<HTM
		<i><b>$totalthreads</b></i> support requests, <i><b>$totalsites</b></i> sites, <b><i>$totalchatthreads</i></b> live chats and counting ...
HTM;

}

//Show site navigation menu

function get_site_menu()
{
	$menuCode = <<<HTM
		<table width="100%" cellspacing="5" celladding="5" align="center" border="0">
			<tr>
				<td align="center">
					:<a href="index.php">Home</a>:
					:<a href="index.php?a=wmjoin">Join</a>:
					:<a href="index.php?a=wmlogin">Login</a>:
					:<a href="http://www.monitor-line.com/php_mysql_support_center_helpdesk_script.php">Script</a>:
					:<a href="http://monitor-line.com/contactus/index.php?a=createticket&siteid=monitor-line.com" target="_blank">Contact</a>:
HTM;
	if(file_exists("pcc_money_config.php"))
	{
		$menuCode .= <<<HTM
			:<a href="index.php?a=refprog">Opportunity</a>:
HTM;
	}
	$menuCode .= <<<HTM
				</td>
				<td align="right">
					<a href="http://monitor-line.com/contactus/index.php?a=createchatsession&siteid=monitor-line.com" target="_blank"><img src="images/lcb.gif" alt="Live Chat with developer of this script" height="30"></a>
				</td>
			</tr>
		</table>
HTM;
	

		return $menuCode;
}

//Manage sites
function wmmanagesites()
{
	global $pagecontent, $siteurl, $sitename;
	
	$uname = $_SESSION['uname'];
	$pagecontent .= getMemMenu();
	
	$reflink = $siteurl . "index.php?r=" . $uname;
	
	$pagecontent .= <<<HTM
		<p align="center"><font color="blue"><u><b>Referral Link:</u></b></font></p>
		<p>Your referral link is: <br>
		<input type="text" size="90" value="$reflink"><br>
		(Please direct users to above link to refer new members to our site.)</p>
		<hr>
		<p align="center"><font color="blue"><u><b>Helpdesk and Live Help Link(s):</u></b></font></p>
HTM;
	
	
	$q="SELECT * FROM sites WHERE wmid = '$uname'";
	if($r=mysql_query($q))
	{
		$pagecontent .= "<p><u>You have following sites registered:</u></p>";
		while($wdata=mysql_fetch_array($r))
		{
			$sdom = $wdata['sitedomain'];
			$hdeskcode = $siteurl . "index.php?a=createticket&siteid=" . $sdom;
			$chatcode = $siteurl . "index.php?a=createchatsession&siteid=" . $sdom; 

HTM;

			$pagecontent .= <<<HTM
			<p align="center"><u><b>Site:</u> <i>$sdom</i></b></p>
			<p>Link to helpdesk for this site: <br>
			<input type="text" size="90" value="$hdeskcode"> - <a href="$hdeskcode" target="_blank">Test it</a><br>
			(Please direct users of your site to above link so that they can create support request for you.)</p>
			<p>Link to live help (Chat Sessions) for this site: <br>
			<input type="text" size="90" value="$chatcode"> - <a href="$chatcode" target="_blank">Test it</a><br>
			(Please direct users of your site to above link so that they can open a live chat session for live help with you and your support staff.)</p>
			<hr size="1" width="75%">
HTM;
		}
		
	}	
}

//Close the thread
function closeThread()
{
	global $pagecontent, $adsFlag, $ticketrate;
	$tid = $_GET['t'];
	$pcd = $_GET['c'];
	
	//Check if the passcode and the thread id match
	$q="SELECT * FROM threads WHERE threadid = $tid AND passcode = '$pcd'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) <= 0)
		{
			$pagecontent .= "<p>ERROR! Access denied.</p>";
			return;
		}
		else
		{
			//Read the siteid
			$tdata1=mysql_fetch_array($r);
			$sid = $tdata1['siteid'];
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! " . mysql_error();
		return;
	}
	
	//adsFlag to be set
	if(function_exists("checkwmbalance"))
	{
		$wmbal = checkwmbalance("", $sid);
		if($wmbal < $ticketrate)
		{
			$adsFlag = "Y";
		}
	}
	
	//Show the confirmation that the thread needs to be closed
	$pagecontent .= <<<HTM
		<form action="index.php?a=closeThread1" method="post">
			<p>You are closing ticket # <i><u>$tid</u></i></p>
			<p>Are you sure you want to close this ticket? Please enter the security code below and click 'Close' to continue.</p>
			<input type="hidden" name="ti" value="$tid">
			<input type="hidden" name="cd" value="$pcd">
			<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
			Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
			<p><input type="submit" value="Close the ticket"></p>
		</form>
HTM;
}

//Close the ticket
function closeThread1()
{
	global $sitename, $pagecontent, $siteurl, $noreply_email, $adsFlag, $ticketrate;
	//Check security code
	if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
		return;
	}
	$t = $_POST['ti'];
	$c = $_POST['cd'];
	
	$ct = time();
	
	$q="SELECT * FROM threads WHERE threadid = $t AND passcode = '$c'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) <= 0)
		{
			$pagecontent .= "<p>ERROR! Access denied.</p>";
			return;
		}
		else
		{
			//Read the siteid
			$tdata1=mysql_fetch_array($r);
			$sid = $tdata1['siteid'];
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! " . mysql_error();
		return;
	}
	
	//adsFlag to be set
	if(function_exists("checkwmbalance"))
	{
		$wmbal = checkwmbalance("", $sid);
		if($wmbal < $ticketrate)
		{
			$adsFlag = "Y";
		}
	}
	$q="UPDATE threads SET status = 'Closed', closedon = '$ct' WHERE threadid = $t AND passcode = '$c'";
	if($r = mysql_query($q))
	{
		$pagecontent .= "<p>Ticket is closed successfully!</p>";
	}
	else
	{
		$pagecontent .= "<p>ERROR! There was some error in closing the ticket.";
		return;
	}		
}

//Add news and updates for the site
function manageNewsUpdates()
{
	global $pagecontent;
	$uname = $_SESSION['uname'];
	$pagecontent .= getMemMenu();
	
	//Select the sites for this webmaster
	$q="SELECT * FROM sites WHERE wmid = '$uname'";
	if($r=mysql_query($q))
	{
		$siteiddropdown .= <<<HTM
			<select name="sitedomain">
				<option value="">Select site</option>
HTM;
		while($sdata=mysql_fetch_array($r))
		{
			$sid = $sdata['sitedomain'];
			$siteiddropdown .= <<<HTM
				<option value="$sid">$sid</option>
HTM;
		}
		$siteiddropdown .= <<<HTM
			</select>
HTM;
	}
	else
	{
		$pagecontent .= "<p>ERROR! There was some problem reading the webmaster sites details. Cannot continue.";
		return;
	}
	
	$pagecontent .= <<<HTM
		<p><b>Add news and update for one of your sites using the form below:</b></p>
		<p>Note: Current server time is - $curstamp (This time stamp will be shown with the news and update entry.)</p>
		<form action="index.php?a=addNewsUpdates" method="post">
			<p>Select Site for which you want to add news/update: $siteiddropdown </p>
			<p>Text for the news/update:<br>
			<textarea rows="10" cols="60" name="sitenewsupdate"></textarea></p>
			<p><input type="submit" value="Add news/update"></p>
		</form>
HTM;
}

//Add news and updates for the site
function addNewsUpdates()
{
	global $pagecontent;
	$uname = $_SESSION['uname'];
	$pagecontent .= getMemMenu();
	
	$sd = $_POST['sitedomain'];
	$st = $_POST['sitenewsupdate'];
	
	//All fields are mandatory
	if($sd == "" or $st == "")
	{
		$pagecontent .= "<p>ERROR! All fields are necessary. Please try again.";
		return;
	}
	
	$q="INSERT INTO newsupdates SET wmid = '$uname', siteid = '$sd', newsupdate = '$st'";
	if($r=mysql_query($q))
	{
		$pagecontent .= "<p>SUCCESS! Entry added successfully. All entries start reflecting on your news and updates feed instantly. Get code for your news and updates feed from 'Get codes' link from the main menu.";
	}
	else
	{
		$pagecontent .= "<p>ERROR! There was some problem adding the records to the database. Cannot continue.";
		return;
	}	
}

//Function to delete the news updates entries
function deleteNewsUpdates()
{
	global $pagecontent;
	$et = $_GET['t'];
	$wm = $_GET['w'];
	$si = $_GET['s'];
	
	$pagecontent .= <<<HTM
		<form action="index.php?a=deleteNewsUpdates1" method="post">
			<p><b>Deleting entry added by <u>$wm</u> on <u>$et</u> for <u>$si</u></b></p>
			<p><font color="red" size="1">(Caution! Once the entry is deleted, it cannot be recovered.)</font></p>
			<p>Please enter your passcode: <input type="password" value="" size="20" maxlength="10" name="pc"><br>
			<font color="blue" size="1">(Passcode was sent to you with the registration email. If you have lost it, you can <a href="index.php?a=wmrtrpasscode" target="_blank"> retrieve your passcode here</a>.)</font></p>
			<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
			Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
			<input type="hidden" name="et" value="$et">
			<input type="hidden" name="wm" value="$wm">
			<input type="hidden" name="si" value="$si">
			<p><input type="submit" value="Delete this entry"></p>
		</form>
HTM;

}

//Function to delete the news updates entries
function deleteNewsUpdates1()
{
	global $sitename, $pagecontent, $siteurl, $noreply_email;
	//Check security code
	if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
		return;
	}
	
	//Post variables
	$pc = $_POST['pc'];
	$et = $_POST['et'];
	$wm = $_POST['wm'];
	$si = $_POST['si'];
	
	//Check webmaster access code
	$q="SELECT * FROM webmasters WHERE wmid = '$wm' AND wmaccesscode = '$pc'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) == 1)
		{
			//OK
		}
		else
		{
			//Not OK
			$pagecontent .= "<p>ERROR! Access denied.";
			return;
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! Could not verify the access. Cannot continue.";
		return;
	}
	
	//Now delete the entry
	$q="DELETE FROM newsupdates WHERE entrytime = '$et' AND wmid = '$wm' AND siteid = '$si' LIMIT 1";
	if($r=mysql_query($q))
	{
		$pagecontent .= "<p>SUCCESS! Entry deleted successfully.</p>";
	}
	else
	{
		$pagecontent .= "<p>ERROR! Error while deleting the entry. Cannot continue.</p>";
		return;
	}
}

function get_message_text_box($msgtxt, $addedbycolor)
{
	return <<<HTM
		<table style="border: 1px solid $addedbycolor; text-align: left; width: 70%;" border="1" cellpadding="5" cellspacing="0">
		  <tbody>
			<tr>
			  <td style="text-align: left;">$msgtxt</td>
			</tr>
		  </tbody>
		</table>
HTM;
}

//Create new chat session
function createchatsession($sid)
{
	global $pagecontent, $sitename ;
	//Check site id
	if(checksite($sid) == false)
	{
		$pagecontent .= "<p>ERROR! This site is not registered.</p>";
		return;
	}
	//Get logo of the site
	$logourl = getlogourl($sid);
	if($logourl != "")
	{
		$logohtml = <<<HTM
			<center><img src="$logourl" alt="$sid"></center>
			
HTM;
	}
	
	//Check if the site is setup for 24X7 chat session creation
	$q="SELECT * FROM sites WHERE sitedomain = '$sid' AND chat24X7 = 'Y'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r)>0)
		{
			//OK to create chat session
		}
		else
		{
			//Check if the support staff is online - if not show the contact us form
			$timetocheck = time() - 20;
			$wmid = getwebmaster($sid);
			$q="SELECT * FROM webmasterlog WHERE wmid = '$wmid' AND loggedinasof > $timetocheck";
			if($r=mysql_query($q))
			{
				if(mysql_num_rows($r)>0)
				{
					//Webmaster is online to provide support
			
				}
				else
				{
					//Webmaster is not online - show contact form
					$pagecontent .= <<<HTM
					$logohtml
					<p><b>Sorry!</b> Support staff is not currently available.</p>
					<p>Please create a support request <a href="index.php?a=createticket&siteid=$sid">here</a> and support staff will respond at the earliest possible.</p>
				
HTM;
					return;
				}
			}
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! There was a database error. Try again later.</p>";
		return;
	}
	$pagecontent .= <<<HTM
		$logohtml
		<p><font size="4"><b>Welcome to Helpdesk of <u>$sid</u></b></font></p>
		<p><font size="2">Powered by <a href="index.php" target="_blank">$sitename</a>.</font></p>
		<p><b>Start a new chat session to chat with support staff at <u>$sid</u>.</b></p>
		<form action="index.php?a=createchatsession1" method="post">
			<p>Enter your name: <input type="text" name="uname" size="20" maxlength="20"><br>
			(Note: This is the name that will show in the chat session.)</p>
			<p>Enter subject: <input type="text" name="usub" size="60" maxlength="200"><br>
			(Note: Briefly describe your support request.)</p>
			<input type="hidden" name="sid" value="$sid">
			<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
			Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
			<p><input type="submit" value="Start chat session"></p>
			
		</form>
HTM;
}

//Save the ticket
function createchatsession1($uname, $usubject, $sid)
{
	global $pagecontent, $noreply_email, $sitename, $siteurl, $ticketrate, $adsFlag;
	//Security code must match
	//Check security code
	if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
		return;
	}
	//All fields are mandatory
	if($uname == "" or $usubject == "" or $sid == "")
	{
		$pagecontent .= "<p>ERROR! All fields are mandatory.</p>";
		return;
	}
	
	//Clean the contents
	$uname = strip_tags($uname);
	$usubject = strip_tags($usubject);
	//Entry date and time
	$msgenteredon = time();
	//Create random code
	$rndcd = rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	$rndcd .= rand(0,9);
	
	//Insert and create chat thread id
	//First get webmaster ID
	$wmi = getwebmaster($sid);
	if($wmi=="")
	{
		$pagecontent .= "<p>ERROR! Webmaster details of this site could not be found. Try again.</p>";
		return;
	}
	$q="INSERT INTO chatthreads SET startedon = '$msgenteredon', siteid = '$sid', wmid = '$wmi', name = '$uname', passcode = '$rndcd'";
	if($r=mysql_query($q))
	{
		//Now enter the message
		$lastthreadid = mysql_insert_id();
		if($lastthreadid > 0)
		{
			//Set the username in the session variable for check later
			$_SESSION['username'] = $uname;
			
			//Now send mail to the support staff
			//Read the webmaster's email address and id
			$q2="SELECT a.wmeml, a.wmid FROM webmasters a, sites b WHERE b.sitedomain = '$sid' AND a.wmid = b.wmid";
			if($r2=mysql_query($q2))
			{
				$wmdata = mysql_fetch_array($r2);
				$wmeml = $wmdata[0];
				$wmid = $wmdata[1];
					
				//Update the balance of the webmaster if positive balance exists
				if(function_exists("update_balance"))
				{
					if($adsFlag == "Y")
					{
					}
					else
					{
						update_balance($wmid, $ticketrate);
						update_ref_credits($wmid);
					}
				}
				
				if($wmeml != "")
				{
					//Build subject line
					$sub = $sid . " New chat request created No. " . $lastthreadid;
					//Build the reply link
					//For webmaster
					$replylink = $siteurl . "index.php?a=showchat&threadid=$lastthreadid&c=$rndcd&wmaccess=1";
					$replylinkuser = $siteurl . "index.php?a=showchat&threadid=$lastthreadid&c=$rndcd";
					$msg .= <<<TXT

A new chat session is created at $sitename for your site $sid

In order to join, please click on the link below:

$replylink

$sitename


TXT;
					if(send_mail_plain($wmeml,$noreply_email,$sub,$msg))
					{
						$pagecontent .= <<<HTM
	<p>SUCCESS! Your chat session created successfully. <a href="$replylinkuser">Click here to join the chat ...</a></p>
HTM;
						
					}
				}
			}
			else
			{
				$pagecontent .= "ERROR! " . mysql_error();
			}
		}
		else
		{
			$pagecontent .= "ERROR! " . mysql_error();
		}
	}

}

//Show the chat room
function showchat()
{
	global $pagecontent, $adsFlag, $ticketrate;
	$tid = $_GET['threadid'];
	$wac = $_GET['wmaccess'];
	$pcd = $_GET['c'];
		
	//Thread ID is mandatory
	if($tid == "" or $pcd == "")
	{
		$pagecontent .= "<p>ERROR! Chat session ID and/or passcode is missing. Email sent to you has these details. Please try again.</p>";
		return;
	}
	//Check if the email and the thread id match
	$q="SELECT * FROM chatthreads WHERE threadid = $tid AND passcode = '$pcd'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) <= 0)
		{
			$pagecontent .= "<p>ERROR! Access denied.</p>";
			return;
		}
		else
		{
			//Read the site id
			$tiddata=mysql_fetch_array($r);
			$siteid = $tiddata['siteid'];
			$tstatus = $tiddata['status'];
			$uname = $tiddata['name'];
			
			
			//Update the status and response time
			if($wac == 1)
			{
				$rtime = time();
				$qu = "UPDATE chatthreads SET status = 'Work in progress', respon = '$rtime' WHERE threadid = $tid AND status != 'Closed'";
				mysql_query($qu);
			}
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! " . mysql_error();
		return;
	}
	
	//adsFlag to be set
	if(function_exists("checkwmbalance"))
	{
		$wmbal = checkwmbalance("", $siteid);
		if($wmbal < $ticketrate)
		{
			$adsFlag = "Y";
		}
	}
	
	$pagecontent .= <<<HTM
		<p><b>Support Center for <font color="#006600">$siteid</font></b></p>	
		<hr size="1">
HTM;

	$fileforchat = $tid . "_" . $pcd;
//	$pagecontent .= "<p>Chat file : $fileforchat</p>";
	
	//Set the session variables
	$_SESSION['cfn'] = $fileforchat;
	if($wac == 1)
	{
		$uname = "Support";
	}
	$_SESSION['username'] = $uname;
	
	$pagecontent .= <<<HTM
		<table cellspacing="0" cellpadding="20" align="center">
			<tr>
				<td valign="top">
					<iframe src="chatpage.php" width="650" height="500" frameborder="0"></iframe>
				</td>
				<td valign="top" align="center">
					<p><a href="index.php?a=closechatThread&t=$tid&c=$pcd">Click here mark this chat session as closed.</a></p>
				</td>
			</tr>
		</table>
HTM;

}

//Get webmaster
function getwebmaster($c)
{
	$wm = "";
	$q="SELECT wmid FROM sites WHERE sitedomain = '$c'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) > 0)
		{
			$wdata=mysql_fetch_array($r);
			$wm = $wdata[0];
			return $wm;
		}
		else
		{
			return $wm;
		}
	}	
	return $wm;
}

//Get logo url
function getlogourl($c)
{
	$lu = "";
	$q="SELECT sitelogo FROM sites WHERE sitedomain = '$c'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) > 0)
		{
			$wdata=mysql_fetch_array($r);
			$lu = $wdata[0];
			return $lu;
		}
		else
		{
			return $lu;
		}
	}	
	return $lu;
}

//Close the thread
function closechatThread()
{
	global $pagecontent, $adsFlag, $ticketrate;
	$tid = $_GET['t'];
	$pcd = $_GET['c'];
	
	//Check if the passcode and the thread id match
	$q="SELECT * FROM chatthreads WHERE threadid = $tid AND passcode = '$pcd'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) <= 0)
		{
			$pagecontent .= "<p>ERROR! Access denied.</p>";
			return;
		}
		else
		{
			//Read the siteid
			$tdata1=mysql_fetch_array($r);
			$sid = $tdata1['siteid'];
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! " . mysql_error();
		return;
	}
	
	//adsFlag to be set
	if(function_exists("checkwmbalance"))
	{
		$wmbal = checkwmbalance("", $sid);
		if($wmbal < $ticketrate)
		{
			$adsFlag = "Y";
		}
	}
	
	//Show the confirmation that the thread needs to be closed
	$pagecontent .= <<<HTM
		<form action="index.php?a=closechatThread1" method="post">
			<p>You are closing chat session # <i><u>$tid</u></i></p>
			<p>Are you sure you want to close this chat session? Please enter the security code below and click 'Close' to continue.</p>
			<input type="hidden" name="ti" value="$tid">
			<input type="hidden" name="cd" value="$pcd">
			<p>Security Code -> <img src="CaptchaSecurityImages.php" /><br>
			Enter Security Code: <input id="security_code" name="security_code" type="text" /></p>
			<p><input type="submit" value="Close the chat session"></p>
		</form>
HTM;
}

//Close the ticket
function closechatThread1()
{
	global $sitename, $pagecontent, $siteurl, $noreply_email, $adsFlag, $ticketrate;
	//Check security code
	if(($_SESSION['security_code'] == $_POST['security_code']) && (!empty($_SESSION['security_code'])) ) 
	{
		unset($_SESSION['security_code']);
	}
	else 
	{
		$pagecontent .= "<p>ERROR! Security code is invalid. Try again.";
		return;
	}
	$t = $_POST['ti'];
	$c = $_POST['cd'];
	
	$ct = time();
	
	$q="SELECT * FROM chatthreads WHERE threadid = $t AND passcode = '$c'";
	if($r=mysql_query($q))
	{
		if(mysql_num_rows($r) <= 0)
		{
			$pagecontent .= "<p>ERROR! Access denied.</p>";
			return;
		}
		else
		{
			//Read the siteid
			$tdata1=mysql_fetch_array($r);
			$sid = $tdata1['siteid'];
		}
	}
	else
	{
		$pagecontent .= "<p>ERROR! " . mysql_error();
		return;
	}
	
	//adsFlag to be set
	if(function_exists("checkwmbalance"))
	{
		$wmbal = checkwmbalance("", $sid);
		if($wmbal < $ticketrate)
		{
			$adsFlag = "Y";
		}
	}
	$q="UPDATE chatthreads SET status = 'Closed', closedon = '$ct' WHERE threadid = $t AND passcode = '$c'";
	if($r = mysql_query($q))
	{
		$pagecontent .= "<p>Chat session is closed successfully!</p>";
	}
	else
	{
		$pagecontent .= "<p>ERROR! There was some error in closing the chat session.";
		return;
	}		
}

?>