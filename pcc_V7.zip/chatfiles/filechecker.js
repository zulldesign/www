// PHP Script Chat - http://coursesweb.net/


// Calls Ajax function to each 2 seconds (with chatuser) to 
function loopingFunction() {
	var expDate = new Date();
		
	document.write(expDate.getTime());
	setTimeout('loopingFunction()', 10000);
}
loopingFunction();    // Calls Ajax function