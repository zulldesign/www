// Start AJAX 

var mypostrequest = new ajaxRequest();    // Create the object for AJAX

function ajaxRequest(){
 var activexmodes=["Msxml2.XMLHTTP", "Microsoft.XMLHTTP"] //activeX versions to check for in IE
 if (window.ActiveXObject){      //Test for support for ActiveXObject in IE first (as XMLHttpRequest in IE7 is broken)
  for (var i=0; i<activexmodes.length; i++){
   try {
    return new ActiveXObject(activexmodes[i])
   }
   catch(e){
    //suppress error
   }
  }
 }
 else if (window.XMLHttpRequest) return new XMLHttpRequest()
 else return false
}

function ajaxF(file, parameters) 
{
  
  mypostrequest.open("POST", file, true);
  mypostrequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  mypostrequest.send(parameters);
  mypostrequest.onreadystatechange = stateChanged;
    function stateChanged() 
	{
		if (mypostrequest.readyState==4) 
		{
			if (mypostrequest.status==200 && document.getElementById('wmid')) 
			{
				if(mypostrequest.responseText == 'yes')
				{
					alert("New chat request created by someone from your site!\n\rPLEASE CHECK THE ACTIVE CHATS IN THE SELLER DASHBOARD or \n\rCheck your email immediately.");
					window.location.replace('index.php?a=mem');

				}
			}
		}
	}
//	alert(response_text);
}

// Calls Ajax function to each 2 seconds (with chatuser) to 
function checkUpdate() 
{
	//Read the webmaster id
	var wmid = '';
	var file = 'sendupdates.php';
	if(document.getElementById('wmid')) 
	{
		wmid = document.getElementById('wmid').innerHTML; 
		//alert("luck"+wmid); 
	}
	
	else{ exit(); }
	var parameters = 'wmid='+wmid;
	ajaxF(file, parameters);
	
	
	//alert("hi "+wmid);
	setTimeout('checkUpdate()', 20000);
}

checkUpdate();    // Calls Ajax function
