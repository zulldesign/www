-- --------------------------------------------------------

--
-- Table structure for table `chatthreads`
--

DROP TABLE IF EXISTS `chatthreads`;
CREATE TABLE IF NOT EXISTS `chatthreads` (
  `threadid` bigint(20) NOT NULL auto_increment,
  `startedon` varchar(15) NOT NULL,
  `siteid` varchar(50) NOT NULL,
  `wmid` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL default 'New' COMMENT 'Status of the request',
  `respon` varchar(15) NOT NULL COMMENT 'Response timestamp',
  `closedon` varchar(15) NOT NULL COMMENT 'Closure timestamp',
  `passcode` varchar(10) NOT NULL default '0123456789' COMMENT 'Unique passcode for the thread',
  UNIQUE KEY `threadid` (`threadid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Threads' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `msgid` bigint(20) NOT NULL auto_increment,
  `threadid` bigint(20) NOT NULL,
  `wmaccess` varchar(1) NOT NULL,
  `addedon` varchar(15) NOT NULL,
  `subj` varchar(200) NOT NULL,
  `msgtext` blob NOT NULL,
  PRIMARY KEY  (`msgid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Messages submitted by users and admin' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `newsupdates`
--

DROP TABLE IF EXISTS `newsupdates`;
CREATE TABLE IF NOT EXISTS `newsupdates` (
  `entrytime` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT 'Entry timestamp',
  `wmid` varchar(20) collate utf8_unicode_ci NOT NULL COMMENT 'Webmaster id',
  `siteid` varchar(100) collate utf8_unicode_ci NOT NULL COMMENT 'Domain name',
  `newsupdate` blob NOT NULL COMMENT 'News and update text',
  PRIMARY KEY  (`entrytime`,`wmid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='News and updates';

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
CREATE TABLE IF NOT EXISTS `sites` (
  `sitedomain` varchar(50) NOT NULL,
  `wmid` varchar(20) NOT NULL,
  `sitelogo` varchar(200) NOT NULL COMMENT 'Logo URL for the site',
  `chat24X7` varchar(1) NOT NULL default 'N' COMMENT 'Flag to check chat session can be created anytime',
  UNIQUE KEY `sitedomain` (`sitedomain`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Sites';

-- --------------------------------------------------------

--
-- Table structure for table `threads`
--

DROP TABLE IF EXISTS `threads`;
CREATE TABLE IF NOT EXISTS `threads` (
  `threadid` bigint(20) NOT NULL auto_increment,
  `startedon` varchar(15) NOT NULL,
  `siteid` varchar(50) NOT NULL,
  `emailid` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL default 'New' COMMENT 'Status of the request',
  `respon` varchar(15) NOT NULL COMMENT 'Response timestamp',
  `closedon` varchar(15) NOT NULL COMMENT 'Closure timestamp',
  `passcode` varchar(10) NOT NULL default '0123456789' COMMENT 'Unique passcode for the thread',
  UNIQUE KEY `threadid` (`threadid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Threads' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `webmasterlog`
--

DROP TABLE IF EXISTS `webmasterlog`;
CREATE TABLE IF NOT EXISTS `webmasterlog` (
  `wmid` varchar(20) collate utf8_unicode_ci NOT NULL COMMENT 'Webmaster ID',
  `loggedinasof` bigint(20) NOT NULL COMMENT 'Date and time of the last login update',
  PRIMARY KEY  (`wmid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Webmaster log';

-- --------------------------------------------------------

--
-- Table structure for table `webmasters`
--

DROP TABLE IF EXISTS `webmasters`;
CREATE TABLE IF NOT EXISTS `webmasters` (
  `wmid` varchar(20) NOT NULL,
  `wmeml` varchar(200) NOT NULL,
  `wmjoinedon` varchar(15) NOT NULL,
  `wmaccesscode` varchar(10) NOT NULL,
  `paid_balance` int(11) NOT NULL default '0' COMMENT 'Balance for paid members',
  `ref` varchar(20) NOT NULL COMMENT 'Referrer',
  `ref_balance` bigint(20) NOT NULL COMMENT 'Referral earnings',
  PRIMARY KEY  (`wmid`),
  UNIQUE KEY `wmid` (`wmid`),
  UNIQUE KEY `wmeml` (`wmeml`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Webmasters';

