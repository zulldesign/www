<?
include("pcc_config.php");
include("pcc_funs.php");
if(file_exists("pcc_money_config.php"))
{
	include("pcc_money_config.php");
}

if(file_exists("pcc_money_funs.php"))
{
	include("pcc_money_funs.php");
}

global $sitename, $sitepunchline, $hitscode, $footercode, $rightpanel, $pagecontent, $link, $ticketrate, $adsFlag, $menuFlag, $default_user;

$link = dbconnect();
session_start();
$act=$HTTP_GET_VARS['a'];
if($act == "checkcookie")
{
	echo "Cookie set - ". $_COOKIE["refeml"];
	exit;
	
}
if($act == "cookieunset")
{
	$re = "noref";
	
	setcookie("refeml", $re, time() - 3600);
	
	echo "Cookie unset ..";
	exit;
}	
//Referral cookie
$cbp=$HTTP_GET_VARS['r'];
if($cbp=="")
{
	$cbp=$default_user;
}
if($cbp!="")
{
	$re = $cbp;
	if(isset($_COOKIE["refeml"]))
	{
		//Do nothing
	}
	else
	{
		setcookie("refeml", $re, time() + 60 * 60 * 24 * 365);
	}
}


switch($act)
{
	case "";
		$adsFlag = "Y";
		$menuFlag = "Y";
		showMain();
		break;
	case "wmjoin";
		$adsFlag = "Y";
		$menuFlag = "Y";
		wmjoin();
		break;
	case "wmjoin1";
		$adsFlag = "Y";
		$menuFlag = "Y";
		$un=$HTTP_POST_VARS['wmid'];
		$ueml = $HTTP_POST_VARS['wmeml'];
		wmjoin1($un, $ueml);
		break;
	case "wmaddsite";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		if(check_login())
		{
			wmaddsite();
		}
		else
		{
			login();
		}
		break;
	case "wmaddsite1";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		if(check_login())
		{
			wmaddsite1();
		}
		else
		{
			login();
		}
		break;
	case "showcc";
		$menuFlag = "N";
		$siteidcc = $HTTP_POST_VARS['siteid'];
		
		if($siteidcc == "")
		{
			$siteidcc = $HTTP_GET_VARS['siteid'];
		}
		
		//adsFlag to be set
		if(function_exists("checkwmbalance"))
		{
			$wmbal = checkwmbalance("", $siteidcc);
			if($wmbal < $ticketrate)
			{
				$adsFlag = "Y";
			}
		}
		showcc($siteidcc);
		break;
	case "createticket";
		$menuFlag = "N";
		$sid = $HTTP_GET_VARS['siteid'];
		//adsFlag to be set
		if(function_exists("checkwmbalance"))
		{
			$wmbal = checkwmbalance("", $sid);
			if($wmbal < $ticketrate)
			{
				$adsFlag = "Y";
			}
		}
		createticket($sid);
		break;
	case "createticket1";
		$menuFlag = "N";
		$uemail = $HTTP_POST_VARS['ueml'];
		$usubject = $HTTP_POST_VARS['usub'];
		$utext = $HTTP_POST_VARS['utxt'];
		$sid = $HTTP_POST_VARS['sid'];
		//adsFlag to be set
		if(function_exists("checkwmbalance"))
		{
			$wmbal = checkwmbalance("", $sid);
			if($wmbal < $ticketrate)
			{
				$adsFlag = "Y";
			}
		}
		createticket1($uemail, $usubject, $utext, $sid);
		break;
	case "showthread";
		$menuFlag = "N";
		showthread();
		break;
	case "updateticket";
		$menuFlag = "N";
		updatethread();
		break;
	case "updateticket1";
		$menuFlag = "N";
		updatethread1();
		break;
	case "wmrtrpasscode";
		$adsFlag = "Y";
		$menuFlag = "Y";
		wmrtrpasscode();
		break;
	case "wmrtrpasscode1";
		$adsFlag = "Y";
		$menuFlag = "Y";
		$eml = $HTTP_POST_VARS['wmeml'];
		wmrtrpasscode1($eml);
		break;
	case "wmlogin";
		$adsFlag = "Y";
		$menuFlag = "Y";
		login();
		break;
	case "login1";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		$cbuname = $HTTP_POST_VARS['uname'];
		$cbupass = $HTTP_POST_VARS['upass'];
		login1($cbuname, $cbupass);
		break;
	case "mem";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		if(check_login())
		{
			mem();
		}
		else
		{
			login();
		}
		break;
	case "logoff";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		session_destroy();
		header("Location: index.php");
		break;
	case "wmsearchmsg";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		if(check_login())
		{
			wmsearchmsg();
		}
		else
		{
			login();
		}
		break;
	case "wmsearchmsg1";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		if(check_login())
		{
			wmsearchmsg1();
		}
		else
		{
			login();
		}
		break;
	case "wmmanagesites";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		if(check_login())
		{
			wmmanagesites();
		}
		else
		{
			login();
		}
		break;
	case "closeThread";
		closeThread();
		break;
	case "closeThread1";
		closeThread1();
		break;
	case "closechatThread";
		closechatThread();
		break;
	case "closechatThread1";
		closechatThread1();
		break;
	case "manageNewsUpdates";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		if(check_login())
		{
			manageNewsUpdates();
		}
		else
		{
			login();
		}
		break;
	case "addNewsUpdates";
		$adsFlag = "Y";
		$menuFlag = "Y";
		session_start();
		if(check_login())
		{
			addNewsUpdates();
		}
		else
		{
			login();
		}
		break;
	case "deleteNewsUpdates";
		$adsFlag = "Y";
		$menuFlag = "Y";
		deleteNewsUpdates();
		break;
	case "deleteNewsUpdates1";
		$adsFlag = "Y";
		$menuFlag = "Y";
		deleteNewsUpdates1();
		break;
	case "refprog";
		$adsFlag = "Y";
		$menuFlag = "Y";
		if(function_exists("refprog"))
		{
			refprog();
		}
		break;
	case "createchatsession";
		$menuFlag = "N";
		$sid = $HTTP_GET_VARS['siteid'];
		//adsFlag to be set
		if(function_exists("checkwmbalance"))
		{
			$wmbal = checkwmbalance("", $sid);
			if($wmbal < $ticketrate)
			{
				$adsFlag = "Y";
			}
		}
		createchatsession($sid);
		break;
	case "createchatsession1";
		$menuFlag = "N";
		$unm = $HTTP_POST_VARS['uname'];
		$usubject = $HTTP_POST_VARS['usub'];
		$sid = $HTTP_POST_VARS['sid'];
		//adsFlag to be set
		if(function_exists("checkwmbalance"))
		{
			$wmbal = checkwmbalance("", $sid);
			if($wmbal < $ticketrate)
			{
				$adsFlag = "Y";
			}
		}
		createchatsession1($unm, $usubject, $sid);
		break;
	case "showchat";
		$menuFlag = "N";
		showchat();
		break;

}


//Read the template
$templateCode = file_get_contents('TEMPLATE.html');

//Replace placeholders
$templateCode = str_replace("[SITENAME]", $sitename, $templateCode);
$templateCode = str_replace("[PUNCHLINE]", $sitepunchline, $templateCode);
$templateCode = str_replace("[SITESTATS]", getSiteStats(), $templateCode);
$templateCode = str_replace("[PAGECONTENT]", $pagecontent, $templateCode);
$templateCode = str_replace("[FOOTER]", $footercode, $templateCode);
$templateCode = str_replace("[METATITLE]", $sitename, $templateCode);
$templateCode = str_replace("[HITS]", $hitscode, $templateCode);
//Take care of the ads
if($adsFlag == "Y")
{
	$templateCode = str_replace("[BOTTOMCENTERPANEL]", $bottomcenterpanel, $templateCode);
}
else
{
	$templateCode = str_replace("[BOTTOMCENTERPANEL]", "", $templateCode);
}

//Take care of the site menu
if($menuFlag == "Y")
{
	$templateCode = str_replace("[SITEMENU]", get_site_menu(), $templateCode);
}
else
{
	$templateCode = str_replace("[SITEMENU]", "", $templateCode);
}

echo $templateCode;

dbclose($link);

?>