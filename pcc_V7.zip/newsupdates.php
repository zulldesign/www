<?
include("pcc_config.php");
include("pcc_funs.php");
global $sitename, $sitepunchline, $hitscode, $footercode, $rightpanel, $pagecontent, $link;
$link = dbconnect();
$sdom = $_GET['siteid'];
$sitems = $_GET['items'];

if($sitems == "" or $sitems < 0 or $sitems > 10 or !is_numeric($sitems))
{
	$sitems = 5;
}

echo <<<HTM
<html>
<head></head>
<body leftmargin="2" topmargin="0">
<font size="1" face="arial">
News and updates powered by <a href="$siteurl" target="_blank">$sitename</a>
<hr size="1" widht="80%">
HTM;

$q="SELECT * FROM newsupdates WHERE siteid = '$sdom' ORDER BY entrytime DESC LIMIT $sitems";
if($r=mysql_query($q))
{
	while($udata = mysql_fetch_array($r))
	{
		$setime = $udata['entrytime'];
		$wmid = $udata['wmid'];
		$stext = $udata['newsupdate'];
		$sid = $udata['siteid'];
		
		echo <<<HTM
			<u>$setime:</u> $stext <A href="$siteurl/index.php?a=deleteNewsUpdates&t=$setime&w=$wmid&s=$sid" target="_blank"><img border="1" src="images/cross-mark.jpg" alt="Delete this entry" align="middle" width="10"></a><hr size="1" widht="80%">
HTM;
	}
}
echo "</font></body></html>";

dbclose($link);

?>