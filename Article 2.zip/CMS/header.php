<div id="templatemo_header_wrapper">
	<div id="templatemo_header">
    
    	<div id="site_title">
            <h1><a href="http://www.templatemo.com" target="_parent"><strong>CMS IBCS44</strong><span>Free Blog Template in HTML CSS</span></a></h1>
        </div>
    
    </div>
</div>