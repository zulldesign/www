<div class="cleaner"></div>            
        </div>        
    </div>    
    <div id="templatemo_main_bottom"></div>    
</div>




<div id="templatemo_footer">

    Copyright © 2048 <a href="index.html">Your Company Name</a> | 
    <a href="" target="_parent">Website Templates</a> by <a href="" target="_parent">Free CSS Templates</a>
    
</div>



<div align=center>This template  downloaded form <a href=''>free website templates</a></div></body>
</html>