<?php
header( "refresh:2;url=users.php" );
include_once ("z_db.php");
// Inialize session
session_start();
// Semak, jika sesi nama pengguna TIDAK ditetapkan, halaman ini akan melompat ke laman log masuk
if (!isset($_SESSION['adminidusername'])) {
        print "
				<script language='javascript'>
					window.location = 'index.php';
				</script>
			";
			
}
$todelete= mysqli_real_escape_string($con,$_GET["username"]);

$result=mysqli_query($con,"DELETE FROM affiliateuser WHERE username='$todelete'");
if ($result)
{
print "<center>Pengguna dipadam <br/> Redirecting dalam 2 saat ...</center>";
}
else
{
print "<center>Tindakan tidak dapat dilakukan, periksa kembali <br/> Mengalihkan arah dalam masa 2 saat...</center>";
}

?>