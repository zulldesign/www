<?php
header( "refresh:1;url=notifications.php" );
session_start(); //sesi permulaan
include('z_db.php'); //butiran sambungan
$status = "OK"; //status permulaan
$msg="";
$nhead=mysqli_real_escape_string($con,$_POST['notihead']); //mengambil butiran melalui kaedah pos
$nbody = mysqli_real_escape_string($con,$_POST['notibody']);

if ( strlen($nhead) < 2 ){
$msg=$msg."Subjek Harus Memiliki 2 Karakter Minimum.<BR>";
$status= "NOTOK";}

if ( strlen($nbody) < 4 ){ //memeriksa jika badan lebih besar maka 4 atau tidak
$msg=$msg."Body must contain more than 4 char length.<BR>";
$status= "NOTOK";}

if($status=="OK")
{
$res1=mysqli_query($con,"INSERT INTO notifications (subject, body, posteddate, valid) VALUES ('$nhead', '$nbody', NOW(), 1)");

if($res1)
{
print "Pemberitahuan Dihantar ... !!!";
}
else
{
print "kesilapan !!!! cuba lagi nanti atau meminta bantuan daripada pentadbir anda.";
}


} 
else {
        
echo "<font face='Verdana' size='2' color=red>$msg</font><br><input type='button' value='Retry' onClick='history.go(-1)'>"; //kesilapan percetakan
	 
}

?>
