<?php
header( "refresh:3;url=pacsettings.php" );
session_start(); //sesi permulaan
include('z_db.php'); //butiran sambungan
$status = "OK"; //status permulaan
$msg="";
$pname=mysqli_real_escape_string($con,$_POST['pckname']); //mengambil butiran melalui kaedah pos
$pdetail = mysqli_real_escape_string($con,$_POST['pckdetail']);
$pprice = mysqli_real_escape_string($con,$_POST['pckprice']);
$pcurid = mysqli_real_escape_string($con,$_POST['currency']);
$pckmpay = mysqli_real_escape_string($con,$_POST['pckmpay']);
$pcksbonus = mysqli_real_escape_string($con,$_POST['pcksbonus']);
$pcktax = mysqli_real_escape_string($con,$_POST['pcktax']);
$pact = mysqli_real_escape_string($con,$_POST['pckact']);
$pidmain = mysqli_real_escape_string($con,$_POST['pckmainid']);
$p1 = mysqli_real_escape_string($con,$_POST['lev1']);
$p2 = mysqli_real_escape_string($con,$_POST['lev2']);
$p3 = mysqli_real_escape_string($con,$_POST['lev3']);
$p4 = mysqli_real_escape_string($con,$_POST['lev4']);
$p5 = mysqli_real_escape_string($con,$_POST['lev5']);
$p6 = mysqli_real_escape_string($con,$_POST['lev6']);
$p7 = mysqli_real_escape_string($con,$_POST['lev7']);
$p8 = mysqli_real_escape_string($con,$_POST['lev8']);
$p9 = mysqli_real_escape_string($con,$_POST['lev9']);
$p10 = mysqli_real_escape_string($con,$_POST['lev10']);
$p11 = mysqli_real_escape_string($con,$_POST['lev11']);
$p12 = mysqli_real_escape_string($con,$_POST['lev12']);
$p13 = mysqli_real_escape_string($con,$_POST['lev13']);
$p14 = mysqli_real_escape_string($con,$_POST['lev14']);
$p15 = mysqli_real_escape_string($con,$_POST['lev15']);
$p16 = mysqli_real_escape_string($con,$_POST['lev16']);
$p17 = mysqli_real_escape_string($con,$_POST['lev17']);
$p18 = mysqli_real_escape_string($con,$_POST['lev18']);
$p19 = mysqli_real_escape_string($con,$_POST['lev19']);
$p20 = mysqli_real_escape_string($con,$_POST['lev20']);
$gateway = 0;
$renewdays = mysqli_real_escape_string($con,$_POST['renewdays']);

if ( strlen($pname) < 2 ){
$msg=$msg."Nama Pakej Harus Memiliki 2 Karakter Minimum.<BR>";
$status= "NOTOK";}

if ( strlen($pdetail) < 4 ){ //memeriksa jika badan lebih besar maka 4 atau tidak
$msg=$msg."Butiran pakej mesti mengandungi lebih daripada 4 panjang char.<BR>";
$status= "NOTOK";}

if($status=="OK")
{
$res1=mysqli_query($con,"update packages set name='$pname',price='$pprice',currency='$pcurid',details='$pdetail',tax='$pcktax',mpay='$pckmpay',sbonus='$pcksbonus',active='$pact',level1='$p1',level2='$p2',level3='$p3',level4='$p4',level5='$p5',level6='$p6',level7='$p7',level8='$p8',level9='$p9',level10='$p10',level11='$p11',level12='$p12',level13='$p13',level14='$p14',level15='$p15',level16='$p16',level17='$p17',level18='$p18',level19='$p19',level20='$p20',gateway='$gateway',validity='$renewdays' where id=$pidmain");

if($res1)
{
print "Pakej dikemas kini ... !!! Mengarahkan ...";
}
else
{
print "kesilapan !!!! cuba lagi nanti atau minta bantuan daripada pentadbir anda !!!! Mengarahkan ...";
}


} 
else {
        
echo "<font face='Verdana' size='2' color=red>$msg</font><br><input type='button' value='Retry' onClick='history.go(-1)'>"; //kesilapan percetakan
	 
}

?>
