<?php
session_start(); //sesi permulaan
include('z_db.php'); //butiran sambungan

$ndel=mysqli_real_escape_string($con,$_POST['notisub']); //mengambil butiran melalui kaedah pos


$res1=mysqli_query($con,"update notifications set valid=0 where id=$ndel");

if($res1)
{
print "Pemberitahuan dinyahaktifkan ... !!";
}
else
{
print "kesilapan !!!! cuba lagi nanti atau meminta bantuan daripada pentadbir anda.";
}

header( "refresh:1;url=notifications.php" );
?>
