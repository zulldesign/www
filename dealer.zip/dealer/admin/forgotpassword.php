<!DOCTYPE html>
<html lang="en" class="app">
<head>
<meta charset="utf-8" />
<title>HALOTELCO</title>
<meta name="description" content="Pembekal Perkhidmatan Telekomunikasi & Membina Perisian + Webreplika + Blog + Shopping cart + Minisite + Dan sebagainya" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="css/app.v1.css" type="text/css" />
<link rel="shortcut icon" sizes="192x192" href="https://www.halotelco.org/User/images/android-chrome-192x192.png">
<!--[if lt IE 9]> <script src="js/ie/html5shiv.js"></script> <script src="js/ie/respond.min.js"></script> <script src="js/ie/excanvas.js"></script> <![endif]-->
<style type="text/css">html {
    overflow-y: scroll;
background: url(images/login2.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

</style>
<div id="google_translate_element" align="right"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, multilanguagePage: true}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        
</head>
<body class="">
<section id="content" class="m-t-lg wrapper-md animated fadeInUp">
  <div class="container aside-xl"> <a class="navbar-brand block" href="index.php">Hantar Katalaluan</a>
    <section class="m-b-lg">
      <header class="wrapper text-center"> <strong>Masukkan E-Mail Untuk Dapatkan Katalaluan</strong> </header>
      <form action="forgotpasswordck.php" method="post">
        <div class="list-group">
          <div class="list-group-item">
            <input type="email" placeholder="E-Mel berdaftar" class="form-control no-border" name="femail">
          </div>
          
        </div>
        <button type="submit" class="btn btn-lg btn-primary btn-block">Hantar Katalaluan Saya</button>
        <div class="text-center m-t m-b"><a href="index.php"><small>Mendapat Katalaluan?</small></a></div>
        <div class="line line-dashed"></div>
       
      </form>
    </section>
  </div>
</section>
<!-- footer -->
<footer id="footer">
  <div class="text-center padder">
    <p> <small>Jual Software MLM Professional Berasas Web Replika
+ MNP Halo Telco &#174;<br>&copy; 2020</small> </p>
  </div>
</footer>
<!-- / footer -->
<!-- Bootstrap -->
<!-- App -->
<script src="js/app.v1.js"></script>
<script src="js/app.plugin.js"></script>
</body>
</html>