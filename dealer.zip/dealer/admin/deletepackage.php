<?php
header( "refresh:2;url=pacsettings.php" );
include_once ("z_db.php");
// Inialize session
session_start();
// Semak, jika sesi nama pengguna TIDAK ditetapkan, halaman ini akan melompat ke laman log masuk
if (!isset($_SESSION['adminidusername'])) {
        print "
				<script language='javascript'>
					window.location = 'index.php';
				</script>
			";
			
}
$tomake= mysqli_real_escape_string($con,$_POST["packagedelid"]);

$result=mysqli_query($con,"UPDATE packages SET active=0 WHERE id='$tomake'");
if ($result)
{
print "<center>Pakej Dinyahaktifkan <br/>Mengalihkan arah dalam masa 2 saat...</center>";
}
else
{
print "<center>Tindakan tidak boleh dilakukan, Ada sesuatu yang tidak kena. Semak kembali lagi <br/>Mengalihkan arah dalam 2 saat ...</center>";
}

?>