<?php
$con = new mysqli("shareddb-s.hosting.stackcp.net", "wordpress-31323514cf", "e8e2eeeb822b", "wordpress-31323514cf");
if ($con->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
?>