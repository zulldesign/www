<?php
//mengumpul data
include_once ("z_db.php");
$email=mysqli_real_escape_string($con,$_POST['femail']);
$status=1;
if($status==1){

$status = "OK";
$msg="";
//memeriksa kekangan
if ( strlen($email) < 1 ){
$msg=$msg."Sila masukkan Id E-mel anda.<BR>";
$status= "NOTOK";}

if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)){
$msg=$msg."Id E-mel Tidak Sah, Sila masukkan Id E-mel yang Betul.<BR>";
$status= "NOTOK";
}


$result = mysqli_query($con,"SELECT count(*) FROM  affiliateuser where email = '$email'");
$row = mysqli_fetch_row($result);
$numrows = $row[0];

if(($numrows) == 0) {
$msg=$msg."Akaun anda tidak dijumpai atau akaun anda tidak aktif. Sila hubungi pentadbir anda.<BR>";
$status= "NOTOK";}
}

if($status=="OK")
{
$re = mysqli_query($con,"SELECT password FROM  affiliateuser where email = '$email'");
$r12 = mysqli_fetch_row($re);
$pwd = $r12[0];
//mengemas kini status jika pengesahan berlalu
$to=$email;
$subject="Permintaan Katalaluan";
$message="Mengikut permintaan anda, kami telah menghantar katalaluan anda.<br> Kata laluan anda adalah <b>$pwd</b><br><br>Salam";
mail($to,$subject,$message,$headers);

echo "<center>Kata laluan anda telah dihantar ke id mel berdaftar anda. Sila periksa folder sampah atau spam anda jika tidak terdapat dalam peti masuk anda. <br><input type='button' value='Log masuk sekarang' onClick='history.go(-1)'></center>";
}
else{
echo "<br/><br/><br/><center><font face='Verdana' size='2' color=red>$msg</font><br><input type='button' value='Cuba Semula' onClick='history.go(-1)'></center>"; //ralat primal jika didapati dalam pengesahan
}
?>