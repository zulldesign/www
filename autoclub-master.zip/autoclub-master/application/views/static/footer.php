<!------------ Footer section ------------>
<footer>

    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-3">&copy;<script type="text/javascript">document.write(new Date().getFullYear());</script> Letyoujoin.com</div>
            <div class="col-sm-12 col-md-2 col-md-offset-7">Created with <i class="fa fa-heart"></i></div>
        </div>

    </div>

</footer>



<script src="<?php echo base_url()?>js/jquery.js"></script>
<script src="<?php echo base_url()?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo base_url()?>js/jquery.backstretch.min.js"></script>
<script src="<?php echo base_url()?>js/isotope.js"></script>
<script src="<?php echo base_url()?>js/imagesloaded.min.js"></script>
<script src="<?php echo base_url()?>js/nivo-lightbox.min.js"></script>
<script src="<?php echo base_url()?>js/jquery.parallax.js"></script>
<script src="<?php echo base_url()?>js/smoothscroll.js"></script>
<script src="<?php echo base_url()?>js/wow.min.js"></script>
<script src="<?php echo base_url()?>js/core.js"></script>


</body>
</html>