
<!------------ Home Banner ------------>
<section id="banner" class="parallax">
    <div class="gradient-overlay"></div>
    <div class="container">
        <div class="row">

            <div class="col-md-offset-2 col-md-8 col-sm-12">
                <h1 class="wow fadeInUp" data-wow-delay="1s">Promising Future</h1>
                <p class="wow fadeInUp" data-wow-delay="1s">Tired of Day Jobs, Horrible Bosses, Tough Routines ?<br>
                    <small>Let's start a healthy and productive social network to create brotherhood with financial stability and time's independence</small>
                </p>
                <a href="<?php echo base_url().'Join'?>#todo" class="wow fadeInUp btn btn-transparent-white btn-capsul btn-lg smoothScroll" data-wow-delay="1.3s">Discover Now</a>
            </div>

        </div>
    </div>
</section>