<!------------Static navbar ------------>
<nav class="navbar navbar-default top-bar affix" data-spy="affix" data-offset-top="250" >
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Let You Join! </a><br><span style="color: #fff; font-weight: bolder">+92 331 641 416 4</span>
        </div>
        <div id="navbar" class="navbar-collapse collapse">

            <ul class="nav navbar-nav navbar-right">
                <li><a href="<?php echo base_url()?>#banner">Home</a></li>
                <li><a href="<?php echo base_url()?>#location">Members</a></li>
                <li><a href="<?php echo base_url().'Join'?>">Join</a></li>
                <li><a href="<?php echo base_url().'Login'?>">Login</a></li>

            </ul>
        </div><!--/.nav-collapse -->
    </div>
</nav>
