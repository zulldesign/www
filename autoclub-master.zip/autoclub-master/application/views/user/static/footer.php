<div class="layout-footer">
    <div class="layout-footer-body">
        <small class="version">Version 1.0.0</small>
        <small class="copyright">2017 &copy; ERP By <a href="http://letyoujoin.com/">LetYouJoin</a></small>
    </div>
</div>
</div>

<script src="<?php echo base_url()?>assets/js/vendor.minf9e3.js"></script>
<script src="<?php echo base_url()?>assets/js/elephant.minf9e3.js"></script>
<script src="<?php echo base_url()?>assets/js/application.minf9e3.js"></script>
<script src="<?php echo base_url()?>assets/js/demo.minf9e3.js"></script>
<script src="<?php echo base_url()?>assets/js/demo.minf9e3.js"></script>
<script src="<?php echo base_url()?>assets/js/profile.minf9e3.js"></script>
<script src="<?php echo base_url()?>assets/js/compose.minf9e3.js"></script>


</body>


</html>
<script>
    /*var time = new Date().getTime();
    $(document.body).bind("mousemove keypress", function(e) {
        time = new Date().getTime();
    });

    function refresh() {
        if(new Date().getTime() - time >= 60000)
            window.location.reload(true);
        else
            setTimeout(refresh, 10000);
    }

    setTimeout(refresh, 10000);*/
</script>