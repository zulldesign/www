<div class="layout-content">
    <div class="layout-content-body">
        <div class="title-bar">
            <h1 class="title-bar-title">
                <span class="d-ib">I am Referred By</span>
            </h1>
        </div>

        <div class="row gutter-xs">
            <div class="col-md-6 col-lg-6 col-lg-push-0">
                <div class="card bg-primary">
                    <div class="card-body">
                        <div class="media">
                            <div class="media-middle media-left">
                      <span class="bg-primary-inverse circle sq-48">
                        <span class="icon icon-user"></span>
                      </span>
                            </div>
                            <div class="media-middle media-body">
                                <h3 class="media-heading">
                                    <span class="fw-l"><?php echo $referred_by?></span>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>




    </div>
</div>