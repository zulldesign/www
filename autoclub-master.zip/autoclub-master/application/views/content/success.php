<!------------ Gallery section ------------>
<section id="banner" class="parallax">

    <div class="container">
        <div class="row">

            <div class="col-md-offset-2 col-md-8 col-sm-12">
                <h1 class="wow fadeInUp" data-wow-delay="1s">Congratulations!</h1>
                <p class="wow fadeInUp" data-wow-delay="1s">We have you on Board.<br>
                    <small>You will receive a call for verification</small>
                </p>
                <a href="<?php echo base_url().'Login'?>" class="wow fadeInUp btn btn-transparent-white btn-capsul btn-lg smoothScroll" data-wow-delay="1.3s">Login!</a>
            </div>

        </div>
    </div>
</section>
