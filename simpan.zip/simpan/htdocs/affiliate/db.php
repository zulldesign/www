<?php

session_start();
error_reporting(0);

$dbhost = 'sql111.epizy.com';
$dbuser = 'epiz_22867522';
$dbpass = 'surausaw';
$dbname = 'epiz_22867522_mlmsoft';

$con=mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) //connect to the database server
or die ("Could not connect to mysql because ".mysqli_error());

mysqli_select_db($con,$dbname)  //select the database
or die ("Could not select to mysql because ".mysqli_error());

//Admin User Credits
$admin_username = 'admin';
$admin_password = 'pass';

?>