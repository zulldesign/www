CREATE TABLE `referral` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `user` varchar(500) NOT NULL UNIQUE, 
 `str` varchar(500) NOT NULL UNIQUE,
 `clicks` int(255) NOT NULL DEFAULT  '0',
PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;