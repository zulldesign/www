<script type="text/javascript"><!--
google_ad_client = "pub-8475978623562162";
/* 468x60, created 10/24/09 */
google_language = "en";
google_ad_slot = "5161028221";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

<p align="center"><a style="font-size:9px; color: #B0B0B0; font-family: Verdana, Arial;" href="http://www.belajarphp.com" target="_blank"title="BelajarPHP">Powered by BelajarPHP </a></p>