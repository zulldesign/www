<?php include("./pass_protect.php"); ?>   <!--Masukkan (include) skrip ini pada page yang anda ingin protect (1st line):-->
<h1 align="center" style="padding-top:40px; padding-left:70px;">Selamat Datang</h1>
<p align="center" style="padding-top:40px; padding-left:70px;"><a href="demo1.php">DEMO1</a> | <a href="demo2.php">DEMO2</a> | <a href="?logout">logout</a><br />
    <br />
  Ini Adalah <strong>DEMO2</strong>.<br />
  Hanya boleh diakses selepas Login<br />
  <br />
  <br />
  <? include ("ads.php");?>
</p>
