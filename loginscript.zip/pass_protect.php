<?php

######################
#  SETTINGS START
#  Script By: BELAJARPHP.COM
#  Author : Zahisham
######################

// Ini adalah maklumat LOGIN / PASSWORD anda (sila tukar).
$LOGIN_INFORMATION = array(
  'login' => 'admin',
  'admin' => 'pass'
);

// request login? true - show login and password boxes, false - password box only
define('USE_USERNAME', true);

// User will be redirected to this page after logout
define('LOGOUT_URL', 'index.php');

// time out after NN minutes of inactivity. Set to 0 to not timeout
define('TIMEOUT_MINUTES', 1);  // <--- cth ini, dalam masa 1 minit auto logout

// This parameter is only useful when TIMEOUT_MINUTES is not zero
// true - timeout time from last activity, false - timeout time from login
define('TIMEOUT_CHECK_ACTIVITY', true);

######################
#  SETTINGS END
######################


$timeout = (TIMEOUT_MINUTES == 0 ? 0 : time() + TIMEOUT_MINUTES * 60);


if(isset($_GET['logout'])) {
  setcookie("verify", '', $timeout, '/');
  header('Location: ' . LOGOUT_URL);
  exit();
}

if(!function_exists('showLoginPasswordProtect')) {


function showLoginPasswordProtect($error_msg) {
?>
<html>
<head>
  <title>Login to Web Folder</title>
  <META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
  <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
</head>
<body>
  <style>
    input { border: 1px solid black; }
  </style>
<div style="width:500px; margin-left:auto; margin-right:auto; text-align:center; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;">Login : <strong>admin</strong><br>
  Password : <strong>pass</strong> <br>
  <table width="450" cellspacing="0" cellpadding="0">
    <tr>
      <td width="450" height="250" align="center" background="login.jpg">
	  <table width="450" cellspacing="0" cellpadding="0" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px;">
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="194">&nbsp;</td>
            <td width="254">  
			<form method="post">
			<font color="red"><?php echo $error_msg; ?></font><br />
			<?php if (USE_USERNAME) echo 'Login:<br /><input type="input" name="access_login" /><br />Password:<br />'; ?>
			<input type="password" name="access_password" /><p></p><input type="submit" name="Submit" value="Log Masuk" />
			</form>  			</td>
          </tr>
        </table>
	  </td>
    </tr>
  </table>



 
<a style="font-size:9px; color: #B0B0B0; font-family: Verdana, Arial;" href="http://www.belajarphp.com" target="_blank"title="BelajarPHP">Powered by BelajarPHP </a>  </div>
</body>
</html>

<?php

  die();
}
}


if (isset($_POST['access_password'])) {

  $login = isset($_POST['access_login']) ? $_POST['access_login'] : '';
  $pass = $_POST['access_password'];
  if (!USE_USERNAME && !in_array($pass, $LOGIN_INFORMATION)
  || (USE_USERNAME && ( !array_key_exists($login, $LOGIN_INFORMATION) || $LOGIN_INFORMATION[$login] != $pass ) ) 
  ) {
    showLoginPasswordProtect("Password Tidak Sah.");
  }
  else {

    setcookie("verify", md5($login.'%'.$pass), $timeout, '/');
    

    unset($_POST['access_login']);
    unset($_POST['access_password']);
    unset($_POST['Submit']);
  }

}

else {


  if (!isset($_COOKIE['verify'])) {
    showLoginPasswordProtect("");
  }


  $found = false;
  foreach($LOGIN_INFORMATION as $key=>$val) {
    $lp = (USE_USERNAME ? $key : '') .'%'.$val;
    if ($_COOKIE['verify'] == md5($lp)) {
      $found = true;

      if (TIMEOUT_CHECK_ACTIVITY) {
        setcookie("verify", md5($lp), $timeout, '/');
      }
      break;
    }
  }
  if (!$found) {
    showLoginPasswordProtect("");
  }

}

?>
