<?php include("./pass_protect.php"); ?>
<h1 align="center" style="padding-top:40px; padding-left:70px;">Selamat Datang</h1>
<p align="center" style="padding-top:40px; padding-left:70px;"><a href="demo1.php">DEMO1</a> | <a href="demo2.php">DEMO2</a> | <a href="?logout">logout</a><br />
  <br />
 Halaman Utama.<br />
 Sesi ini akan log keluar secara automatik selepas 1 minit (boleh tukar setting). <br />
 <br />
 <? include ("ads.php");?>  
  <strong></strong><br />
</p>
