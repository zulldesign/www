<?
include "config.php";
mysql_close();
?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><? echo $sitename; ?> Terms and Conditions</title>
<meta name="robots" content="noindex,nofollow"><style>
<!--
BODY {
background-image: url(/images/bg.jpg);
background-repeat:repeat-x;
background-position:top;
background-attachment:fixed;
margin-top: 0px;
margin-bottom: 0px;
}
--></style>
</head>

<body>

<div align="center">
	<table border="0" cellpadding="5" cellspacing="5" width="851" bgcolor="#FFFFFF">
		<tr>
			<td>

<center>
<h2><font face="Tahoma" color="#0000FF"><? echo $sitename; ?> Terms and Conditions</font></h2>
<p>&nbsp;</p></center>
			<p><u><b><font face="Tahoma">AGE Limit</font></b></u></p>
			<p><font face="Tahoma">You agree that you are the age of 18 or 
			older.</font></p>
			<p><u><b><font face="Tahoma">Commissions</font></b></u></p>
			<p><font face="Tahoma">A Pro Member is not guaranteed to get paid unless you have referred at least one Paid Member.  However, everyone can request that their commissions be traded with advertising package and we promise to treat them with greater value.  Make sure you do not come to <?php echo $sitename ?> to click for money alone.  Although we offer Cash Rewards we should not be treated like a Paid-to-Click Program.  We do not pay Inactive Members.  Active Members means: must be logging in regularly, posting and viewing ads including Free Ads.</font></p>

<p><u><b><font face="Tahoma">REWARDS and BONUSES</font></b></u></p>
			<p><font face="Tahoma"> We are happy to reward active members that is why in <?php echo $sitename ?>,  
Points earned can be traded for cash per request.  
However, we decide on your points and we do not guarantee that 
everyone�s request will be granted.  Once you have requested trading 
points to cash, you also agree that some of the points will be traded 
for advertising package. We promise to treat them with greater value.   
Trading Points to Cash is only a �reward� and should not be treated 
as �ACTUAL CASH COMMISSION�.
We can CANCEL, change, refuse to give or take back any bonus 
or reward that was offered.  </font></p>

			<p><font face="Tahoma"><b><u>Number of Accounts</u></b></font></p>
			<p><font face="Tahoma">You agree to only create 1 account.</font></p>
			<p><font face="Tahoma"><b><u>EMAILS</u></b> <br><br>By joining 
			<? echo $sitename; ?> <b>YOU AGREE TO RECEIVE UP TO 7 EMAILS EVERY 24HRS FROM <? echo $adminemail; ?>.  Please add this email address to your address book and mark all emails from <? echo $adminemail; ?> as NOT SPAM.  This is to ensure all members get other members' Solo Ads as well as website updates, commissions info etc.</b>  Again, these emails may be for updates, account issues, <? echo $sitename; ?> promotions including but not limited to <b>Solo Ads</b> from <? echo $sitename; ?> members or anything that <? echo $sitename; ?> needs to relay to all members.  You also agree to receive up to 2 emails every 7 days from your sponsor from the referral mailer.  Your sponsor will not know your email address.  </font></p><p><font face="Tahoma"><? echo $sitename; ?> will send 5 solo ads at most per day and occasionally 1 admin email.&nbsp; Most will be <b>Solo Ads</b>, you will be rewarded with points when you read them.&nbsp; 		</b></font></p>
			<p><font face="Tahoma"><b><u>Posting Text Ads</u></b></font></p>
			<li><font face="Tahoma" size="2">You agree that any ad posts that 
			displays and/or connects with malware, porn, gambling, warez, or 
			other inappropriate sites will be DELETED and that your account will 
			be deleted without refund.</font></li>
			<li><font face="Tahoma" size="2">You agree that no ad posts will 
			promote any form of illegal activity. You agree that all ad posts 
			will be fully compliant with federal and state laws.</font></li>
			<li><font face="Tahoma" size="2">You agree to no racist or hateful 
			ads.</font></li>
			<li><font face="Tahoma" size="2">You agree to only have links in ad 
			posts that point to other html web pages. You agree to have no links 
			to e-books, downloads, zip files, mp3�s etc.</font></li>
			<li><font face="Tahoma" size="2">You agree to only use URLs that do not break frames.</font></li>
			<li><font face="Tahoma" size="2">You agree not to include profanity 
			in your ad posts.</font></li>
			<li><font face="Tahoma" size="2">You agree that any form of 
			misleading readers will not be tolerated.</font></li>
			<p><font face="Tahoma"><b><u>No Autoresponders or Bounced Emails are allowed</u></b></font></p>
			<p><font face="Tahoma">If your email address bounces or sends back <? echo $sitename; ?> a message with an autoresponder, you risk having 
	your account deleted. Once your account is deleted you will have to contact <? echo $adminname; ?> to upgrade you back to Pro if you were a Pro member.  You will be required to show proof of your Upgrade to Pro by supplying your PayPal transaction ID#.  All referrals, points and COMMISSIONS will be lost if your account is deleted.&nbsp;</font></p>
			<p><font face="Tahoma"><b><u>Liability</u></b> <br><? echo $sitename; ?> is a promotional marketing tool 
			used to help members 
	promote all of their offers on the Internet. <? echo $sitename; ?> does not 
	make any promises written or implied as to the amount of money that can be 
	made from <? echo $sitename; ?>. </font></p>
			<p><font face="Tahoma">It is your responsibility to make sure your email 
	address for your PayPal account is correct. Commission payments 
	made to the wrong account because of an incorrectly entered id is your 
			responsibility. Should your account at PayPal be locked or restricted for any 
	reason, that is also your responsibility. <? echo $sitename; ?> will not be 
	held liable. </font></p>
			<p><font face="Tahoma"><b><u>Policies</u></b> <br>All policies, rules and regulations are the final decision of 
			<? echo $sitename; ?>.&nbsp; We reserve the right to modify, add or change any policies 
	as we deem necessary at any time. All members agree that they will not hold 
			<? echo $sitename; ?> liable for any items or policies within this program.
			</font></p>
			<p><font face="Tahoma"><b><u>Refunds</u></b> <br>NO REFUNDS WILL BE MADE.  All purchases are Final. We are open and are willing to help with any issues that may arise and you can always open a Support Ticket.  All items purchased in this site are NON-TANGIBLE.  Once you made a purchase, you agree that you will never get a Refund.  We have zero tolerance to "TRICKY Purchases" after enjoying the item/service purchased, should you file charge back or dispute on payment processors, your account will be deleted.   You will lose any earned commissions and will not be eligible for payment. &nbsp; By joining and paying for any paid portion of <? echo $sitename; ?>, you agree to all the terms and conditions 
	on this page. </font></p>
			<p><font face="Tahoma"><b><u>SPAM</u></b> <br><? echo $sitename; ?> has a 
			<font color="#FF0000"><b>zero</b></font> tolerance for spam. Anyone caught spamming 
	will be deleted from the program and is subject to civil and criminal 
	prosecution including up to $50,000 in fines.&nbsp; If you are to include 
			<? echo $sitename; ?>'s name or URL in any email promotion, please only 
			email to your own &quot;double-optin&quot; subscribers.&nbsp; Safelists are 
			also allowed as well as downline mailing programs such as	YourLuckyList.</font></p>
			<p><font face="Tahoma">The following are grounds for 
	termination of your account: </font></p>
			<p><font face="Tahoma">To send unsolicited emails to anyone that is 
			not on your own personal double-optin list.&nbsp;&nbsp; <b>If this 
			does not make sense to you, then do not include promotions for 
			<? echo $sitename; ?> in emails.</b><br>To falsify user information provided to 
			<? echo $sitename; ?> or to other 
	users of the service in connection with <? echo $sitename; ?>, or any of it's 
	other sites.<br>To use the <? echo $sitename; ?> name and URL via bought commercial 
			bulk email lists.<br>&nbsp;</font></p>
			<p><font face="Tahoma"><? echo $sitename; ?> considers the above practices to 
	constitute abuse of our service and of the recipients of such unsolicited 
	mailings and/or postings who often bear the expense. Therefore, these 
	practices are prohibited by <? echo $sitename; ?> terms and conditions of 
	service. Engaging in one or more of these practices will result in 
	termination of the offender's account. </font></p>
			<p><font face="Tahoma">In addition, we have the right, where feasible, to 
	implement technical mechanisms which block multiple postings as described 
	above before they are forwarded. </font></p>
			<p><font face="Tahoma">Nothing contained in this policy shall be construed 
	to limit <? echo $sitename; ?> actions or remedies in any way with respect to 
	any of the foregoing activities. </font></p>
			<p><font face="Tahoma"><? echo $sitename; ?> reserves the right to take any 
	and all additional actions it may deem appropriate with respect to such 
	activities, including without limitation taking action to recover the costs 
	and expenses of identifying offenders and removing them from the program.
			</font></p>
			<p><font face="Tahoma">In addition, <? echo $sitename; ?> reserves at all 
	times all rights and remedies available to it with respect to such 
	activities at law or in equity. </font></p>
			<p><font face="Tahoma">We use IP tracking devices. Any user that is found to 
	blatantly violate this agreement will be banned from the program 
	indefinitely and may be subject to civil and criminal prosecution. </font>
			</p>
			<p><font face="Tahoma">We reserve the right to refuse service to anyone. We 
	may also make changes to these rules, regulations, and policies at any time.
			</font></p>
			<p><b><font face="Tahoma">By becoming a Free Member or a Pro Member of 
			<? echo $sitename; ?>, you agree to all of the above terms and conditions.</font></b></p>
			<p><b><font face="Tahoma">To Your Success,</font></b></p>
			<address align="left"><b><font face="Tahoma"><? echo $adminname; ?></font></b></address>
			<address align="left"><b><font face="Tahoma">President and CEO</font></b></address>
			<address align="left"><b><font face="Tahoma"><? echo $sitename; ?></font></b></address></td>
		</tr>
	</table>
</div>

</body>

</html>