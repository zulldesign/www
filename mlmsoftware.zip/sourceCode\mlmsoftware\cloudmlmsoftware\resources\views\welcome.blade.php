<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Free MLM Software with best features for your business dashboard at http://cloudmlmsoftware.com</title>

        <meta name="description" content="Free MLM Software with best features for your MLM business dashboard at http://cloudmlmsoftware.com" />

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #348efe;
                color: #fff;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #FFF;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            img.logo {
                margin-top: -30px;
            }

            h1.mlmsoftware-intro {
                margin-top: 30px;
                margin-bottom: 30px;
                font-weight: 100;
            }

        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    <a href="{{ url('/login') }}">Login</a>
                    <a href="{{ url('/register') }}">Register</a>
                </div>
            @endif

            <div class="content">
            
                <img class="logo" src="{{asset('images/cloudmlmsoftware-logo.png')}}" style="width:200px;" />

                <div class="title m-b-md">
                    Cloud MLM Software
                </div>

                <h1 class="mlmsoftware-intro"> Free MLM Software with best features for your MLM business dashboard </h1>


                <div class="links">
                    <a href="http://cloudmlmsoftware.com/cloud-mlm-software-features">Features</a>
                    <a href="http://cloudmlmsoftware.com/presets">Online Demo</a>
                    <a href="http://cloudmlmsoftware.com/blog">Blog</a>
                    <a href="http://cloudmlmsoftware.com/contact">Support / Contact</a>
                </div>
            </div>
        </div>
    </body>
</html>
