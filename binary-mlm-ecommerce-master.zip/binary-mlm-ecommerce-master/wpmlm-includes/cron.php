<?php
	add_action( 'wpmlm_hourly_cron_task', 'wpmlm_clear_stock_claims' );
	/**
	 * wpmlm_clear_stock_claims, clears the stock claims, runs using wp-cron and when editing purchase log statuses via the dashboard
	 */
	function wpmlm_clear_stock_claims() {
		global $wpdb;

		$time = (float) get_option( 'wpmlm_stock_keeping_time', 1 );
		$interval = get_option( 'wpmlm_stock_keeping_interval', 'day' );

		// we need to convert into seconds because we're allowing decimal intervals like 1.5 days
		$convert = array(
			'hour' => 3600,
			'day'  => 86400,
			'week' => 604800,
		);

		$seconds = floor( $time * $convert[$interval] );

		$sql = $wpdb->prepare( "DELETE FROM " . WPMLM_TABLE_CLAIMED_STOCK . " WHERE last_activity < NOW() - INTERVAL %d SECOND", $seconds );
		$wpdb->query( $sql );
	}
?>