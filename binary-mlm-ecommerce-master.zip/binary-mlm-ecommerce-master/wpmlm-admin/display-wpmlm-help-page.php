<?php function wpmlm_help()
{
?>

<div class='wrap'>
	<div class="widgetbox">
		<div class="title"><h3>Help</h3></div>

		<div class="notibar msginfo">
			
			<p>	help page
			
			</p>
			
			
			
			
		</div>
	</div>
</div>		
		




<?php 
}
?>