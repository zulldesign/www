function pvSetForProduct(urlpath, pid, pvvalue) 
{         
alert(pvvalue);
    /*var xmlhttp;
	document.getElementById("epinmsg_"+user_id).innerHTML= '<img src="'+ urlpath +'/images/ajax-loader.gif" class="loadImage" />';
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	if (xmlhttp.status==200 && xmlhttp.readyState==4)
	{
	 document.getElementById("epinmsg_"+user_id).innerHTML=xmlhttp.responseText;
	 window.setTimeout(function(){location.reload()},500)
	}
	} 
	xmlhttp.open("GET", urlpath+'/epinUpdate.php?user_id='+user_id+'&epin='+epin,true);
	xmlhttp.send();
	*/
}