<center>
<p align="center">
|&nbsp;<a href="<?php echo $domain ?>/details.php?referid=<?php echo $referid ?>" target="_blank"><font color="#000000">Program Details</a>&nbsp;|&nbsp;
<a href="<?php echo $domain ?>/affiliate.php?referid=<?php echo $referid ?>" target="_blank"><font color="#000000">Affiliate Program</a>&nbsp;|&nbsp;
<a href="<?php echo $domain ?>/terms.php?referid=<?php echo $referid ?>" target="_blank"><font color="#000000">Terms and Conditions</a>&nbsp;|&nbsp;
<a href="<?php echo $domain ?>/spam.php?referid=<?php echo $referid ?>" target="_blank"><font color="#000000">Spam/Privacy Policy</a>&nbsp;|&nbsp;
<a href="<?php echo $domain ?>/earnings.php?referid=<?php echo $referid ?>" target="_blank"><font color="#000000">Earnings Disclaimer</a>&nbsp;|&nbsp;
<a href="<?php echo $domain ?>/faq.php?referid=<?php echo $referid ?>" target="_blank"><font color="#000000">FAQ</a>&nbsp;|
<br><br>
<font color="#000000" size="1">&copy; 2014 Custom PHP Script Development By <a href="http://phpsitescripts.com" target="_blank"><font size="1">Sabrina Markon, PHPSiteScripts.com</a>, Proudly Powered by <a href="http://sunshinehosting.net" target="_blank"><font size="1">SunshineHosting.net</a>
<br>
</td>
</tr>
</table>
<img src="<?php echo $domain ?>/images/footer.jpg"></center>
</body>
</html>