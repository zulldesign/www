/* CSS file for row dialog in the table plugin */

.panel_wrapper div.current {
	height: 200px;
}

.advfield {
	width: 200px;
}

#action {
	margin-bottom: 3px;
}

#rowtype,#align,#valign,#class,#height {
	width: 150px;
}

#height {
	width: 50px;	
}

.col2 {
	padding-left: 20px;
}
