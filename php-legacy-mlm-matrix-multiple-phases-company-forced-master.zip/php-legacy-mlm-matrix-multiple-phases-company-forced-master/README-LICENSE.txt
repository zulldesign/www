#############################################################################
# CUSTOM BUILD MLM E-Business Script - MULTI-PHASE COMPANY FORCED MATRIX WITH SPILLOVER/SPILLUNDER v10.1      		      
# Script Developed By: Sabrina Markon 				      
# Copyright 1998-2014 Sabrina Markon sabrina@phpsitescripts.com  
# PearlsOfWealth.com / SunshineHosting.net / PHPSiteScripts.com
#############################################################################
#                          COPYRIGHT NOTICE                      
#                                                                  
#    Software Copyright All Rights Reserved Sabrina Markon 
#                                                                  
#  This script can be used on your own website as long as you don't   
#  change this header, any of my copyright notices in the script, or  
#  attempt to reverse-engineer any of my software encryption.         
#                                                                 
# Redistributing\selling  the  code for this software is NOT allowed. 
# Period. Copies may be purchased either from myself or from one of   
#  my colleagues above who are the ONLY ones permitted to resell.     
#								      
# Use for any  unauthorized  purpose is expressly prohibited by law,  
# and  may  result  in  severe  civil  and  criminal  penalties.      
# Violators  will  be  prosecuted  to  the  maximum extent possible.  
#                                                                     
# YOU MAY NOT RESELL OR RELEASE THIS PROGRAM OR ITS GRAPHIC DESIGN TO OTHERS         
# NEITHER IN FULL NOR IN PART.
#
# Copyright dates are ALL years after the original copyright date until they enter public
# domain, which is normally 50 years after the death of the author and with content
# by her/his descendents.
#
#######################################################################

Carefully read the following terms and conditions before purchasing this software.
Unless you have a different license agreement signed by Sabrina Markon your purchase of this software indicates your
acceptance of this license agreement and warranty. 
BY PURCHASING THE SOFTWARE YOU ACKNOWLEDGE THAT YOU HAVE READ THIS AGREEMENT,
AND THAT YOU UNDERSTAND AND AGREE TO BE BOUND BY ITS TERMS AND SUBJECTS TO ITS CONDITIONS. 

This agreement shall be governed by the laws of any States and any countries.
If the agreement is violated in any manner, the license may be revoked at the discretion of Sabrina Markon,
at any time. There are no refunds given for revoked licenses.
Revocation of license is at the sole discretion of Sabrina Markon. 

YOU FURTHER AGREE THAT THIS AGREEMENT IS THE COMPLETE AND EXCLUSIVE STATEMENT CONCERNING
THE SUBJECT MATTER OF THE AGREEMENT BETWEEN Sabrina Markon AND YOU,
AND SUPERSEDES ANY PROPOSAL(S), OR PRIOR AGREEMENT(S), WHETHER WRITTEN OR ORAL,
RELATING TO THE SUBJECT MATTER OF THE AGREEMENT. 

Limit of Liability: Sabrina Markon is not, and will not, be held liable for any conduct associated with your use of this program,
for your advertising activity, nor for any content posted using Sabrina Markon or SunshineHosting.net programs. 

The user must assume the entire risk of using the program. Sabrina Markon is not to be held, and will not accept,
any liability for any damages, direct or consequential, resulting from the installation or use of this software.
This includes, but is not limited to, loss of stored data or loss of operational capability
of the associated hardware and software systems. 


Disclaimer of Warranty:
THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SOLD "AS IS" AND WITHOUT WARRANTIES AS TO PERFORMANCE
OR MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED THE PURCHASER AGREES TO HOLD Sabrina Markon HARMLESS
AND WITHOUT LIABILITY IN MATTERS OF DAMAGES, EITHER DIRECT, OR CONSEQUENTIAL, WHICH RESULT EITHER DIRECTLY OR INDIRECTLY,
FROM THE USE OR NON-USE OF THIS SOFTWARE. ANY LIABILITY OF THE SELLER WILL BE LIMITED EXCLUSIVELY TO PRODUCT
REPLACEMENT OR REFUND OF PURCHASE PRICE IN ACCORDANCE WITH THE STATED REFUND POLICY. 

Grant of License:
One licensed copy of the program may reside on a single server.
For each installed instance of the program, a separate license is required.
Registered users may alter or modify this software, at their own risk.
Users or license owners may not give non license holders access to or permission
to modify the software, however. Although license-holders may modify the code for their use, modified code
may NOT be resold or distributed. All copyright notices used within the scripts MUST remain intact. 

Ownership:
While license-holder owns the magnetic or digital media, or online delivered file,
on which the licensed software is originally stored, the Licensor (Sabrina Markon) RETAINS TITLE AND OWNERSHIP of the
software recorded on the original magnetic or digital media or online delivered file and all subsequent copies of it.

THIS LICENSE IS NOT A SALE OF THE ORIGINAL SOFTWARE OR ANY COPY!

ATTEMPTS TO REVERSE ENGINEER, COPY, RESELL, or otherwise steal my work will result in first, a formal complaint
filed with your host as well as their upline bandwidth provider(s). At this point your license is revoked and you are required
to delete the software and all copies entirely immediately or face further action (such as forcible remote removal of the stolen
material by myself).

Copyright Notice & Usage Disclaimer:
Although you may customize the software as you like, you MAY NOT alter or remove the copyright and "powered by"
notices throughout the system.
In addition, by using these scripts you agree to assume full liability for any content or banners you or others 
post on your system. You also agree that Sabrina Markon is not liable for any mishaps that may result due to installation
of the scripts. These scripts MAY NOT be sold or in any way re-used or licensed without the express written consent
of Sabrina Markon. 


Additional Terms & Conditions :


Script Distribution:
The script will be distributed in its default layout with the features and functions as seen on our demo pages. 
Custom layouts and graphics may be ordered from us. The minimum (and average) charge is 75.00, but may be
higher depending on the complexity of the graphics ordered.

Installation:
installation will be given upon request on server that fully satisfies requirements at extra cost of $50 US per script.

Modifications:
3rd party modifications prohibited without permission of Sabrina Markon
(this does not include localisations). Any 3rd party modification can cause warranty void.
Repairs to scripts damaged due to this type of tampering can be ordered. Minimum charge for repairs of this
nature is 100.00.

Updates:
We provide 1 free update of our scripts.
Updates that require file uploading, setting file permissions and setting server variables in files
must be performed by the client OR service may be purchased from us for 50.00.

Refund Policy:
# Refunds are given within 30 days after purchase if the script does not work as the proposed demo version.
# Refunds are NOT given if server specifications does not meet requirements as listed on our corresponding product info page.
# Refunds are NOT given for unsuitability to a webserver requirement for which the requirements are clearly listed on the product site.
# Refunds are NOT given for missing "features" or missing capabilities for our products which feature a fully functional online demo
  or for which we have arranged a trial period. The customer is responsible for determining if the product is suitable
  by using the demo or trial software.
# Refunds are NOT given for installation fees or other non-product labor costs. 

Run-Your-Own-Service Guarantee
Sabrina Markon provides the technology that allows you to run your own service as outlined
on our product info page and as seen on the corresponding demo pages with all features and functions.
However Sabrina Markon does not give an income guarantee .

For more info contact us at
http://phpsitescripts.com/helpdesk
http://sunshinehosting.net/helpdesk
sabrina@phpsitescripts.com
sabrina@sunshinehosting.net
sabrina.markon@gmail.com
CEO and Senior Developer Sabrina Markon
Copyrights 2002-2014, Sabrina Markon All rights reserved.
http://phpsitescripts.com
http://sunshinehosting.net
