<?php
$username = $userid;
########################################################################
########################################################################
function MatrixAdd($username,$matrixlevelname,$matrixwidth,$matrixdepth,$matrixprice,$matrixpayout,$givereentrythislevel,$matrixsequence,$matrixid,$cyclecommissionforsponsor)
{
global $paychoice,$transaction,$adpackid;
# make sure userid exists before adding to a matrix.
$q00 = "select * from members where userid=\"$username\"";
$r00 = mysql_query($q00);
$row00 = mysql_num_rows($r00);
if ($row00 > 0)
{
# in company forced version, referring matrix ID is always #1.
####################################################################################
$matrixtablename = "matrix" . $matrixid;
$vacancyq = "select * from $matrixtablename where username=\"VACANT\" order by id limit 1";
$vacancyr = mysql_query($vacancyq);
$vacancyrows = mysql_num_rows($vacancyr);
if ($vacancyrows > 0)
{
$vacancyid = mysql_result($vacancyr,0,"id");
$addq = "update $matrixtablename set username=\"$username\",paychoice=\"$paychoice\",transaction=\"$transaction\",signupdate=NOW() where id=\"$vacancyid\"";
$addr = mysql_query($addq);
$addq0 = "insert into transactions (userid,action,`date`,quantity) values ('$username','$transaction - $matrixid Matrix Phase: $matrixlevelname Position','".time()."','$amount')";
$addr0 = mysql_query($addq0);
for($i=1;$i<=$matrixdepth;$i++)
{
$parentid = "parent" . $i;
$parentusername = "parent" . $i . "username";
$refq = "update $matrixtablename set $parentusername=\"$username\" where $parentid=\"$vacancyid\"";
$refr = mysql_query($refq);
} # for($i=1;$i<=$matrixdepth;$i++)

if ($adpackid != "")
{
$apackq = "select * from adpacks where id=\"$adpackid\"";
$apackr = mysql_query($apackq);
$apackrows = mysql_num_rows($apackr);
if ($apackrows > 0)
{
$countq = "update adpacks set howmanytimeschosen=howmanytimeschosen+1 where id=\"$adpackid\"";
$countr = mysql_query($countq);
$description = mysql_result($apackr,0,"description");
$points = mysql_result($apackr,0,"points");
$surfcredits = mysql_result($apackr,0,"surfcredits");
$banner_num = mysql_result($apackr,0,"banner_num");
$banner_views = mysql_result($apackr,0,"banner_views");
$solo_num = mysql_result($apackr,0,"solo_num");
$traffic_num = mysql_result($apackr,0,"traffic_num");
$traffic_views = mysql_result($apackr,0,"traffic_views");
$login_num = mysql_result($apackr,0,"login_num");
$login_views = mysql_result($apackr,0,"login_views");
$hotlink_num = mysql_result($apackr,0,"hotlink_num");
$hotlink_views = mysql_result($apackr,0,"hotlink_views");
$button_num = mysql_result($apackr,0,"button_num");
$button_views = mysql_result($apackr,0,"button_views");
$ptc_num = mysql_result($apackr,0,"ptc_num");
$ptc_views = mysql_result($apackr,0,"ptc_views");
$featuredad_num = mysql_result($apackr,0,"featuredad_num");
$featuredad_views = mysql_result($apackr,0,"featuredad_views");
$hheaderad_num = mysql_result($apackr,0,"hheaderad_num");
$hheaderad_views = mysql_result($apackr,0,"hheaderad_views");
$hheadlinead_num = mysql_result($apackr,0,"hheadlinead_num");
$hheadlinead_views = mysql_result($apackr,0,"hheadlinead_views");
########################################################
if ($points > 0)
	{
	mysql_query("UPDATE members SET points=points+".$points." WHERE userid='".$username."'");
	}
if ($surfcredits > 0)
	{
	mysql_query("UPDATE members SET surfcredits=surfcredits+".$surfcredits." WHERE userid='".$username."'");
	}
if ($solo_num > 0)
	{
		$count = $solo_num;
		while($count > 0) {
			mysql_query("INSERT INTO `solos` (`id` ,`userid` ,`approved` ,`subject` ,`adbody` ,`sent` ,`added`) VALUES (NULL , '".$username."', '0', '', '', '0', '0')");
			$count--;
		}
	}
if (($featuredad_num > 0) and ($featuredad_views > 0))
	{
		$count = $featuredad_num;
		while($count > 0) {
			mysql_query("insert into featuredads (userid,max,purchase) values('$username','".$featuredad_views."',NOW())");
			$count--;
			}
	}
if (($hheaderad_num > 0) and ($hheaderad_views > 0))
	{
		$count = $hheaderad_num;
		while($count > 0) {
			mysql_query("insert into hheaderads (userid,max,purchase) values('$username','".$hheaderad_views."',NOW())");
			$count--;
			}
	}
if (($hheadlinead_num > 0) and ($hheadlinead_views > 0))
	{
		$count = $hheadlinead_num;
		while($count > 0) {
			mysql_query("insert into hheadlineads (userid,max,purchase) values('$username','".$hheadlinead_views."',NOW())");
			$count--;
			}
	}
if (($banner_num > 0) and ($banner_views > 0))
	{
		$count = $banner_num;
		while($count > 0) {
			mysql_query("INSERT INTO `banners` ( `id` , `name` , `bannerurl` , `targeturl` , `userid` , `status` , `shown` , `clicks` , `max` , `added` )VALUES (NULL , '', '', '', '".$username."', '0', '0', '0', '".$banner_views."', '0')");
			$count--;
		}
	}
if (($button_num > 0) and ($button_views > 0))
	{
		$count = $button_num;
		while($count > 0) {
			mysql_query("INSERT INTO `buttons` ( `id` , `name` , `bannerurl` , `targeturl` , `userid` , `status` , `shown` , `clicks` , `max` , `added` )VALUES (NULL , '', '', '', '".$username."', '0', '0', '0', '".$button_views."', '0')");
			$count--;
		}
	}
if (($login_num > 0) and ($login_views > 0))
	{
		$count = $login_num;
		while($count > 0) {
			mysql_query("insert into loginads (userid,max) values('$username','".$login_views."')");
			$count--;
		}
	}
if (($traffic_num > 0) and ($traffic_views > 0))
	{
		$count = $traffic_num;
		while($count > 0) {
			mysql_query("insert into tlinks (userid,paid) values('$username','".$traffic_views."')");
			$count--;
		}
	}
if (($hotlink_num > 0) and ($hotlink_views > 0))
	{
		$count = $hotlink_num;
		while($count > 0) {
			mysql_query("insert into hotlinks (userid,max) values('$username','".$hotlink_views."')");
			$count--;
		}
	}
if (($ptc_num > 0) and ($ptc_views > 0))
	{
		$count = $ptc_num;
		while($count > 0) {
			mysql_query("insert into ptcads (userid,paid) values('$username','".$ptc_views."')");
			$count--;
		}
	}
} # if ($apackrows > 0)
} # if ($adpackid != "")

} # if ($vacancyrows > 0)
####################################################################################
if ($vacancyrows < 1)
{
$addq = "select * from $matrixtablename where L1<".$matrixwidth." order by id limit 1";
$addr = mysql_query($addq);
$addrow = mysql_num_rows($addr);
	if ($addrow > 0)
		{
		$newreferrername = mysql_result($addr,0,"username");
		$newreferrerid = mysql_result($addr,0,"id");
		$addqbuildfields = "";
		$addqbuildvalues = "\"$newreferrerid\",\"$newreferrername\",";
		for($i=1;$i<=$matrixdepth;$i++)
		{
		$downlinevariablenameid = "referrerparent" . $i;
		$downlinevariablenameidinsql = "parent" . $i;
		$downlinevariablenamename = "referrerparent" . $i . "name";
		$downlinevariablenamenameinsql = "parent" . $i . "username";
		eval("\$downlinevariablenameid = mysql_result(\$addr,0,\"$downlinevariablenameidinsql\");");
		eval("\$downlinevariablenamename = mysql_result(\$addr,0,\"$downlinevariablenamenameinsql\");");
		$addqbuildfields = $addqbuildfields . "parent" . $i . "," . "parent" . $i . "username,";
		if ($i < $matrixdepth)
		{
		$addqbuildvalues = $addqbuildvalues . "\"" . $downlinevariablenameid . "\",\"" . $downlinevariablenamename . "\",";
		}
		###
		if ($i == 1)
		{
		$addq1 = "update $matrixtablename set L1=L1+1 where id=\"".$newreferrerid."\"";
		$addr1 = mysql_query($addq1) or die(mysql_error());
		}
		if ($i != 1)
		{
		$oneless = $i-1;
		$downlinevariablenameidonelessinsql = "parent" . $oneless;
		eval("\$downlinevariablenameidonelessinsql = mysql_result(\$addr,0,\"$downlinevariablenameidonelessinsql\");");
		$addq1 = "update $matrixtablename set L$i=L$i+1 where id=\"".$downlinevariablenameidonelessinsql."\"";
		$addr1 = mysql_query($addq1) or die(mysql_error());
		}
		} # for($i=1;$i<=$matrixdepth;$i++)
$poq = "select * from $matrixtablename order by positionordernumber desc limit 1";
$por = mysql_query($poq);
$porows = mysql_num_rows($por);
if ($porows > 0)
{
$lastpositionordernumber = mysql_result($por,0,"positionordernumber");
$positionordernumber = $lastpositionordernumber+1;
}
		$addq0 = "insert into $matrixtablename (username," . $addqbuildfields . "urlreferrerid,urlreferrername,paychoice,transaction,positionordernumber,signupdate) values (\"$username\"," . $addqbuildvalues . "\"$newreferrerid\",\"$newreferrername\",\"$paychoice\",\"$transaction\",\"$positionordernumber\",NOW())";
		$addr0 =  mysql_query($addq0) or die(mysql_error());
		$addq0 = "insert into transactions (userid,action,`date`,quantity) values ('$username','$transaction - $matrixid Matrix Phase: $matrixlevelname Position','".time()."','$amount')";
		$addr0 = mysql_query($addq0);

if ($adpackid != "")
{
$apackq = "select * from adpacks where id=\"$adpackid\"";
$apackr = mysql_query($apackq);
$apackrows = mysql_num_rows($apackr);
if ($apackrows > 0)
{
$countq = "update adpacks set howmanytimeschosen=howmanytimeschosen+1 where id=\"$adpackid\"";
$countr = mysql_query($countq);
$description = mysql_result($apackr,0,"description");
$points = mysql_result($apackr,0,"points");
$surfcredits = mysql_result($apackr,0,"surfcredits");
$banner_num = mysql_result($apackr,0,"banner_num");
$banner_views = mysql_result($apackr,0,"banner_views");
$solo_num = mysql_result($apackr,0,"solo_num");
$traffic_num = mysql_result($apackr,0,"traffic_num");
$traffic_views = mysql_result($apackr,0,"traffic_views");
$login_num = mysql_result($apackr,0,"login_num");
$login_views = mysql_result($apackr,0,"login_views");
$hotlink_num = mysql_result($apackr,0,"hotlink_num");
$hotlink_views = mysql_result($apackr,0,"hotlink_views");
$button_num = mysql_result($apackr,0,"button_num");
$button_views = mysql_result($apackr,0,"button_views");
$ptc_num = mysql_result($apackr,0,"ptc_num");
$ptc_views = mysql_result($apackr,0,"ptc_views");
$featuredad_num = mysql_result($apackr,0,"featuredad_num");
$featuredad_views = mysql_result($apackr,0,"featuredad_views");
$hheaderad_num = mysql_result($apackr,0,"hheaderad_num");
$hheaderad_views = mysql_result($apackr,0,"hheaderad_views");
$hheadlinead_num = mysql_result($apackr,0,"hheadlinead_num");
$hheadlinead_views = mysql_result($apackr,0,"hheadlinead_views");
########################################################
if ($points > 0)
	{
	mysql_query("UPDATE members SET points=points+".$points." WHERE userid='".$username."'");
	}
if ($surfcredits > 0)
	{
	mysql_query("UPDATE members SET surfcredits=surfcredits+".$surfcredits." WHERE userid='".$username."'");
	}
if ($solo_num > 0)
	{
		$count = $solo_num;
		while($count > 0) {
			mysql_query("INSERT INTO `solos` (`id` ,`userid` ,`approved` ,`subject` ,`adbody` ,`sent` ,`added`) VALUES (NULL , '".$username."', '0', '', '', '0', '0')");
			$count--;
		}
	}
if (($featuredad_num > 0) and ($featuredad_views > 0))
	{
		$count = $featuredad_num;
		while($count > 0) {
			mysql_query("insert into featuredads (userid,max,purchase) values('$username','".$featuredad_views."',NOW())");
			$count--;
			}
	}
if (($hheaderad_num > 0) and ($hheaderad_views > 0))
	{
		$count = $hheaderad_num;
		while($count > 0) {
			mysql_query("insert into hheaderads (userid,max,purchase) values('$username','".$hheaderad_views."',NOW())");
			$count--;
			}
	}
if (($hheadlinead_num > 0) and ($hheadlinead_views > 0))
	{
		$count = $hheadlinead_num;
		while($count > 0) {
			mysql_query("insert into hheadlineads (userid,max,purchase) values('$username','".$hheadlinead_views."',NOW())");
			$count--;
			}
	}
if (($banner_num > 0) and ($banner_views > 0))
	{
		$count = $banner_num;
		while($count > 0) {
			mysql_query("INSERT INTO `banners` ( `id` , `name` , `bannerurl` , `targeturl` , `userid` , `status` , `shown` , `clicks` , `max` , `added` )VALUES (NULL , '', '', '', '".$username."', '0', '0', '0', '".$banner_views."', '0')");
			$count--;
		}
	}
if (($button_num > 0) and ($button_views > 0))
	{
		$count = $button_num;
		while($count > 0) {
			mysql_query("INSERT INTO `buttons` ( `id` , `name` , `bannerurl` , `targeturl` , `userid` , `status` , `shown` , `clicks` , `max` , `added` )VALUES (NULL , '', '', '', '".$username."', '0', '0', '0', '".$button_views."', '0')");
			$count--;
		}
	}
if (($login_num > 0) and ($login_views > 0))
	{
		$count = $login_num;
		while($count > 0) {
			mysql_query("insert into loginads (userid,max) values('$username','".$login_views."')");
			$count--;
		}
	}
if (($traffic_num > 0) and ($traffic_views > 0))
	{
		$count = $traffic_num;
		while($count > 0) {
			mysql_query("insert into tlinks (userid,paid) values('$username','".$traffic_views."')");
			$count--;
		}
	}
if (($hotlink_num > 0) and ($hotlink_views > 0))
	{
		$count = $hotlink_num;
		while($count > 0) {
			mysql_query("insert into hotlinks (userid,max) values('$username','".$hotlink_views."')");
			$count--;
		}
	}
if (($ptc_num > 0) and ($ptc_views > 0))
	{
		$count = $ptc_num;
		while($count > 0) {
			mysql_query("insert into ptcads (userid,paid) values('$username','".$ptc_views."')");
			$count--;
		}
	}
} # if ($apackrows > 0)
} # if ($adpackid != "")

		} # if ($addrow > 0)
} # if ($vacancyrows < 1)
######################################################################################################## CYCLE CHECK
$refsinlowestmatrixlevel = pow($matrixwidth, $matrixdepth);
$cycleq = "select * from $matrixtablename where L$matrixdepth>=$refsinlowestmatrixlevel and cycled!=\"yes\"";
$cycler = mysql_query($cycleq);
$cyclerow = mysql_num_rows($cycler);
if ($cyclerow > 0)
{
	while ($cyclerowz = mysql_fetch_array($cycler))
	{
		$cycleid = $cyclerowz["id"];
		$cycleusername = $cyclerowz["username"];
		$cycleq2build = "";
		for($o=1;$o<=$matrixdepth;$o++)
		{
		$maxrefsinthislevel = pow($matrixwidth, $o);
		$cycleq2build = $cycleq2build . "L$o=" . $maxrefsinthislevel . ",";
		} # for($o=1;$o<=$matrixdepth;$o++)
		$cycleq2 = "update $matrixtablename set owed=owed+" . $matrixpayout . "," . $cycleq2build . "cycled=\"yes\", datecycled=NOW(), paid=\"yes\", lastpaid=NOW() where id=\"$cycleid\"";
		$cycler2 = mysql_query($cycleq2);
		$getpaidq = "update members set commission=commission+" . $matrixpayout . " where userid=\"$cycleusername\"";
		$getpaidr = mysql_query($getpaidq);
		if ($cyclecommissionforsponsor > 0)
		{
		$refq = "select * from members where userid=\"$cycleusername\"";
		$refr = mysql_query($refq);
		$refrows = mysql_num_rows($refr);
		if ($refrows > 0)
			{
			$referrer = mysql_result($refr,0,"referid");
			$refq2 = "update members set commission=commission+" . $cyclecommissionforsponsor . " where userid=\"$referrer\"";
			$refr2 = mysql_query($refq2);
			}
		}
		if ($givereentrythislevel == "yes")
		{
		$thislevel = MatrixAdd($cycleusername,$matrixlevelname,$matrixwidth,$matrixdepth,$matrixprice,$matrixpayout,$givereentrythislevel,$matrixsequence,$matrixid,$cyclecommissionforsponsor);
		}
		$nextmatrixsequence = $matrixsequence+1;
		$nq = "select * from matrixconfiguration where matrixsequence=\"$nextmatrixsequence\"";
		$nr = mysql_query($nq);
		$nrows = mysql_num_rows($nr);
		if ($nrows > 0)
		{
		$nextmatrixid = mysql_result($nr,0,"id");
		$nextmatrixlevelname = mysql_result($nr,0,"matrixlevelname");
		$nextmatrixwidth = mysql_result($nr,0,"matrixwidth");
		$nextmatrixdepth = mysql_result($nr,0,"matrixdepth");
		$nextmatrixprice = mysql_result($nr,0,"matrixprice");
		$nextmatrixpayout = mysql_result($nr,0,"matrixpayout");
		$nextgivereentrythislevel = mysql_result($nr,0,"givereentrythislevel");
		$nextcyclecommissionforsponsor = mysql_result($nr,0,"cyclecommissionforsponsor");
		$nextlevel = MatrixAdd($cycleusername,$nextmatrixlevelname,$nextmatrixwidth,$nextmatrixdepth,$nextmatrixprice,$nextmatrixpayout,$nextgivereentrythislevel,$nextmatrixsequence,$nextmatrixid,$nextcyclecommissionforsponsor);
		} # if ($nrows > 0)
		if ($nrows < 1)
		{
		$howmanypositions = 1;
		$firstmatrixq = "select * from matrixconfiguration order by id limit 1";
		$firstmatrixr = mysql_query($firstmatrixq);
		$firstmatrixrows = mysql_num_rows($firstmatrixr);
		if ($firstmatrixrows > 0)
			{
				$nextmatrixid = mysql_result($firstmatrixr,0,"id");
				$nextmatrixlevelname = mysql_result($firstmatrixr,0,"matrixlevelname");
				$nextmatrixwidth = mysql_result($firstmatrixr,0,"matrixwidth");
				$nextmatrixdepth = mysql_result($firstmatrixr,0,"matrixdepth");
				$nextmatrixprice = mysql_result($firstmatrixr,0,"matrixprice");
				$nextmatrixpayout = mysql_result($firstmatrixr,0,"matrixpayout");
				$nextgivereentrythislevel = mysql_result($firstmatrixr,0,"givereentrythislevel");
				$nextcyclecommissionforsponsor = mysql_result($firstmatrixr,0,"cyclecommissionforsponsor");
				$nextlevel = MatrixAdd($cycleusername,$nextmatrixlevelname,$nextmatrixwidth,$nextmatrixdepth,$nextmatrixprice,$nextmatrixpayout,$nextgivereentrythislevel,$nextmatrixsequence,$nextmatrixid,$nextcyclecommissionforsponsor);
			} # if ($firstmatrixrows > 0)
		} # if ($nrows < 1)
	}
} # if ($cyclerow > 0)
######################################################################################################## COMPRESS
$q = "update $matrixtablename set positionordernumber=1 where id=1";
$r = mysql_query($q);
$q = "select * from $matrixtablename where username!=\"VACANT\" order by id";
$r = mysql_query($q);
$rows = mysql_num_rows($r);
$positionordernumber = 0;
if ($rows > 0)
{
	while ($rowz = mysql_fetch_array($r))
	{
	$mid = $rowz["id"];
	$positionordernumber = $positionordernumber+1;
	for($i=1;$i<=$matrixdepth;$i++)
	{
	$levelname = "L" . $i;
	$parentidname = "parent" . $i;
	$q2 = "select * from $matrixtablename where $parentidname=\"".$mid."\"";
	$r2 = mysql_query($q2);
	$rows2 = mysql_num_rows($r2);
	$q3 = "update matrix set $levelname=\"".$rows2."\",positionordernumber=".$positionordernumber.",id=".$positionordernumber." where id=\"".$mid."\"";
	$r3 = mysql_query($q3);
	$q4 = "update matrix set $parentidname=".$positionordernumber." where $parentidname=".$mid;
	#echo $q3 . "<br>" . $q4 . "<br>";
	$r4 = mysql_query($q4);
	} # for($i=1;$i<=$matrixdepth;$i++)
	} # while ($rowz = mysql_fetch_array($r))
} # if ($rows > 0)
} # if ($row00 > 0)
} # function MatrixAdd
?>