<!DOCTYPE html>
<html>
<head>
	<title>Dynamic Ajax Shopping Cart</title>
	<script type="text/javascript" src="jquery-1.3.2.js"></script>
	<script type="text/javascript" src="jquery.livequery.js"></script>
	<link href="style.css" rel="stylesheet" />
<script type="text/javascript">
$(document).ready(function() {
	var Arrays=new Array();
	$('.add-to-cart-button').click(function(){
		var thisID 	  = $(this).parent().parent().attr('id').replace('detail-','');
		var itemname  = $(this).parent().find('.item_name').html();
		var itemprice = $(this).parent().find('.price').html();
		
		if(include(Arrays,thisID))
		{
			var price 	 = $('#each-'+thisID).children(".shopp-price").find('em').html();
			var quantity = $('#each-'+thisID).children(".shopp-quantity").html();
			quantity = parseInt(quantity)+parseInt(1);
			var total = parseInt(itemprice)*parseInt(quantity);
			$('#each-'+thisID).children(".shopp-price").find('em').html(total);
			$('#each-'+thisID).children(".shopp-quantity").html(quantity);
			var prev_charges = $('.cart-total span').html();
			prev_charges = parseInt(prev_charges)-parseInt(price);
			prev_charges = parseInt(prev_charges)+parseInt(total);
			$('.cart-total span').html(prev_charges);
			$('#total-hidden-charges').val(prev_charges);
		}
		else
		{
			Arrays.push(thisID);
			var prev_charges = $('.cart-total span').html();
			prev_charges = parseInt(prev_charges)+parseInt(itemprice);
			$('.cart-total span').html(prev_charges);
			$('#total-hidden-charges').val(prev_charges);
			var Height = $('#cart_wrapper').height();
			$('#cart_wrapper').css({height:Height+parseInt(45)});
			$('#cart_wrapper .cart-info').append('<div class="shopp" id="each-'+thisID+'"><div class="label">'+itemname+'</div><div class="shopp-price"> $<em>'+itemprice+'</em></div><span class="shopp-quantity">1</span><img src="remove.png" class="remove" /><br class="all" /></div>');
		}
	});	
	$('.remove').livequery('click', function() {
		var deduct = $(this).parent().children(".shopp-price").find('em').html();
		var prev_charges = $('.cart-total span').html();
		var thisID = $(this).parent().attr('id').replace('each-','');
		var pos = getpos(Arrays,thisID);
		Arrays.splice(pos,1,"0")
		prev_charges = parseInt(prev_charges)-parseInt(deduct);
		$('.cart-total span').html(prev_charges);
		$('#total-hidden-charges').val(prev_charges);
		$(this).parent().remove();
	});	
	$('#Submit').livequery('click', function() {
		var totalCharge = $('#total-hidden-charges').val();
		$('#cart_wrapper').html('Total Charges: $'+totalCharge);
		return false;
	});	
	var single_li_offset 	= 200;
	var current_opened_box  = -1;
	$('#wrap li').click(function() {
		var thisID = $(this).attr('id');
		var $this  = $(this);
		var id = $('#wrap li').index($this);
		if(current_opened_box == id)
		{
			$('#wrap .detail-view').slideUp('slow');
			return false;
		}
		$('#cart_wrapper').slideUp('slow');
		$('#wrap .detail-view').slideUp('slow');
		current_opened_box = id;
		var targetOffset = 0;
		if(id<=3)
			targetOffset = 0;
		else if(id<=7)
			targetOffset = single_li_offset;
		else if(id<=11)
			targetOffset = single_li_offset*2;
		else if(id<=15)
			targetOffset = single_li_offset*3;
		$("html:not(:animated),body:not(:animated)").animate({scrollTop: targetOffset}, 800,function(){
		$('#wrap #detail-'+thisID).slideDown(500);
			return false;
		});
	});
	$('.close a').click(function() {
		$('#wrap .detail-view').slideUp('slow');
	});
	$('.closeCart').click(function() {
		$('#cart_wrapper').slideUp();
		
	});
	$('#show_cart').click(function() {
		$('#cart_wrapper').slideToggle('slow');
	});
});
function include(arr, obj) {
  for(var i=0; i<arr.length; i++) {
    if (arr[i] == obj) return true;
  }
}
function getpos(arr, obj) {
  for(var i=0; i<arr.length; i++) {
    if (arr[i] == obj) return i;
  }
}
</script>
</head>
<body>
<div class="header">
	<ul>
	  <li><a href="index.php">Home</a></li>
	  <li><a href="#product">Products</a></li>
	  <li><a href="#contact">Contact</a></li>
	  <li><a href="#about">About</a></li>
	  <li><a id="show_cart" href="javascript:void(0)">View Cart</a></li>
	</ul>
</div>
<div align="left" style="min-height:800px;">
	<div id="cart_wrapper" align="center">
		<form action="#" id="cart_form" name="cart_form">
			<div class="cart-info"></div>
			<div class="cart-total">
				<b>Total Charges:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b> $<span>0</span>
				<input type="hidden" name="total-hidden-charges" id="total-hidden-charges" value="0" />
			</div>
			<button type="submit" id="Submit">CheckOut</button>
		</form>
	</div>
	<div id="wrap" align="center">
		
		<ul>
			<div>
				<h1>Mobile Phones 2016</h1><hr/>
			</div>
			<li id="1">
				<img src="product_img/1.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div>Asus Phone 2016</div>
			</li>
			<li id="2">
				<img src="product_img/2.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div>Samsung Edge</div>
			</li>
			<li id="3">
				<img src="product_img/3.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div>Samsung A5 Gold</div>
			</li>
			<li id="4">
				<img src="product_img/4.png" class="items" height="100" alt="" />
				
				<br clear="all" />
				<div>Samsung J5 2016</div>
			</li>
			<div class="detail-view" id="detail-1">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/1.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Asus Phone 2016</label>
					<br clear="all" />
					<p>
						New mobile phones in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">30,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-2">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/2.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Samsung Edge</label>
					<br clear="all" />
					<p>
						New mobile phones in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">28,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-3">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/3.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Samsung A5 Gold</label>
					<br clear="all" />
					<p>
						New mobile phones in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">33,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-4">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/4.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Samsung J5 2016</label>
					<br clear="all" />
					<p>
						New mobile phones in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">10,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<li id="5">
				<img src="product_img/5.jpg" class="items" height="100" alt="" />
				<br clear="all" />
				<div>Iphone 5S</div>
			</li>
			<li id="6">
				<img src="product_img/6.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div>Honor</div>
			</li>
			<li id="7">
				<img src="product_img/7.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div>HTC</div>
			</li>
			<li id="8">
				<img src="product_img/8.jpg" class="items" height="100" alt="" />
				<br clear="all" />
				<div>Infinix Note 2</div>
			</li>
			<div class="detail-view" id="detail-5">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/5.jpg" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Iphone 5S</label>
					<br clear="all" />
					<p>
						New mobile phones in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">34,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-6">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/6.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Honor</label>
					<br clear="all" />
					<p>
						New mobile phones in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">12,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-7">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/7.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>HTC</label>
					<br clear="all" />
					<p>
						New mobile phones in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">15,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-8">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/8.jpg" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Infinix Note 2</label>
					<br clear="all" />
					<p>
						New mobile phones in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">25,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div>
				<h1>Laptops</h1><hr/>
			</div>
			<li id="9">
				<img src="product_img/9.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div><span class="name">ASUS</span><span class="price"></span></div>
			</li>
			<li id="10">
				<img src="product_img/10.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div><span class="name">Raptor</span></div>
			</li>
			<li id="11">
				<img src="product_img/11.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div><span class="name">Lenovo Gaming Laptop</span></div>
			</li>
			<li id="12">
				<img src="product_img/12.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div><span class="name">Apple Mac Pro Series</span></div>
			</li>
			<div class="detail-view" id="detail-9">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/9.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>ASUS</label>
					<br clear="all" />
					<p>
						New Series of Laptops in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">40,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-10">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/10.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Raptor</label>
					<br clear="all" />
					<p>
						New Series of Laptops in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">80,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-11">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/11.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Lenovo Gaming Laptop</label>
					<br clear="all" />
					<p>
						New Series of Laptops in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">75,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-12">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/12.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Apple Mac Pro Series</label>
					<br clear="all" />
					<p>
						New Series of Laptops in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">90,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<li id="13">
				<img src="product_img/13.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div><span class="name">Dell</span></div>
			</li>
			<li id="14">
				<img src="product_img/14.jpg" class="items" height="100" alt="" />
				<br clear="all" />
				<div><span class="name">MSI Gaming Laptop</span></div>
			</li>
			<li id="15">
				<img src="product_img/15.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div><span class="name">NVIDIA</span></div>
			</li>
			<li id="16">
				<img src="product_img/16.png" class="items" height="100" alt="" />
				<br clear="all" />
				<div><span class="name">Samsung</span></div>
			</li>
			<div class="detail-view" id="detail-13">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/13.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Dell</label>
					<br clear="all" />
					<p>
						New Series of Laptops in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">82,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-14">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/14.jpg" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>MSI Gaming Laptop</label>
					<br clear="all" />
					<p>
						New Series of Laptops in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">100,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-15">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/15.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>NVIDIA</label>
					<br clear="all" />
					<p>
						New Series of Laptops in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">50,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<div class="detail-view" id="detail-16">
				<div class="close" align="right">
					<a href="javascript:void(0)">x</a>
				</div>
				<img src="product_img/16.png" class="detail_images" width="340" height="310" alt="" />
				<div class="detail_info">
					<label class='item_name'>Samsung</label>
					<br clear="all" />
					<p>
						New Series of Laptops in this year 2016.
						<br clear="all" /><br clear="all" />
						P<span class="price">35,000.00</span>
					</p>
					<br clear="all" />
					<button  class="add-to-cart-button">Add to Cart</button>
				</div>
			</div>
			<br clear="all" />
		</ul>
		<br clear="all" />
	</div>
</div>
<div class="footer"><footer align="center"><a href="http://www.sourcecodester.com">Sourcecodester 2016</a></footer>
</div>
</body>
</html>